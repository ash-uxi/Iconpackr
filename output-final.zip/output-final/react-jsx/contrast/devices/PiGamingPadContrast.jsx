import React from 'react';

/**
 * PiGamingPadContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiGamingPadContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'gaming-pad icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M22 16.91v-5.24A6.67 6.67 0 0 0 15.33 5H8.67A6.67 6.67 0 0 0 2 11.67v5.24a3.09 3.09 0 0 0 5.85 1.38L8 18c.61-1.23 1.87-2 3.24-2h1.52c1.37 0 2.63.77 3.24 2l.15.3A3.09 3.09 0 0 0 22 16.9" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 13v-2m0 0V9m0 2H6m2 0h2m8.02 1H18m4-.33v5.24a3.09 3.09 0 0 1-5.85 1.38L16 18a3.6 3.6 0 0 0-3.24-2h-1.52c-1.37 0-2.63.77-3.24 2l-.15.3A3.09 3.09 0 0 1 2 16.9v-5.24A6.67 6.67 0 0 1 8.67 5h6.66A6.67 6.67 0 0 1 22 11.67"/>
    </svg>
  );
}
