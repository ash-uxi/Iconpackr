import React from 'react';

/**
 * PiPlaystationContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPlaystationContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'playstation icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M11 2v7.53l1 .33V5a1 1 0 1 1 2 0v5.84h1l1.58.52c4.55 1.24 4.67-6.17 0-7.58z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m8.04 13.87-4.2 1.9c-4.05 1.56-.7 5.33 3.16 4.08l1.04-.42M14 16.16l2.95-1.08c3.69-1.3 7.36 2.61 3.22 4.08L14 21.13m1-10.29 1.58.52c4.55 1.24 4.67-6.17 0-7.58L11 2v20"/>
    </svg>
  );
}
