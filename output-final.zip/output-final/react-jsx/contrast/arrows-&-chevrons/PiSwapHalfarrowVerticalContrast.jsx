import React from 'react';

/**
 * PiSwapHalfarrowVerticalContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSwapHalfarrowVerticalContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'swap-halfarrow-vertical icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M18 17.11a20 20 0 0 1-3.6 3.75.6.6 0 0 1-.4.14v-3.66a24 24 0 0 0 1.78-.06z"/><path d="M6 6.89a20 20 0 0 1 3.6-3.75q.18-.15.4-.14v3.66a24 24 0 0 0-1.78.06z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 17.34V21q.21 0 .4-.14a20 20 0 0 0 3.6-3.75l-2.22.17a24 24 0 0 1-1.78.06m0 0V6m-4 .66V3a.6.6 0 0 0-.4.14A20 20 0 0 0 6 6.89l2.22-.17A24 24 0 0 1 10 6.66m0 0V18"/>
    </svg>
  );
}
