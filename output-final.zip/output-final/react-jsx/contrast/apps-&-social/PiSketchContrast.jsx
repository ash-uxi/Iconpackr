import React from 'react';

/**
 * PiSketchContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSketchContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'sketch icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m22.13 7.9-2.9-4.06A2 2 0 0 0 17.58 3H6.41a2 2 0 0 0-1.63.84l-2.9 4.07a2 2 0 0 0 .1 2.47l8.5 9.92a2 2 0 0 0 3.04 0l8.5-9.92a2 2 0 0 0 .1-2.47" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m17.52 9.02-4.14 9.42L12 21m5.52-11.98H6.48m11.04 0h4.98m-4.98 0L12 3M6.48 9.02l4.14 9.42L12 21M6.48 9.02H1.5m4.98 0L12 3m10.5 6.02a2 2 0 0 0-.37-1.11l-2.9-4.07A2 2 0 0 0 17.58 3H12m10.5 6.02a2 2 0 0 1-.48 1.36l-8.5 9.92A2 2 0 0 1 12 21M1.5 9.02a2 2 0 0 0 .48 1.36l8.5 9.92A2 2 0 0 0 12 21M1.5 9.02a2 2 0 0 1 .37-1.11l2.9-4.07A2 2 0 0 1 6.42 3H12"/>
    </svg>
  );
}
