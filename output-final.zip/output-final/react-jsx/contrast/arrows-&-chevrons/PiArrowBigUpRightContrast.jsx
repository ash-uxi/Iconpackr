import React from 'react';

/**
 * PiArrowBigUpRightContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowBigUpRightContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-big-up-right icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m7.22 18.76-1.98-1.98c-.4-.4-.6-.59-.67-.82a1 1 0 0 1 0-.62c.07-.23.27-.42.67-.82l7.01-7.02Q10.77 6.15 9.2 4.91q4.54-.67 9.1-.18a1.1 1.1 0 0 1 .98.98c.33 3.03.27 6.09-.18 9.1a61 61 0 0 0-2.6-3.06l-7.01 7.01c-.4.4-.6.6-.82.67a1 1 0 0 1-.62 0c-.23-.07-.43-.27-.82-.67" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m5.24 16.78 1.98 1.98c.4.4.59.6.82.67a1 1 0 0 0 .62 0c.23-.07.42-.27.82-.67l7.02-7.01q1.34 1.48 2.6 3.06.66-4.55.17-9.1a1.1 1.1 0 0 0-.98-.98 35 35 0 0 0-9.1.18 61 61 0 0 1 3.06 2.6l-7.01 7.01c-.4.4-.6.6-.67.82a1 1 0 0 0 0 .62c.07.23.27.43.67.82"/>
    </svg>
  );
}
