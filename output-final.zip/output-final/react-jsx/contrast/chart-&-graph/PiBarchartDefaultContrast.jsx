import React from 'react';

/**
 * PiBarchartDefaultContrast icon from the contrast style in chart-&-graph category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBarchartDefaultContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'barchart-default icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M9 6c0-.93 0-1.4.15-1.77a2 2 0 0 1 1.08-1.08C10.6 3 11.07 3 12 3s1.4 0 1.77.15a2 2 0 0 1 1.08 1.08C15 4.6 15 5.07 15 6v5c0-.93 0-1.4.15-1.77a2 2 0 0 1 1.08-1.08C16.6 8 17.07 8 18 8s1.4 0 1.77.15a2 2 0 0 1 1.08 1.08c.15.37.15.84.15 1.77v6.8c0 1.12 0 1.68-.22 2.1a2 2 0 0 1-.87.88c-.43.22-.99.22-2.11.22H6.2c-1.12 0-1.68 0-2.1-.22a2 2 0 0 1-.88-.87C3 19.48 3 18.92 3 17.8V15c0-.93 0-1.4.15-1.77a2 2 0 0 1 1.08-1.08C4.6 12 5.07 12 6 12s1.4 0 1.77.15a2 2 0 0 1 1.08 1.08C9 13.6 9 14.07 9 15z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 21v-6c0-.93 0-1.4-.15-1.77a2 2 0 0 0-1.08-1.08C7.4 12 6.93 12 6 12s-1.4 0-1.77.15a2 2 0 0 0-1.08 1.08C3 13.6 3 14.07 3 15v2.8c0 1.12 0 1.68.22 2.1q.3.58.87.88c.43.22.99.22 2.11.22zm0 0h6m-6 0V6c0-.93 0-1.4.15-1.77a2 2 0 0 1 1.08-1.08C10.6 3 11.07 3 12 3s1.4 0 1.77.15a2 2 0 0 1 1.08 1.08C15 4.6 15 5.07 15 6v15m0 0h2.8c1.12 0 1.68 0 2.1-.22a2 2 0 0 0 .88-.87c.22-.43.22-.99.22-2.11V11c0-.93 0-1.4-.15-1.77a2 2 0 0 0-1.08-1.08C19.4 8 18.93 8 18 8s-1.4 0-1.77.15a2 2 0 0 0-1.08 1.08C15 9.6 15 10.07 15 11z"/>
    </svg>
  );
}
