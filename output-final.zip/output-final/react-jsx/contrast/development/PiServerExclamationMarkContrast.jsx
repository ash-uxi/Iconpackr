import React from 'react';

/**
 * PiServerExclamationMarkContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiServerExclamationMarkContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'server-exclamation-mark icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M7 12c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 15.3 3 15.54 3 16s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02h9.17a3 3 0 0 1-.17-1v-4a3 3 0 0 1 2.28-2.91l-.39-.07C17.7 12 17.46 12 17 12c.46 0 .7 0 .9-.02a3.5 3.5 0 0 0 3.08-3.09C21 8.7 21 8.46 21 8s0-.7-.02-.9a3.5 3.5 0 0 0-3.09-3.08C17.7 4 17.46 4 17 4H7c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 7.3 3 7.54 3 8s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 19v-4M7 12h10c.46 0 .7 0 .9-.02a3.5 3.5 0 0 0 3.08-3.09C21 8.7 21 8.46 21 8s0-.7-.02-.9a3.5 3.5 0 0 0-3.09-3.08C17.7 4 17.46 4 17 4H7c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 7.3 3 7.54 3 8s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02m0 0c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 15.3 3 15.54 3 16s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02h8.13M17 8h.01M13 16"/>
    </svg>
  );
}
