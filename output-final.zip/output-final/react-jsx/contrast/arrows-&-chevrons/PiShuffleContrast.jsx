import React from 'react';

/**
 * PiShuffleContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiShuffleContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'shuffle icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M18.2 10a15 15 0 0 0 2.65-2.56.7.7 0 0 0 0-.88A15 15 0 0 0 18.19 4l.07.65a24 24 0 0 1 0 4.7z"/><path d="M18.2 20a15 15 0 0 0 2.65-2.56.7.7 0 0 0 0-.88A15 15 0 0 0 18.19 14l.07.65a24 24 0 0 1 0 4.7z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2 17h1.88a6 6 0 0 0 4.91-2.56l3.42-4.88A6 6 0 0 1 17.12 7h1.25M2 7h1.88a6 6 0 0 1 3.96 1.5m5.48 7.14a6 6 0 0 0 3.8 1.36h1.25m0 0a24 24 0 0 1-.11 2.35l-.07.65a15 15 0 0 0 2.66-2.56.7.7 0 0 0 0-.88A15 15 0 0 0 18.19 14l.07.65a24 24 0 0 1 .11 2.35m0-10a24 24 0 0 1-.11 2.35l-.07.65a15 15 0 0 0 2.66-2.56.7.7 0 0 0 0-.88A15 15 0 0 0 18.19 4l.07.65A24 24 0 0 1 18.37 7"/>
    </svg>
  );
}
