import React from 'react';

/**
 * PiMaximizeFourLineArrowContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMaximizeFourLineArrowContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'maximize-four-line-arrow icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g opacity=".28"><path fill="currentColor" d="M3.07 3.54q-.2 2.23.17 4.46l.8-.95a24 24 0 0 1 3-3.01l.96-.8q-2.23-.37-4.46-.17a.5.5 0 0 0-.47.47"/><path fill="currentColor" d="M20.76 8q.37-2.23.17-4.46a.5.5 0 0 0-.47-.47 17 17 0 0 0-4.46.17l.95.8a24 24 0 0 1 3.01 3z"/><path fill="currentColor" d="M16 20.76q2.23.37 4.46.17a.5.5 0 0 0 .47-.47q.2-2.23-.17-4.46l-.8.95a24 24 0 0 1-3 3.01z"/><path fill="currentColor" d="M3.24 16q-.37 2.23-.17 4.46a.5.5 0 0 0 .47.47q2.23.2 4.46-.17l-.95-.8a24 24 0 0 1-3.01-3z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m15 15 3.52 3.52M9 9 5.48 5.48M9 15l-3.52 3.52M15 9l3.52-3.52m0 13.04q-.75.76-1.57 1.44l-.95.8q2.23.37 4.46.17a.5.5 0 0 0 .47-.47q.2-2.23-.17-4.46l-.8.95q-.67.82-1.44 1.57m0-13.04q.76.75 1.44 1.57l.8.95q.37-2.23.17-4.46a.5.5 0 0 0-.47-.47 17 17 0 0 0-4.46.17l.95.8a24 24 0 0 1 1.57 1.44m-13.04 0a24 24 0 0 0-1.44 1.57l-.8.95q-.37-2.23-.17-4.46a.5.5 0 0 1 .47-.47q2.23-.2 4.46.17l-.95.8a24 24 0 0 0-1.57 1.44m0 13.04a24 24 0 0 1-1.44-1.57l-.8-.95q-.37 2.23-.17 4.46a.5.5 0 0 0 .47.47q2.23.2 4.46-.17l-.95-.8q-.82-.67-1.57-1.44"/>
    </svg>
  );
}
