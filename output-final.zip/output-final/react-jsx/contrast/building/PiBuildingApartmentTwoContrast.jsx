import React from 'react';

/**
 * PiBuildingApartmentTwoContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBuildingApartmentTwoContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'building-apartment-two icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M10.8 2H6.2c-1.12 0-1.68 0-2.1.22a2 2 0 0 0-.88.87C3 3.52 3 4.08 3 5.2v15.2c0 .56 0 .84.1 1.05a1 1 0 0 0 .45.44c.21.11.49.11 1.05.11h7.8c.56 0 .84 0 1.05-.1a1 1 0 0 0 .44-.45c.11-.21.11-.49.11-1.05V5.2c0-1.12 0-1.68-.22-2.1a2 2 0 0 0-.87-.88C12.48 2 11.92 2 10.8 2" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 6h3m-3 4h3m-3 4h3m-3 4h3m7-4h1m-1 4h1m-5.6 4c.56 0 .84 0 1.05-.1a1 1 0 0 0 .44-.45c.11-.21.11-.49.11-1.05V10m-1.6 12h7c.56 0 .84 0 1.05-.1a1 1 0 0 0 .44-.45c.11-.21.11-.49.11-1.05v-7.2c0-1.12 0-1.68-.22-2.1a2 2 0 0 0-.87-.88c-.43-.22-.99-.22-2.11-.22H14m-1.6 12H4.6c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45C3 21.24 3 20.96 3 20.4V5.2c0-1.12 0-1.68.22-2.1a2 2 0 0 1 .87-.88C4.52 2 5.08 2 6.2 2h4.6c1.12 0 1.68 0 2.1.22q.58.3.88.87c.22.43.22.99.22 2.11V10"/>
    </svg>
  );
}
