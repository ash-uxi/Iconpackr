import React from 'react';

/**
 * PiWhatsappContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiWhatsappContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'whatsapp icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M21 12a9 9 0 0 1-12.15 8.43c-.32-.12-.48-.18-.6-.2q-.15-.02-.31-.02c-.12 0-.25.04-.52.1l-1.48.35c-1.13.26-1.69.4-2.08.24a1.4 1.4 0 0 1-.76-.76c-.15-.4-.02-.95.24-2.08l.35-1.48c.06-.27.1-.4.1-.52q0-.16-.02-.31a4 4 0 0 0-.2-.6A9 9 0 1 1 21 12" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.7 12.49a9 9 0 0 1-1.2-3.9c.02-.5.46-.99.95-1.07q.32-.04.64 0c.49.04.91.34 1.11.78l.1.24.17.51c.25.97-.06 2-.79 2.67l-.42.34zm0 0a8 8 0 0 0 2.66 2.71m0 0a9 9 0 0 0 4.05 1.3c.5-.02.98-.46 1.06-.95q.06-.34.01-.68a1.4 1.4 0 0 0-.74-1.06l-.33-.12-.65-.22a2.7 2.7 0 0 0-2.43.64c-.12.11-.23.24-.46.5zM12 21a9 9 0 1 0-8.43-5.85c.12.32.18.48.2.6q.02.15.02.31c0 .12-.04.25-.1.52l-.35 1.48c-.26 1.13-.4 1.69-.24 2.08q.22.54.76.76c.4.15.95.02 2.08-.24l1.48-.35c.27-.06.4-.1.52-.1q.16 0 .31.02c.12.02.28.08.6.2Q10.33 21 12 21"/>
    </svg>
  );
}
