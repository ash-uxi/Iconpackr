import React from 'react';

/**
 * PiBugContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBugContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'bug icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12 20a7 7 0 0 0 6.5-4.7A8 8 0 0 0 16.76 7H7.24a7.9 7.9 0 0 0-1.74 8.3A7 7 0 0 0 12 20" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 20v-7m0 7a7 7 0 0 0 6.5-4.7M12 20a7 7 0 0 1-6.5-4.7M14.83 7a3 3 0 1 0-5.66 0m5.66 0h1.93q.7.71 1.22 1.6M14.83 7H9.17m0 0H7.24a8 8 0 0 0-1.22 1.6M21 3v2.54a3 3 0 0 1-2.41 2.94l-.6.12M3 3v2.54a3 3 0 0 0 2.41 2.94l.6.12M22 21v-2.54a3 3 0 0 0-2.41-2.94l-1.1-.22M2 21v-2.54a3 3 0 0 1 2.41-2.94l1.1-.22m12.99 0a8 8 0 0 0-.52-6.7M5.5 15.3a8 8 0 0 1 .52-6.7"/>
    </svg>
  );
}
