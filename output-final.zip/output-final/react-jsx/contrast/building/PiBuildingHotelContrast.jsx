import React from 'react';

/**
 * PiBuildingHotelContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBuildingHotelContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'building-hotel icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M19 19.5V4.2a14.7 14.7 0 0 0-14 0v15.3c0 .83.67 1.5 1.5 1.5h11c.83 0 1.5-.67 1.5-1.5" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="16" strokeWidth="2" d="M19 4.2v15.3c0 .83-.67 1.5-1.5 1.5H14m5-16.8a14.7 14.7 0 0 0-14 0m14 0q1.05.55 2 1.3M5 4.2v15.3c0 .83.67 1.5 1.5 1.5H10M5 4.2q-1.05.55-2 1.3M10 21h4m-4 0v-4.43M14 21v-4.43m.83.63a4 4 0 0 0-.83-.63m-4.83.63a4 4 0 0 1 .83-.63m4 0a4 4 0 0 0-4 0M16 13"/>
    </svg>
  );
}
