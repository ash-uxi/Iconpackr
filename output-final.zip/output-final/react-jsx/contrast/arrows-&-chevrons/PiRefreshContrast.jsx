import React from 'react';

/**
 * PiRefreshContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiRefreshContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'refresh icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M17.5 2.47a15 15 0 0 1 1.05 3.73c.03.22-.1.43-.3.51a15 15 0 0 1-3.75.96l.36-.5a24 24 0 0 0 2.39-4.14z"/><path d="M6.5 21.53a15 15 0 0 1-1.05-3.73.5.5 0 0 1 .3-.51l.18-.08a15 15 0 0 1 3.57-.88l-.36.5a24 24 0 0 0-2.39 4.14z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.9 10.8a8 8 0 0 1-12.06 8.04m-3.68-5.26a8 8 0 0 1 12-8.42M7.83 18.84a24 24 0 0 0-1.09 2.13l-.25.56a15 15 0 0 1-1.05-3.73.5.5 0 0 1 .3-.51 15 15 0 0 1 3.75-.96l-.36.5a24 24 0 0 0-1.3 2m8.31-13.68a24 24 0 0 0 1.1-2.13l.25-.56a15 15 0 0 1 1.05 3.73c.03.22-.1.43-.3.51a15 15 0 0 1-3.75.96l.36-.5q.7-.98 1.3-2"/>
    </svg>
  );
}
