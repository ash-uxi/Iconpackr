import React from 'react';

/**
 * PiGoogleCardboardVrContrast icon from the contrast style in ar-&-vr category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiGoogleCardboardVrContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'google-cardboard-vr icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2.33 7.64C2 8.28 2 9.12 2 10.8v2.4c0 1.68 0 2.52.33 3.16a3 3 0 0 0 1.3 1.31c.65.33 1.49.33 3.17.33h.24c.71 0 1.07 0 1.39-.1a2 2 0 0 0 .75-.47c.24-.24.4-.56.72-1.2l.67-1.34a1.6 1.6 0 0 1 2.86 0l.67 1.34c.32.64.48.96.72 1.2a2 2 0 0 0 .75.46c.32.11.68.11 1.4.11h.23c1.68 0 2.52 0 3.16-.33a3 3 0 0 0 1.31-1.3c.33-.65.33-1.49.33-3.17v-2.4c0-1.68 0-2.52-.33-3.16a3 3 0 0 0-1.3-1.31C19.71 6 18.87 6 17.2 6H6.8c-1.68 0-2.52 0-3.16.33a3 3 0 0 0-1.31 1.3" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.33 7.64C2 8.28 2 9.12 2 10.8v2.4c0 1.68 0 2.52.33 3.16a3 3 0 0 0 1.3 1.31c.65.33 1.49.33 3.17.33h.24c.71 0 1.07 0 1.39-.1a2 2 0 0 0 .75-.47c.24-.24.4-.56.72-1.2l.67-1.34a1.6 1.6 0 0 1 2.86 0l.67 1.34c.32.64.48.96.72 1.2a2 2 0 0 0 .75.46c.32.11.68.11 1.4.11h.23c1.68 0 2.52 0 3.16-.33a3 3 0 0 0 1.31-1.3c.33-.65.33-1.49.33-3.17v-2.4c0-1.68 0-2.52-.33-3.16a3 3 0 0 0-1.3-1.31C19.71 6 18.87 6 17.2 6H6.8c-1.68 0-2.52 0-3.16.33a3 3 0 0 0-1.31 1.3"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
    </svg>
  );
}
