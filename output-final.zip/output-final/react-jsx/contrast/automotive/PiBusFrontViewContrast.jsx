import React from 'react';

/**
 * PiBusFrontViewContrast icon from the contrast style in automotive category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBusFrontViewContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'bus-front-view icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M4 9.33c0-2.17 0-3.26.41-4.1a4 4 0 0 1 1.82-1.82C7.07 3 8.16 3 10.33 3h3.34c2.17 0 3.26 0 4.1.41a4 4 0 0 1 1.82 1.82c.41.84.41 1.93.41 4.1V20.5a1.5 1.5 0 0 1-3 0V19H7v1.5a1.5 1.5 0 0 1-3 0z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 9.33c0-2.17 0-3.26.41-4.1a4 4 0 0 1 1.82-1.82C7.07 3 8.16 3 10.33 3h3.34c2.17 0 3.26 0 4.1.41a4 4 0 0 1 1.82 1.82c.41.84.41 1.93.41 4.1V20.5a1.5 1.5 0 0 1-3 0V19H7v1.5a1.5 1.5 0 0 1-3 0z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 13h16"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16h1"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 16h1"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 9H2.5a.5.5 0 0 1-.5-.5V8a3 3 0 0 1 2.5-2.96M20 9h1.5a.5.5 0 0 0 .5-.5V8a3 3 0 0 0-2.5-2.96"/>
    </svg>
  );
}
