import React from 'react';

/**
 * PiChatChattingContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiChatChattingContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'chat-chatting icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M16.21 18.69q.58-1.45.59-3.09A8.4 8.4 0 0 0 6.27 7.47l-.3-.3a8 8 0 0 1 14.97 4.79l-.25 2.27v.26c0 .14 0 .28.03.56l.12 1.74c.06.76.08 1.14-.05 1.43a1.2 1.2 0 0 1-.57.57c-.29.13-.67.1-1.43.05l-1.74-.12-.56-.03z"/><path d="M12.44 19.19a5.4 5.4 0 0 1-4.9 1.74l-.99-.15h-.12l-.12-.01-.43.02-1.39.1c-.51.04-.77.06-.96-.03a1 1 0 0 1-.39-.39c-.09-.19-.07-.45-.03-.96l.1-1.39.02-.43v-.12l-.01-.12c0-.1-.06-.4-.15-1A5.4 5.4 0 0 1 5 11.4a5.4 5.4 0 0 1 7.43 7.79"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m17.05 18.72 1.74.12c.76.06 1.14.08 1.43-.05q.38-.19.57-.57c.13-.29.1-.67.05-1.43l-.12-1.74-.03-.56v-.38l.25-2.15q.06-.48.06-.96A8 8 0 0 0 6.38 6.5m7.42 9.1a5.4 5.4 0 1 0-10.73.86l.15.99.01.24-.02.43-.1 1.39c-.04.51-.06.77.03.96q.13.26.39.39c.19.09.45.07.96.03l1.39-.1.43-.02.24.01c.1 0 .4.06 1 .15A5.4 5.4 0 0 0 12.6 19c.75-.93 1.2-2.1 1.2-3.39"/>
    </svg>
  );
}
