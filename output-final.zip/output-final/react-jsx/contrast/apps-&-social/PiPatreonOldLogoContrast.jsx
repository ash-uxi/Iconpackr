import React from 'react';

/**
 * PiPatreonOldLogoContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPatreonOldLogoContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'patreon-old-logo icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M11 8.15a5.15 5.15 0 1 1 10.3 0 5.15 5.15 0 0 1-10.3 0"/><path d="M5 4.5c0-.47 0-.7.08-.88a1 1 0 0 1 .54-.54C5.8 3 6.03 3 6.5 3s.7 0 .88.08q.38.16.54.54c.08.18.08.41.08.88v15c0 .47 0 .7-.08.88a1 1 0 0 1-.54.54c-.18.08-.41.08-.88.08s-.7 0-.88-.08a1 1 0 0 1-.54-.54C5 20.2 5 19.97 5 19.5z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 8.15a5.15 5.15 0 1 1 10.3 0 5.15 5.15 0 0 1-10.3 0"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 4.5c0-.47 0-.7.08-.88a1 1 0 0 1 .54-.54C5.8 3 6.03 3 6.5 3s.7 0 .88.08q.38.16.54.54c.08.18.08.41.08.88v15c0 .47 0 .7-.08.88a1 1 0 0 1-.54.54c-.18.08-.41.08-.88.08s-.7 0-.88-.08a1 1 0 0 1-.54-.54C5 20.2 5 19.97 5 19.5z"/>
    </svg>
  );
}
