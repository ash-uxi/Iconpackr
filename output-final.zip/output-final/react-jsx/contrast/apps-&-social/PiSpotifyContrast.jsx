import React from 'react';

/**
 * PiSpotifyContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSpotifyContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'spotify icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2.85 12a9.15 9.15 0 1 0 18.3 0 9.15 9.15 0 0 0-18.3 0" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.05 15.88A10 10 0 0 0 8 15.44m8.25-2.32a13 13 0 0 0-8.75-.66m10-2.06A16 16 0 0 0 7 9.5m5 11.65a9.15 9.15 0 1 1 0-18.3 9.15 9.15 0 0 1 0 18.3"/>
    </svg>
  );
}
