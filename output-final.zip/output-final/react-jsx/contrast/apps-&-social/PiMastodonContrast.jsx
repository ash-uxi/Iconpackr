import React from 'react';

/**
 * PiMastodonContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMastodonContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'mastodon icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M17.85 19.3q-5.34.36-7.75-1.08c-.72-.43-.23-1.27.6-1.2 2.86.26 6.31.1 8.13-1.68.92-.89 1.4-1.96 1.4-5.08s-.03-4.23-1.4-5.79C16.6 1.9 7.41 1.9 5.17 4.47c-1.37 1.56-1.4 2.67-1.4 5.8l.03 1.18c.08 13.25 12.05 9.91 14.05 7.85" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11.31V8.4m0 0c0-1.26-.9-2.28-2-2.28S8 7.13 8 8.39v4.72m4-4.72c0-1.26.9-2.28 2-2.28s2 1.02 2 2.28v4.72m-5.9 5.1q2.42 1.45 7.75 1.09c-2 2.06-13.97 5.4-14.05-7.85l-.02-1.19c0-3.12.02-4.23 1.39-5.79 2.24-2.57 11.42-2.57 13.66 0 1.37 1.56 1.4 2.67 1.4 5.8 0 3.11-.48 4.18-1.4 5.07-1.82 1.77-5.27 1.94-8.12 1.68-.84-.07-1.33.77-.61 1.2"/>
    </svg>
  );
}
