import React from 'react';

/**
 * PiArcBrowserContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArcBrowserContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arc-browser icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M11.34 3.9c.87-.02 1.68.45 2.07 1.2l2.86 5.48A6 6 0 0 0 17.54 8a2.25 2.25 0 0 1 2.65-1.7 2.17 2.17 0 0 1 1.76 2.55 10.3 10.3 0 0 1-3.55 5.8l1.2 2.31a2.1 2.1 0 0 1-1 2.9 2.3 2.3 0 0 1-3.02-.97l-1.15-2.19a11 11 0 0 1-5.54.14l-.86 1.86a2.3 2.3 0 0 1-2.97 1.1 2.1 2.1 0 0 1-1.15-2.84L4.83 15q-1.46-1.08-2.46-2.55a2.1 2.1 0 0 1 .65-3 2.3 2.3 0 0 1 3.12.64q.27.39.6.75l2.6-5.64a2.3 2.3 0 0 1 2-1.29" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.9 16.85a11 11 0 0 0 5.53-.14m-5.54.14-.86 1.86a2.3 2.3 0 0 1-2.97 1.1 2.1 2.1 0 0 1-1.15-2.84L4.83 15m4.06 1.86c-1.5-.34-2.88-.99-4.06-1.86m0 0q-1.46-1.08-2.46-2.55a2.1 2.1 0 0 1 .65-3 2.3 2.3 0 0 1 3.12.64q.27.39.6.75m0 0 2.6-5.64a2.3 2.3 0 0 1 2-1.29c.87-.02 1.68.45 2.07 1.2l2.86 5.48m-9.53.25a6.4 6.4 0 0 0 4.03 1.95m0 0a7 7 0 0 0 1.6-.04m-1.6.04.75-1.65.84 1.6m3.91-2.15A6 6 0 0 0 17.54 8a2.25 2.25 0 0 1 2.65-1.7 2.17 2.17 0 0 1 1.76 2.55 10.3 10.3 0 0 1-3.55 5.8m-2.13-4.08 2.13 4.07m0 0 1.2 2.32a2.1 2.1 0 0 1-1 2.9 2.3 2.3 0 0 1-3.02-.97l-1.15-2.19m0 0-2.07-3.97"/>
    </svg>
  );
}
