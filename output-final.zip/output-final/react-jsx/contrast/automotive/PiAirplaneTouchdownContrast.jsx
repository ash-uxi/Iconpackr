import React from 'react';

/**
 * PiAirplaneTouchdownContrast icon from the contrast style in automotive category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAirplaneTouchdownContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'airplane-touchdown icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m5.47 13.63 13.36 3.58a1 1 0 0 0 1.23-.7 3 3 0 0 0-2.12-3.68l-2.9-.77-4.1-8.32a3 3 0 0 0-1.9-1.58L8.41 2l.82 8.5-2.9-.77-2.17-2.48a1 1 0 0 0-.5-.3L3 6.75l.25 4.15a3 3 0 0 0 2.22 2.72"/><path fill="currentColor" d="m5.47 13.63 13.36 3.58a1 1 0 0 0 1.23-.7 3 3 0 0 0-2.12-3.68l-2.9-.77-4.1-8.32a3 3 0 0 0-1.9-1.58L8.41 2l.82 8.5-2.9-.77-2.17-2.48a1 1 0 0 0-.5-.3L3 6.75l.25 4.15a3 3 0 0 0 2.22 2.72" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 20h18"/>
    </svg>
  );
}
