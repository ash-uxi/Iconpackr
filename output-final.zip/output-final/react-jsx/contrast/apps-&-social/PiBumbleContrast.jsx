import React from 'react';

/**
 * PiBumbleContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBumbleContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'bumble icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M15.43 3h-6.7c-.67 0-1 0-1.3.1a2 2 0 0 0-.73.41c-.23.22-.4.5-.74 1.09l-3.35 5.8c-.33.58-.5.87-.57 1.18a2 2 0 0 0 0 .84c.07.3.24.6.57 1.18l3.35 5.8c.34.58.5.87.74 1.09a2 2 0 0 0 .72.41c.3.1.64.1 1.31.1h6.7c.67 0 1.01 0 1.31-.1a2 2 0 0 0 .72-.41c.24-.22.4-.5.74-1.09l3.35-5.8c.34-.58.5-.87.57-1.18a2 2 0 0 0 0-.84c-.06-.3-.23-.6-.57-1.18L18.2 4.6c-.33-.58-.5-.87-.74-1.09a2 2 0 0 0-.72-.41c-.3-.1-.64-.1-1.3-.1" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7.08 12h10m-7 4.04h4M9.08 8h6M2.61 13.6l3.35 5.8c.34.58.5.87.74 1.09a2 2 0 0 0 .72.41c.3.1.64.1 1.31.1h6.7c.67 0 1.01 0 1.31-.1a2 2 0 0 0 .72-.41c.24-.22.4-.5.74-1.09l3.35-5.8c.34-.58.5-.87.57-1.18a2 2 0 0 0 0-.84c-.06-.3-.23-.6-.57-1.18L18.2 4.6c-.33-.58-.5-.87-.74-1.09a2 2 0 0 0-.72-.41c-.3-.1-.64-.1-1.3-.1h-6.7c-.68 0-1.02 0-1.32.1a2 2 0 0 0-.72.41c-.23.22-.4.5-.74 1.09l-3.35 5.8c-.33.58-.5.87-.57 1.18a2 2 0 0 0 0 .84c.07.3.24.6.57 1.18"/>
    </svg>
  );
}
