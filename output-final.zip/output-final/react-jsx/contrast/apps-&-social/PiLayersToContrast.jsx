import React from 'react';

/**
 * PiLayersToContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiLayersToContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'layers-to icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2.05 5.96 2 13.46a2.82 2.82 0 0 0 3.34 2.82l.21-.05v.22a2.82 2.82 0 0 0 3.34 2.82l.2-.04v.21a2.82 2.82 0 0 0 3.35 2.82l7.24-1.44a2.84 2.84 0 0 0 2.27-2.78l.05-7.5a2.82 2.82 0 0 0-3.34-2.82l-.21.05v-.22a2.82 2.82 0 0 0-3.34-2.82l-.2.04v-.21a2.82 2.82 0 0 0-3.35-2.82L4.32 3.18a2.84 2.84 0 0 0-2.27 2.78" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m14.9 4.77-7.03 1.4A2.84 2.84 0 0 0 5.6 8.95l-.05 7.28M14.9 4.77l.2-.04a2.82 2.82 0 0 1 3.35 2.82v.22m-3.55-3v-.21a2.82 2.82 0 0 0-3.34-2.82L4.32 3.18a2.84 2.84 0 0 0-2.27 2.78L2 13.46a2.82 2.82 0 0 0 3.34 2.82l.21-.05m0 0v.22a2.82 2.82 0 0 0 3.34 2.82l.2-.04m0 0v.21a2.82 2.82 0 0 0 3.35 2.82l7.24-1.44a2.84 2.84 0 0 0 2.27-2.78l.05-7.5a2.82 2.82 0 0 0-3.34-2.82l-.21.05M9.1 19.23l.05-7.29c0-1.36.95-2.52 2.26-2.78l7.04-1.4"/>
    </svg>
  );
}
