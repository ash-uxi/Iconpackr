import React from 'react';

/**
 * PiBarchartUpContrast icon from the contrast style in chart-&-graph category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBarchartUpContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'barchart-up icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M15.15 4.23C15 4.6 15 5.07 15 6v6c0-.93 0-1.4-.15-1.77a2 2 0 0 0-1.08-1.08C13.4 9 12.93 9 12 9s-1.4 0-1.77.15a2 2 0 0 0-1.08 1.08C9 10.6 9 11.07 9 12v6c0-.93 0-1.4-.15-1.77a2 2 0 0 0-1.08-1.08C7.4 15 6.93 15 6 15s-1.4 0-1.77.15a2 2 0 0 0-1.08 1.08C3 16.6 3 17.07 3 18s0 1.4.15 1.77a2 2 0 0 0 1.08 1.08C4.6 21 5.07 21 6 21h11.8c1.12 0 1.68 0 2.1-.22a2 2 0 0 0 .88-.87c.22-.43.22-.99.22-2.11V6c0-.93 0-1.4-.15-1.77a2 2 0 0 0-1.08-1.08C19.4 3 18.93 3 18 3s-1.4 0-1.77.15a2 2 0 0 0-1.08 1.08" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 21v-3c0-.93 0-1.4-.15-1.77a2 2 0 0 0-1.08-1.08C7.4 15 6.93 15 6 15s-1.4 0-1.77.15a2 2 0 0 0-1.08 1.08C3 16.6 3 17.07 3 18s0 1.4.15 1.77a2 2 0 0 0 1.08 1.08C4.6 21 5.07 21 6 21zm0 0h6m-6 0v-9c0-.93 0-1.4.15-1.77a2 2 0 0 1 1.08-1.08C10.6 9 11.07 9 12 9s1.4 0 1.77.15a2 2 0 0 1 1.08 1.08c.15.37.15.84.15 1.77v9m0 0h2.8c1.12 0 1.68 0 2.1-.22a2 2 0 0 0 .88-.87c.22-.43.22-.99.22-2.11V6c0-.93 0-1.4-.15-1.77a2 2 0 0 0-1.08-1.08C19.4 3 18.93 3 18 3s-1.4 0-1.77.15a2 2 0 0 0-1.08 1.08C15 4.6 15 5.07 15 6z"/>
    </svg>
  );
}
