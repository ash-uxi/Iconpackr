import React from 'react';

/**
 * PiNotificationBellOnContrast icon from the contrast style in alerts category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiNotificationBellOnContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'notification-bell-on icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M4.82 9.6a7.2 7.2 0 0 1 14.36 0l.36 4.27c.04.52.2 1 .37 1.48a1.6 1.6 0 0 1-1.34 2.08 60 60 0 0 1-13.14 0 1.6 1.6 0 0 1-1.33-2.08c.16-.49.32-.97.36-1.48z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.16 17.72q-1.88-.08-3.73-.3a1.6 1.6 0 0 1-1.33-2.07c.16-.49.32-.97.36-1.48l.36-4.26a7.2 7.2 0 0 1 14.36 0l.36 4.26c.04.52.2 1 .37 1.48a1.6 1.6 0 0 1-1.34 2.08 60 60 0 0 1-3.73.3m-5.68 0q2.85.12 5.68 0m-5.68 0v.43a2.84 2.84 0 1 0 5.68 0v-.44"/>
    </svg>
  );
}
