import React from 'react';

/**
 * PiFramerContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiFramerContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'framer icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M10.6 21.4 5 15v-4.1c0-.84 0-1.26.16-1.58q.23-.43.66-.66c.32-.16.74-.16 1.58-.16H12L5.92 3.41c-.52-.43-.78-.65-.8-.84a.5.5 0 0 1 .16-.44C5.42 2 5.76 2 6.44 2H16.6c.84 0 1.26 0 1.58.16q.43.23.66.66c.16.32.16.74.16 1.58v1.7c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.66c-.32.16-.74.16-1.58.16H12l6.1 5.09c.53.43.8.65.82.84a.5.5 0 0 1-.16.44c-.14.13-.49.13-1.17.13H12v5.87c0 .66 0 .99-.13 1.13a.5.5 0 0 1-.43.17c-.2-.03-.4-.28-.84-.77" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v5.87c0 .66 0 .99-.13 1.13a.5.5 0 0 1-.43.17c-.2-.03-.4-.28-.84-.77L5 15m0 0v-4.1c0-.84 0-1.26.16-1.58q.23-.43.66-.66c.32-.16.74-.16 1.58-.16H12M5 15h12.6c.67 0 1.02 0 1.16-.13a.5.5 0 0 0 .16-.44c-.03-.2-.3-.4-.81-.84L12 8.5m0 0h4.6c.84 0 1.26 0 1.58-.16q.43-.23.66-.66c.16-.32.16-.74.16-1.58V4.4c0-.84 0-1.26-.16-1.58a1.5 1.5 0 0 0-.66-.66C17.86 2 17.44 2 16.6 2H6.44c-.68 0-1.02 0-1.16.13a.5.5 0 0 0-.17.44c.03.19.3.4.81.84z"/>
    </svg>
  );
}
