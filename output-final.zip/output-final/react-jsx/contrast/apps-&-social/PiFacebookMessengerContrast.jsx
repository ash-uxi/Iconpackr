import React from 'react';

/**
 * PiFacebookMessengerContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiFacebookMessengerContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'facebook-messenger icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M3 11.73C3 6.71 6.93 3 12 3s9 3.72 9 8.73-3.93 8.73-9 8.73q-1.37 0-2.6-.34a.7.7 0 0 0-.49.03l-1.78.79a.72.72 0 0 1-1.01-.64l-.05-1.6q-.01-.3-.24-.51A8.5 8.5 0 0 1 3 11.73" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeMiterlimit="10" strokeWidth="2" d="m8 14 2.17-3.03a.5.5 0 0 1 .75-.07l2.3 2.2a.5.5 0 0 0 .76-.1L16 10m-4-7c-5.07 0-9 3.71-9 8.73 0 2.62 1.08 4.9 2.83 6.46q.22.2.24.51l.05 1.6a.72.72 0 0 0 1 .64l1.8-.79a.7.7 0 0 1 .47-.03q1.25.33 2.61.34c5.07 0 9-3.71 9-8.73C21 6.72 17.07 3 12 3"/>
    </svg>
  );
}
