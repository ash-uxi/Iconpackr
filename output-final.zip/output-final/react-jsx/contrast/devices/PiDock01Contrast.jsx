import React from 'react';

/**
 * PiDock01Contrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiDock01Contrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'dock-01 icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2 12c0-.93 0-1.4.08-1.78a4 4 0 0 1 3.14-3.14C5.61 7 6.07 7 7 7h10c.93 0 1.4 0 1.78.08a4 4 0 0 1 3.14 3.14c.08.39.08.85.08 1.78s0 1.4-.08 1.78a4 4 0 0 1-3.14 3.14c-.39.08-.85.08-1.78.08H7c-.93 0-1.4 0-1.78-.08a4 4 0 0 1-3.14-3.14C2 13.39 2 12.93 2 12" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2 12c0-.93 0-1.4.08-1.78a4 4 0 0 1 3.14-3.14C5.61 7 6.07 7 7 7h10c.93 0 1.4 0 1.78.08a4 4 0 0 1 3.14 3.14c.08.39.08.85.08 1.78s0 1.4-.08 1.78a4 4 0 0 1-3.14 3.14c-.39.08-.85.08-1.78.08H7c-.93 0-1.4 0-1.78-.08a4 4 0 0 1-3.14-3.14C2 13.39 2 12.93 2 12"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 11.8c0-.28 0-.42.05-.53a.5.5 0 0 1 .22-.22c.11-.05.25-.05.53-.05h.4c.28 0 .42 0 .53.05q.15.08.22.22c.05.11.05.25.05.53v.4c0 .28 0 .42-.05.53a.5.5 0 0 1-.22.22c-.11.05-.25.05-.53.05h-.4c-.28 0-.42 0-.53-.05a.5.5 0 0 1-.22-.22C6 12.62 6 12.48 6 12.2z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 11.8c0-.28 0-.42.05-.53a.5.5 0 0 1 .22-.22c.11-.05.25-.05.53-.05h.4c.28 0 .42 0 .53.05q.15.08.22.22c.05.11.05.25.05.53v.4c0 .28 0 .42-.05.53a.5.5 0 0 1-.22.22c-.11.05-.25.05-.53.05h-.4c-.28 0-.42 0-.53-.05a.5.5 0 0 1-.22-.22c-.05-.11-.05-.25-.05-.53z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11.8c0-.28 0-.42.05-.53a.5.5 0 0 1 .22-.22c.11-.05.25-.05.53-.05h.4c.28 0 .42 0 .53.05q.15.08.22.22c.05.11.05.25.05.53v.4c0 .28 0 .42-.05.53a.5.5 0 0 1-.22.22c-.11.05-.25.05-.53.05h-.4c-.28 0-.42 0-.53-.05a.5.5 0 0 1-.22-.22c-.05-.11-.05-.25-.05-.53z"/>
    </svg>
  );
}
