import React from 'react';

/**
 * PiArrowRightUpContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowRightUpContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-right-up icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M18.4 6.43q.44 3.9-.14 7.8l-4.03-4.46-4.46-4.03q3.9-.57 7.8-.15a.95.95 0 0 1 .84.84" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m14.23 9.77 4.03 4.46q.57-3.9.15-7.8a.95.95 0 0 0-.84-.84 30 30 0 0 0-7.8.15zm0 0L5.4 18.6"/>
    </svg>
  );
}
