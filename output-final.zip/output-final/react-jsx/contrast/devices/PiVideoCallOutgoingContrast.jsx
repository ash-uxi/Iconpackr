import React from 'react';

/**
 * PiVideoCallOutgoingContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiVideoCallOutgoingContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'video-call-outgoing icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M13 19a4 4 0 0 0 4-4V9a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v6a4 4 0 0 0 4 4z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 13.93a2 2 0 0 0 .71 1.47l1 .84A2 2 0 0 0 22 14.7V9.29a2 2 0 0 0-3.29-1.53l-1 .84a2 2 0 0 0-.7 1.46m0 3.87L17 15a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V9a4 4 0 0 1 4-4h7a4 4 0 0 1 4 4v1.06m0 3.87v-3.87"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12.85 13.4a15 15 0 0 0 .07-3.7.7.7 0 0 0-.2-.42M8.6 9.15a15 15 0 0 1 3.68-.07q.25.04.43.2m0 0L7 15"/>
    </svg>
  );
}
