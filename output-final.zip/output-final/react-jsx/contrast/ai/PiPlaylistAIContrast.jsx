import React from 'react';

/**
 * PiPlaylistAIContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPlaylistAIContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'playlist-ai icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M3 14c0-1.4 0-2.1.27-2.63a2.5 2.5 0 0 1 1.1-1.1C4.9 10 5.6 10 7 10h10c1.4 0 2.1 0 2.64.27q.72.37 1.09 1.1C21 11.9 21 12.6 21 14v4c0 1.4 0 2.1-.27 2.64a2.5 2.5 0 0 1-1.1 1.09C19.1 22 18.4 22 17 22H7c-1.4 0-2.1 0-2.63-.27a2.5 2.5 0 0 1-1.1-1.1C3 20.1 3 19.4 3 18z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 6h14M7 2h10M7 22h10c1.4 0 2.1 0 2.64-.27a2.5 2.5 0 0 0 1.09-1.1C21 20.1 21 19.4 21 18v-4c0-1.4 0-2.1-.27-2.63a2.5 2.5 0 0 0-1.1-1.1C19.1 10 18.4 10 17 10H7c-1.4 0-2.1 0-2.63.27a2.5 2.5 0 0 0-1.1 1.1C3 11.9 3 12.6 3 14v4c0 1.4 0 2.1.27 2.64q.37.72 1.1 1.09C4.9 22 5.6 22 7 22"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12.3 12.98a4.5 4.5 0 0 0 3 3 4.5 4.5 0 0 0-3 3 4.5 4.5 0 0 0-3-3 4.5 4.5 0 0 0 3-3"/>
    </svg>
  );
}
