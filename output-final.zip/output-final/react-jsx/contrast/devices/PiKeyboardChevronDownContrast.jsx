import React from 'react';

/**
 * PiKeyboardChevronDownContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiKeyboardChevronDownContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'keyboard-chevron-down icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M15.6 3H8.4c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C2 6.04 2 7.16 2 9.4v1.2c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.86.44 1.98.44 4.22.44h7.2c2.24 0 3.36 0 4.22-.44a4 4 0 0 0 1.74-1.74c.44-.86.44-1.98.44-4.22V9.4c0-2.24 0-3.36-.44-4.22a4 4 0 0 0-1.74-1.74C18.96 3 17.84 3 15.6 3" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 13H8m10-6h.01M18 10h.01M8.4 17h7.2c2.24 0 3.36 0 4.22-.44a4 4 0 0 0 1.74-1.74c.44-.86.44-1.98.44-4.22V9.4c0-2.24 0-3.36-.44-4.22a4 4 0 0 0-1.74-1.74C18.96 3 17.84 3 15.6 3H8.4c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C2 6.04 2 7.16 2 9.4v1.2c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.86.44 1.98.44 4.22.44"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m7 20.17 5 2 5-2"/>
    </svg>
  );
}
