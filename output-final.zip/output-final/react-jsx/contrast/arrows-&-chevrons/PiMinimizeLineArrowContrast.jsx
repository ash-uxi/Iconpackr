import React from 'react';

/**
 * PiMinimizeLineArrowContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMinimizeLineArrowContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'minimize-line-arrow icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M11.47 13.09q.24 2.65-.21 5.31l-2.62-3.04-3.04-2.62q2.66-.45 5.31-.21a.6.6 0 0 1 .56.56" opacity=".28"/><path fill="currentColor" d="M12.53 10.91q-.24-2.65.21-5.31l1.43 1.66a24 24 0 0 0 2.57 2.57l1.66 1.43q-2.66.45-5.31.21a.6.6 0 0 1-.56-.56" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.57 8.43 20 4M8.43 15.57 4 20"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.47 13.09q.24 2.65-.21 5.31l-2.62-3.04-3.04-2.62q2.66-.45 5.31-.21a.6.6 0 0 1 .56.56"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12.53 10.91q-.24-2.65.21-5.31l1.43 1.66a24 24 0 0 0 2.57 2.57l1.66 1.43q-2.66.45-5.31.21a.6.6 0 0 1-.56-.56"/>
    </svg>
  );
}
