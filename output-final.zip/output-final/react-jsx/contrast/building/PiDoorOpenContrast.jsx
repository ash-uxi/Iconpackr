import React from 'react';

/**
 * PiDoorOpenContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiDoorOpenContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'door-open icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2 20h9m8 0h3"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 20V7.98c0-1.4 0-2.1.27-2.63a2.5 2.5 0 0 1 1.1-1.1C6.9 3.98 7.6 3.98 9 3.98h2"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 20.71V3.31c0-.78 0-1.17.16-1.41a1 1 0 0 1 .62-.43c.3-.07.66.07 1.38.34l3.24 1.22c.94.35 1.4.52 1.75.83q.46.4.69.98c.16.43.16.93.16 1.93v10.51c0 1.01 0 1.52-.17 1.95a2.5 2.5 0 0 1-.69.99c-.35.3-.82.48-1.77.82l-3.22 1.18c-.72.26-1.09.4-1.37.33a1 1 0 0 1-.62-.43c-.16-.25-.16-.64-.16-1.4"/><path fill="currentColor" d="M11 20.71V3.31c0-.78 0-1.17.16-1.41a1 1 0 0 1 .62-.43c.3-.07.66.07 1.38.34l3.24 1.22c.94.35 1.4.52 1.75.83q.46.4.69.98c.16.43.16.93.16 1.93v10.51c0 1.01 0 1.52-.17 1.95a2.5 2.5 0 0 1-.69.99c-.35.3-.82.48-1.77.82l-3.22 1.18c-.72.26-1.09.4-1.37.33a1 1 0 0 1-.62-.43c-.16-.25-.16-.64-.16-1.4" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.95 11.62h-.92"/>
    </svg>
  );
}
