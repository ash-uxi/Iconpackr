import React from 'react';

/**
 * PiPhonePlusContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPhonePlusContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'phone-plus icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M5.4 12.97a18.5 18.5 0 0 1-2.37-7.26c-.14-1.2.6-2.46 1.87-2.66.4-.07.88-.06 1.29-.02 1.68.15 2.38 1.64 2.75 3.08a5.4 5.4 0 0 1-1.57 5.33c-.6.56-1.3 1.03-1.96 1.53"/><path d="M18.29 20.97a18 18 0 0 1-7.58-2.57c.64-.72 1.23-1.53 1.95-2.18a5.4 5.4 0 0 1 4.86-1.27c1.53.35 3.23 1.02 3.44 2.79.05.43.06.93-.01 1.36-.2 1.26-1.47 2-2.66 1.86"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 7h3m0 0h3m-3 0V4m0 3v3M5.4 12.97a18.5 18.5 0 0 1-2.37-7.26c-.14-1.2.6-2.46 1.87-2.66.4-.07.88-.06 1.29-.02 1.68.15 2.38 1.64 2.75 3.08a5.4 5.4 0 0 1-1.57 5.33c-.6.56-1.3 1.03-1.96 1.53m0 0a16 16 0 0 0 5.31 5.43m0 0a18 18 0 0 0 7.58 2.57c1.2.14 2.45-.6 2.66-1.87.07-.43.06-.93 0-1.36-.2-1.77-1.9-2.44-3.43-2.8a5.4 5.4 0 0 0-4.86 1.28c-.72.65-1.31 1.46-1.95 2.18"/>
    </svg>
  );
}
