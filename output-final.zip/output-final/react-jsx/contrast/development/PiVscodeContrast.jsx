import React from 'react';

/**
 * PiVscodeContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiVscodeContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'vscode icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" fillRule="evenodd" d="m17 3 3.23 1.62c.64.32.96.48 1.2.72a2 2 0 0 1 .46.74c.11.32.11.68.11 1.4v9.04c0 .72 0 1.08-.1 1.4a2 2 0 0 1-.47.74c-.24.24-.56.4-1.2.72L17 21l-7.79-7.01L4 18l-2-1.5L7 12 2 7.5 4 6l5.21 4zm-5.2 9L17 8v8z" clipRule="evenodd" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m17 21 3.23-1.62c.64-.32.96-.48 1.2-.72a2 2 0 0 0 .46-.74c.11-.32.11-.68.11-1.4V7.48c0-.72 0-1.08-.1-1.4a2 2 0 0 0-.47-.74c-.24-.24-.56-.4-1.2-.72L17 3m0 18v-5m0 5-7.79-7.01M17 3v5m0-5-7.79 7M17 8v8m0-8-5.2 4m5.2 4-5.2-4m0 0-2.6-2m0 0L4 6 2 7.5 7 12m0 0-5 4.5L4 18l5.21-4.01M7 12l2.21 1.99"/>
    </svg>
  );
}
