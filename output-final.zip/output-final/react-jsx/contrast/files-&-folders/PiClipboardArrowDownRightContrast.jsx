import React from 'react';

/**
 * PiClipboardArrowDownRightContrast icon from the contrast style in files-&-folders category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiClipboardArrowDownRightContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'clipboard-arrow-down-right icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M20 10.4v5.7c0 .25-.29.4-.51.29A3 3 0 0 0 15.23 18H14a3 3 0 0 0-2.91 3.73c.03.13-.06.27-.2.27h-.49c-2.24 0-3.36 0-4.22-.44a4 4 0 0 1-1.74-1.74C4 18.96 4 17.84 4 15.6v-5.2c0-2.24 0-3.36.44-4.22a4 4 0 0 1 1.74-1.74A5 5 0 0 1 8 4.04c0 .44 0 .66.05.85.14.52.54.92 1.06 1.06.2.05.43.05.89.05h4c.46 0 .7 0 .89-.05a1.5 1.5 0 0 0 1.06-1.06c.05-.19.05-.41.05-.85a5 5 0 0 1 1.82.4 4 4 0 0 1 1.74 1.74c.44.86.44 1.98.44 4.22" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 4.04V4c0-.46 0-.7-.05-.89a1.5 1.5 0 0 0-1.06-1.06C14.69 2 14.46 2 14 2h-4c-.46 0-.7 0-.89.05a1.5 1.5 0 0 0-1.06 1.06C8 3.31 8 3.54 8 4v.04m8 0c0 .44 0 .66-.05.85a1.5 1.5 0 0 1-1.06 1.06c-.2.05-.43.05-.89.05h-4c-.46 0-.7 0-.89-.05a1.5 1.5 0 0 1-1.06-1.06A4 4 0 0 1 8 4.04m8 0a5 5 0 0 1 1.82.4 4 4 0 0 1 1.74 1.74c.44.86.44 1.98.44 4.22v5.1M8 4.04a5 5 0 0 0-1.82.4 4 4 0 0 0-1.74 1.74C4 7.04 4 8.16 4 10.4v5.2c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.82.42 1.88.44 3.92.44h.03m7.93 1q1.05-.78 1.87-1.8A.3.3 0 0 0 20 21m0 0a.3.3 0 0 0-.07-.2 10 10 0 0 0-1.87-1.8M20 21h-6"/>
    </svg>
  );
}
