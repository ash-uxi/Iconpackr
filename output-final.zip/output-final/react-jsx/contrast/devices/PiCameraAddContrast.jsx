import React from 'react';

/**
 * PiCameraAddContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCameraAddContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'camera-add icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M16.76 6c1.15 0 1.73 0 2.2.16a3 3 0 0 1 1.88 1.88c.16.47.16 1.05.16 2.2v4.96c0 1.68 0 2.52-.33 3.16a3 3 0 0 1-1.3 1.31c-.65.33-1.49.33-3.17.33H7.82c-1.68 0-2.52 0-3.17-.33a3 3 0 0 1-1.3-1.3c-.33-.65-.33-1.49-.33-3.17v-4.97c0-1.14 0-1.72.15-2.18a3 3 0 0 1 1.9-1.9C5.53 6 6.1 6 7.25 6q.29 0 .42-.02a1 1 0 0 0 .5-.27q.09-.09.25-.34l1.1-1.66c.18-.26.27-.39.38-.48a1 1 0 0 1 .35-.19c.14-.04.3-.04.6-.04h2.3c.3 0 .46 0 .6.04a1 1 0 0 1 .35.19c.11.1.2.22.38.48l1.1 1.66q.16.25.25.34a1 1 0 0 0 .5.27c.1.02.21.02.43.02" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16.76 6c1.15 0 1.73 0 2.2.16a3 3 0 0 1 1.88 1.88c.16.47.16 1.05.16 2.2v4.96c0 1.68 0 2.52-.33 3.16a3 3 0 0 1-1.3 1.31c-.65.33-1.49.33-3.17.33H7.82c-1.68 0-2.52 0-3.17-.33a3 3 0 0 1-1.3-1.3c-.33-.65-.33-1.49-.33-3.17v-4.97c0-1.14 0-1.72.15-2.18a3 3 0 0 1 1.9-1.9C5.53 6 6.1 6 7.25 6q.29 0 .41-.02a1 1 0 0 0 .5-.27q.1-.09.26-.34l1.1-1.66c.18-.26.27-.39.38-.48a1 1 0 0 1 .34-.19c.15-.04.3-.04.62-.04h2.28c.32 0 .47 0 .62.04a1 1 0 0 1 .34.19c.11.1.2.22.38.48l1.1 1.66q.16.25.25.34a1 1 0 0 0 .5.27c.1.02.21.02.43.02"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 16v-3m0 0v-3m0 3H9m3 0h3"/>
    </svg>
  );
}
