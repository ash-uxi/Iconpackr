import React from 'react';

/**
 * PiCameraScanContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCameraScanContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'camera-scan icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M14.51 8.07c.46 0 .68 0 .87.04a2 2 0 0 1 1.58 1.58c.04.19.04.41.04.86v2.32c0 1.12 0 1.68-.22 2.1a2 2 0 0 1-.87.88c-.43.22-.99.22-2.11.22h-3.6c-1.12 0-1.68 0-2.1-.22a2 2 0 0 1-.88-.87c-.22-.43-.22-1-.22-2.11v-2.32c0-.45 0-.67.04-.86a2 2 0 0 1 1.58-1.58c.19-.04.41-.04.87-.04h.2a1 1 0 0 0 .53-.23l.14-.14.17-.16c.17-.18.26-.26.36-.32a1 1 0 0 1 .3-.12q.13-.04.47-.03h.68a2 2 0 0 1 .48.03q.15.03.29.12c.1.06.19.14.36.32l.17.16.14.14a1 1 0 0 0 .54.22z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.52 8c.45 0 .67 0 .86.04a2 2 0 0 1 1.58 1.58c.04.19.04.41.04.87v2.31c0 1.12 0 1.68-.22 2.1a2 2 0 0 1-.87.88c-.43.22-.99.22-2.11.22h-3.6c-1.12 0-1.68 0-2.1-.22a2 2 0 0 1-.88-.87C7 14.48 7 13.92 7 12.8v-2.32c0-.45 0-.67.04-.86a2 2 0 0 1 1.58-1.58C8.81 8 9.03 8 9.5 8h.2a1 1 0 0 0 .53-.23l.14-.13.17-.17c.17-.17.26-.26.36-.32a1 1 0 0 1 .3-.12c.1-.03.23-.03.47-.03h.68a2 2 0 0 1 .48.03q.15.03.29.12c.1.06.19.15.36.32l.17.17.14.13a1 1 0 0 0 .54.23z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 7.8v-.3c0-1.48.02-2.26.33-2.86a3 3 0 0 1 1.3-1.31C5.29 3 6.13 3 7.8 3H8M3 16.2v.3c0 1.48.02 2.26.33 2.86a3 3 0 0 0 1.3 1.31c.65.33 1.49.33 3.17.33H8m13-4.8v.3c0 1.48-.02 2.26-.33 2.86a3 3 0 0 1-1.3 1.31c-.65.33-1.49.33-3.17.33H16m5-13.2v-.3c0-1.48-.02-2.26-.33-2.86a3 3 0 0 0-1.3-1.31C18.71 3 17.87 3 16.2 3H16"/>
    </svg>
  );
}
