import React from 'react';

/**
 * PiGitFork02Contrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiGitFork02Contrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'git-fork-02 icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M9 5.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/><path d="M21 5.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/><path d="M9 18.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 15.5v-7m0 7a3 3 0 1 0 .25.01M6 15.5l.25.01M6 8.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6m11.87 0a4 4 0 0 1-3.16 3.41c-.4.09-.88.09-1.83.09h-.92c-1.44 0-2.16 0-2.8.22a4 4 0 0 0-1.49.92c-.47.47-.8 1.1-1.42 2.37M17.87 8.5H18a3 3 0 1 0-.13 0"/>
    </svg>
  );
}
