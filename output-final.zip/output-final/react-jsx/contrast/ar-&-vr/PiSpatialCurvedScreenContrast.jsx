import React from 'react';

/**
 * PiSpatialCurvedScreenContrast icon from the contrast style in ar-&-vr category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSpatialCurvedScreenContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'spatial-curved-screen icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2 4.4v-.1a1 1 0 0 1 1.34-.9l.65.19a29 29 0 0 0 16.02 0l.65-.2q.07 0 .09-.02A1 1 0 0 1 22 4.3v12.4a1 1 0 0 1-1.25.93l-.09-.03-.65-.19A29 29 0 0 0 4 17.4l-.65.2-.09.02A1 1 0 0 1 2 16.69z" opacity=".35"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 21h-5m9.67-3.4-.65-.2A29 29 0 0 0 4 17.4l-.65.2-.09.02A1 1 0 0 1 2 16.69V4.3a1 1 0 0 1 1.34-.9l.65.19a29 29 0 0 0 16.02 0l.65-.2q.07 0 .09-.02A1 1 0 0 1 22 4.3v12.4a1 1 0 0 1-1.25.93z"/>
    </svg>
  );
}
