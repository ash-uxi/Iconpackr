import React from 'react';

/**
 * PiNotionContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiNotionContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'notion icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M15.24 6.6h-2.88c-2.02 0-3.02 0-3.8.4A3.6 3.6 0 0 0 7 8.56c-.39.77-.39 1.77-.39 3.79v2.88c0 2.02 0 3.02.4 3.8a3.6 3.6 0 0 0 1.57 1.57c.77.39 1.77.39 3.79.39h2.88c2.02 0 3.02 0 3.8-.4a3.6 3.6 0 0 0 1.57-1.57c.39-.77.39-1.77.39-3.79v-2.88c0-2.02 0-3.02-.4-3.8A3.6 3.6 0 0 0 19.04 7c-.77-.39-1.77-.39-3.79-.39" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.89 17.4v-6.8q0-.17.02-.2a.1.1 0 0 1 .08-.04q.04.02.15.15l5.34 6.58q.11.14.15.15.05 0 .08-.03.04-.04.03-.22V10.2m3.55-2.14a4 4 0 0 0-1.26-1.07c-.77-.39-1.77-.39-3.79-.39h-2.88c-2.02 0-3.02 0-3.8.4A3.6 3.6 0 0 0 7 8.56c-.39.77-.39 1.77-.39 3.79v2.88c0 2.02 0 3.02.4 3.8q.3.6.82 1.06M20.29 8.06q.18.24.32.5c.39.78.39 1.78.39 3.8v2.88c0 2.02 0 3.02-.4 3.8a3.6 3.6 0 0 1-1.57 1.57c-.77.39-1.77.39-3.79.39h-2.88c-2.02 0-3.02 0-3.8-.4a4 4 0 0 1-.74-.5M20.29 8.06l-2.6-3.48a3.6 3.6 0 0 0-1.36-1.19C15.56 3 14.56 3 12.54 3H8.76c-2.02 0-3.02 0-3.8.4A3.6 3.6 0 0 0 3.4 4.96C3 5.74 3 6.74 3 8.76v3.78c0 2.02 0 3.02.4 3.8q.4.77 1.1 1.28l3.32 2.48"/>
    </svg>
  );
}
