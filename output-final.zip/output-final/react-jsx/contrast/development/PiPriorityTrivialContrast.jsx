import React from 'react';

/**
 * PiPriorityTrivialContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPriorityTrivialContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'priority-trivial icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M11.3 19.84a32 32 0 0 1-5.55-3.64c-.49-.4-.75-.98-.75-1.57V4a32 32 0 0 0 6.3 4.28q.33.16.7.16t.7-.16A32 32 0 0 0 19 4v10.63c0 .6-.26 1.16-.75 1.57a32 32 0 0 1-5.56 3.64q-.31.16-.69.16t-.7-.16" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.3 19.84a32 32 0 0 1-5.55-3.64c-.49-.4-.75-.98-.75-1.57V4a32 32 0 0 0 6.3 4.28q.33.16.7.16t.7-.16A32 32 0 0 0 19 4v10.63c0 .6-.26 1.16-.75 1.57a32 32 0 0 1-5.56 3.64q-.31.16-.69.16t-.7-.16"/>
    </svg>
  );
}
