import React from 'react';

/**
 * PiPendriveContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPendriveContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'pendrive icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M6 11.2c0-1.12 0-1.68.22-2.1a2 2 0 0 1 .87-.88C7.52 8 8.08 8 9.2 8h5.6c1.12 0 1.68 0 2.1.22q.58.3.88.87c.22.43.22.99.22 2.11V16c0 .93 0 1.4-.06 1.78a5 5 0 0 1-4.16 4.16c-.39.06-.85.06-1.78.06s-1.4 0-1.78-.06a5 5 0 0 1-4.16-4.16C6 17.4 6 16.93 6 16z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 11.2c0-1.12 0-1.68.22-2.1a2 2 0 0 1 .87-.88C7.52 8 8.08 8 9.2 8h5.6c1.12 0 1.68 0 2.1.22q.58.3.88.87c.22.43.22.99.22 2.11V16c0 .93 0 1.4-.06 1.78a5 5 0 0 1-4.16 4.16c-.39.06-.85.06-1.78.06s-1.4 0-1.78-.06a5 5 0 0 1-4.16-4.16C6 17.4 6 16.93 6 16z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 4.4c0-.84 0-1.26.16-1.58q.23-.43.66-.66C9.14 2 9.56 2 10.4 2h3.2c.84 0 1.26 0 1.58.16q.43.23.66.66c.16.32.16.74.16 1.58V8H8z"/>
    </svg>
  );
}
