import React from 'react';

/**
 * PiAppleWatchContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAppleWatchContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'apple-watch icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M12 19c1.86 0 2.8 0 3.53-.3l.47-.24-.5 1.8c-.18.62-.27.93-.45 1.16q-.25.32-.62.47c-.27.11-.6.11-1.25.11h-2.36c-.66 0-.98 0-1.25-.11a1.5 1.5 0 0 1-.62-.47 3 3 0 0 1-.44-1.17L8 18.46l.47.24c.73.3 1.67.3 3.53.3"/><path d="M15.53 5.3C14.8 5 13.86 5 12 5s-2.8 0-3.53.3L8 5.54l.5-1.8c.18-.62.27-.93.45-1.16q.25-.32.62-.47c.27-.11.6-.11 1.25-.11h2.36c.66 0 .98 0 1.25.11q.37.15.62.47c.18.23.27.54.44 1.17L16 5.54z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 11v2c0 1.86 0 2.8-.3 3.53a4 4 0 0 1-1.7 1.93M18 11c0-1.86 0-2.8-.3-3.53A4 4 0 0 0 16 5.54M18 11h1v-1h-1m-2-4.46-.5-1.8a4 4 0 0 0-.45-1.16 1.5 1.5 0 0 0-.62-.47C14.16 2 13.83 2 13.18 2h-2.36c-.66 0-.98 0-1.25.11q-.37.15-.62.47c-.18.23-.27.54-.44 1.17L8 5.54m8 0-.47-.24C14.8 5 13.86 5 12 5s-2.8 0-3.53.3L8 5.54m0 0a4 4 0 0 0-1.7 1.93C6 8.2 6 9.14 6 11v2c0 1.86 0 2.8.3 3.53A4 4 0 0 0 8 18.46m0 0 .5 1.8c.18.62.27.93.45 1.16q.25.32.62.47c.27.11.6.11 1.25.11h2.36c.66 0 .98 0 1.25-.11q.37-.15.62-.47c.18-.23.27-.54.44-1.17l.51-1.79m-8 0 .47.24c.73.3 1.67.3 3.53.3s2.8 0 3.53-.3l.47-.24"/>
    </svg>
  );
}
