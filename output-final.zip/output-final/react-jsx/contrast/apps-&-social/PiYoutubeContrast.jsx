import React from 'react';

/**
 * PiYoutubeContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiYoutubeContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'youtube icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M14 4h-4c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19C2 7.8 2 9.2 2 12s0 4.2.54 5.27a5 5 0 0 0 2.19 2.18C5.8 20 7.2 20 10 20h4c2.8 0 4.2 0 5.27-.55a5 5 0 0 0 2.18-2.18C22 16.2 22 14.8 22 12s0-4.2-.55-5.27a5 5 0 0 0-2.18-2.19C18.2 4 16.8 4 14 4" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2 12c0-2.8 0-4.2.54-5.27a5 5 0 0 1 2.19-2.19C5.8 4 7.2 4 10 4h4c2.8 0 4.2 0 5.27.54a5 5 0 0 1 2.18 2.19C22 7.8 22 9.2 22 12s0 4.2-.55 5.27a5 5 0 0 1-2.18 2.18C18.2 20 16.8 20 14 20h-4c-2.8 0-4.2 0-5.27-.55a5 5 0 0 1-2.19-2.18C2 16.2 2 14.8 2 12"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.98 11.13a1 1 0 0 1 0 1.74L11 15.15a1 1 0 0 1-1.5-.87V9.72a1 1 0 0 1 1.5-.87z"/>
    </svg>
  );
}
