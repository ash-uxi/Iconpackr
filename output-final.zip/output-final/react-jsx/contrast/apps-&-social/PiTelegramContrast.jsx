import React from 'react';

/**
 * PiTelegramContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTelegramContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'telegram icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m5.02 10.8 13.9-5.4c.76-.3 1.15-.45 1.44-.38a1 1 0 0 1 .57.45c.13.25.06.65-.07 1.45L19.3 16c-.24 1.38-.36 2.07-.73 2.45a1.8 1.8 0 0 1-1.26.55c-.54.01-1.15-.36-2.37-1.1l-2.58-1.6c-.78-.47-1.17-.7-1.34-1.03q-.22-.43-.1-.9c.09-.36.41-.67 1.06-1.3l4.37-4.24L9 13.1c-.6.34-.89.52-1.2.61q-.43.12-.87.11c-.33-.01-.66-.1-1.32-.28l-.45-.13c-1.23-.34-1.85-.51-2.03-.8a.9.9 0 0 1-.04-.83c.15-.3.74-.54 1.93-1" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m5.02 10.8 13.9-5.4c.76-.3 1.15-.45 1.44-.38a1 1 0 0 1 .57.45c.13.25.06.65-.07 1.45L19.3 16c-.24 1.38-.36 2.07-.73 2.45a1.8 1.8 0 0 1-1.26.55c-.54.01-1.15-.36-2.37-1.1l-2.58-1.6c-.78-.47-1.17-.7-1.34-1.03q-.22-.43-.1-.9c.09-.36.41-.67 1.06-1.3l4.37-4.24L9 13.1c-.6.34-.89.52-1.2.61q-.43.12-.87.11c-.33-.01-.66-.1-1.32-.28l-.45-.13c-1.23-.34-1.85-.51-2.03-.8a.9.9 0 0 1-.04-.83c.15-.3.74-.54 1.93-1"/>
    </svg>
  );
}
