import React from 'react';

/**
 * PiPhotoImageAIContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPhotoImageAIContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'photo-image-ai icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M2.54 5.73C2 6.8 2 8.2 2 11v2c0 2.8 0 4.2.54 5.27a5 5 0 0 0 2.19 2.18c.78.4 1.74.51 3.29.54L10 21h3a3 3 0 0 1 1.39-2.53 3 3 0 0 1 1.5-4.26c.63-.24.8-.4.86-.46.07-.07.22-.24.46-.85A3 3 0 0 1 20 11h2v-1c0-2.15-.07-3.34-.55-4.27a5 5 0 0 0-2.18-2.19C18.2 3 16.8 3 14 3h-4c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19"/><path d="M23 17a4.5 4.5 0 0 1-3-3 4.5 4.5 0 0 1-3 3 4.5 4.5 0 0 1 3 3 4.5 4.5 0 0 1 3-3"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.02 20.99q0-.37.04-.67a11.5 11.5 0 0 1 10.26-10.26C18.91 10 19.61 10 21 10h1c0-2.15-.07-3.34-.55-4.27a5 5 0 0 0-2.18-2.19C18.2 3 16.8 3 14 3h-4c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19C2 6.8 2 8.2 2 11v2c0 2.8 0 4.2.54 5.27a5 5 0 0 0 2.19 2.18c.78.4 1.74.51 3.29.54m0 0L10 21h2m4 0h.01M7.5 9.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2M20 14a4.5 4.5 0 0 1-3 3 4.5 4.5 0 0 1 3 3 4.5 4.5 0 0 1 3-3 4.5 4.5 0 0 1-3-3"/>
    </svg>
  );
}
