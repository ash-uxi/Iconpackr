import React from 'react';

/**
 * PiMacbookContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMacbookContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'macbook icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M22 17a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3 1 1 0 0 1 1-1h5.5l1 1H14l1-1h6a1 1 0 0 1 1 1" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 16V8.8c0-1.68 0-2.52-.33-3.16a3 3 0 0 0-1.3-1.31C18.71 4 17.87 4 16.2 4H7.8c-1.68 0-2.52 0-3.16.33a3 3 0 0 0-1.31 1.3C3 6.29 3 7.13 3 8.8V16m18 0h-6l-1 1H9.5l-1-1H3m18 0a1 1 0 0 1 1 1 3 3 0 0 1-3 3H5a3 3 0 0 1-3-3 1 1 0 0 1 1-1M13 4v1h-2V4"/>
    </svg>
  );
}
