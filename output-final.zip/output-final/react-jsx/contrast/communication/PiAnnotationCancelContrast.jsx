import React from 'react';

/**
 * PiAnnotationCancelContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAnnotationCancelContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'annotation-cancel icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2.5 9.08c0-2.13 0-3.2.42-4A4 4 0 0 1 4.58 3.4c.82-.4 1.88-.4 4-.4h6.85c2.13 0 3.19 0 4 .41.72.37 1.3.95 1.66 1.66.42.82.42 1.88.42 4.01v4.56c0 .7 0 1.06-.05 1.35a3.8 3.8 0 0 1-3.16 3.16c-.57.1-1.15 0-1.72.06a2 2 0 0 0-1.23.61c-.34.37-.61.8-.91 1.2-.83 1.1-1.24 1.65-1.74 1.85a2 2 0 0 1-1.38 0c-.5-.2-.92-.75-1.74-1.85-.3-.4-.58-.83-.91-1.2a2 2 0 0 0-1.24-.61c-.57-.06-1.15.03-1.72-.06A3.8 3.8 0 0 1 2.56 15c-.05-.3-.05-.64-.05-1.35z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.5 13.5 12 11m0 0 2.5-2.5M12 11 9.5 8.5M12 11l2.5 2.5M8.59 3h6.84c2.13 0 3.19 0 4 .41.72.37 1.3.95 1.66 1.66.42.82.42 1.88.42 4.01v4.56c0 .7 0 1.06-.05 1.35a3.8 3.8 0 0 1-3.16 3.16c-.57.1-1.15 0-1.72.06a2 2 0 0 0-1.23.61c-.34.37-.61.8-.91 1.2-.83 1.1-1.24 1.65-1.74 1.85a2 2 0 0 1-1.38 0c-.5-.2-.92-.75-1.74-1.85-.3-.4-.58-.83-.91-1.2a2 2 0 0 0-1.24-.61c-.57-.06-1.15.03-1.72-.06A3.8 3.8 0 0 1 2.56 15c-.05-.3-.05-.64-.05-1.35V9.08c0-2.13 0-3.2.41-4A4 4 0 0 1 4.58 3.4c.82-.4 1.88-.4 4-.4"/>
    </svg>
  );
}
