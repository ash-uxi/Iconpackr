import React from 'react';

/**
 * PiServerCheckContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiServerCheckContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'server-check icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M7 12c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 15.3 3 15.54 3 16s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02h5.93a3 3 0 0 1 4.56-3.55 17 17 0 0 1 3.1-2.6 3.5 3.5 0 0 0-2.7-1.83C17.7 12 17.46 12 17 12c.46 0 .7 0 .9-.02a3.5 3.5 0 0 0 3.08-3.09C21 8.7 21 8.46 21 8s0-.7-.02-.9a3.5 3.5 0 0 0-3.09-3.08C17.7 4 17.46 4 17 4H7c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 7.3 3 7.54 3 8s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 12h10M7 12c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 15.3 3 15.54 3 16s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02h4.87M7 12c-.46 0-.7 0-.9-.02a3.5 3.5 0 0 1-3.08-3.09C3 8.7 3 8.46 3 8s0-.7.02-.9a3.5 3.5 0 0 1 3.09-3.08C6.3 4 6.54 4 7 4h10c.46 0 .7 0 .9.02a3.5 3.5 0 0 1 3.08 3.09c.02.2.02.43.02.89s0 .7-.02.9a3.5 3.5 0 0 1-3.09 3.08c-.2.02-.43.02-.89.02m0 0c.46 0 .7 0 .9.02a3.5 3.5 0 0 1 2.07 1M17 8h.01m-1.3 10.87L17.84 21A14 14 0 0 1 22 16.5"/>
    </svg>
  );
}
