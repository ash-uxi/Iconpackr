import React from 'react';

/**
 * PiFacebookContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiFacebookContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'facebook icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M3.35 7.22C3 8.23 3 9.49 3 12s0 3.77.35 4.78a6.3 6.3 0 0 0 3.87 3.87C8.23 21 9.49 21 12 21s3.77 0 4.78-.35a6.3 6.3 0 0 0 3.87-3.87C21 15.77 21 14.51 21 12s0-3.77-.35-4.78a6.3 6.3 0 0 0-3.87-3.87C15.77 3 14.51 3 12 3s-3.77 0-4.78.35a6.3 6.3 0 0 0-3.87 3.87" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.6 8c-1.26 0-1.9 0-2.38.28q-.64.39-.98 1.12c-.24.55-.24 1.27-.24 2.71V13m0 0v8m0-8H8.75M11 13h3.75M11 21h1c2.51 0 3.77 0 4.78-.35a6.3 6.3 0 0 0 3.87-3.87C21 15.77 21 14.51 21 12s0-3.77-.35-4.78a6.3 6.3 0 0 0-3.87-3.87C15.77 3 14.51 3 12 3s-3.77 0-4.78.35a6.3 6.3 0 0 0-3.87 3.87C3 8.23 3 9.49 3 12s0 3.77.35 4.78a6.3 6.3 0 0 0 3.87 3.87c.87.3 1.91.34 3.78.35"/>
    </svg>
  );
}
