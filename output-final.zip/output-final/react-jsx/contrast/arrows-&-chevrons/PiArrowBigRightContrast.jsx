import React from 'react';

/**
 * PiArrowBigRightContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowBigRightContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-big-right icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M3 13.4v-2.8c0-.56 0-.84.11-1.05a1 1 0 0 1 .44-.44C3.76 9 4.05 9 4.6 9h9.93a61 61 0 0 0-.33-4 35 35 0 0 1 6.55 6.3 1.1 1.1 0 0 1 0 1.4Q17.9 16.26 14.2 19q.24-2 .33-4H4.6c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45c-.1-.21-.1-.49-.1-1.05" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10.6v2.8c0 .56 0 .84.11 1.05a1 1 0 0 0 .44.44c.21.11.5.11 1.05.11h9.93a61 61 0 0 1-.33 4 35 35 0 0 0 6.55-6.3 1.1 1.1 0 0 0 0-1.4Q17.9 7.74 14.2 5q.22 2 .33 4H4.6c-.56 0-.84 0-1.05.1a1 1 0 0 0-.44.45c-.1.21-.1.49-.1 1.05"/>
    </svg>
  );
}
