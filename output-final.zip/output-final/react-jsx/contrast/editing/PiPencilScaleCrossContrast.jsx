import React from 'react';

/**
 * PiPencilScaleCrossContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPencilScaleCrossContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'pencil-scale-cross icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M20.05 5.8 18.2 3.95c-.8-.8-1.2-1.2-1.66-1.35q-.62-.2-1.24 0c-.46.15-.86.55-1.66 1.35L10.68 6.9 7.53 3.75a4 4 0 0 0-.58-.52q-.21-.12-.46-.19A3 3 0 0 0 5.73 3H3l.07 2.68c0 .38.01.57.06.75q.06.23.19.44c.1.16.22.29.49.56l3.17 3.18-3.03 3.03c-.8.8-1.2 1.2-1.35 1.66-.13.4-.13.84 0 1.24.15.46.55.86 1.35 1.66l1.85 1.85c.8.8 1.2 1.2 1.66 1.35.4.13.84.13 1.24 0 .46-.15.86-.55 1.66-1.35l3.02-3.01 3.48 3.5c.53.52 1.34.61 1.97.2a6 6 0 0 0 1.93-1.96 1.6 1.6 0 0 0-.2-1.94l-.06-.06-3.42-3.44 2.97-2.98c.8-.8 1.2-1.2 1.35-1.66q.2-.62 0-1.24c-.15-.46-.55-.86-1.35-1.66" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m4.52 13.07 2.85 2.85m-2.85-2.85-.57.57c-.8.8-1.2 1.2-1.35 1.66-.13.4-.13.84 0 1.24.15.46.55.86 1.35 1.66l1.85 1.85c.8.8 1.2 1.2 1.66 1.35.4.13.84.13 1.24 0 .46-.15.86-.55 1.66-1.35l3.02-3.01m-8.86-3.97 2.46-2.46m6.09-6.1 2.14 2.14m-2.14-2.13-2.4 2.39m2.4-2.4.57-.56c.8-.8 1.2-1.2 1.66-1.35.4-.13.84-.13 1.24 0 .46.15.86.55 1.66 1.35l1.85 1.85c.8.8 1.2 1.2 1.35 1.66.13.4.13.84 0 1.24-.15.46-.55.86-1.35 1.66l-2.97 2.98m0 0 3.42 3.44.06.06a1.6 1.6 0 0 1 .15 2.02l-.03.05a6 6 0 0 1-1.85 1.84c-.63.4-1.44.31-1.97-.21l-3.48-3.5m3.7-3.7-6.4-6.43m0 0L7.53 3.75a4 4 0 0 0-.58-.52q-.21-.12-.46-.19C6.31 3 6.12 3 5.73 3H3l.07 2.68c0 .38.01.57.06.75q.06.23.19.44c.1.16.22.29.49.56l3.17 3.18m0 0 6.4 6.43"/>
    </svg>
  );
}
