import React from 'react';

/**
 * PiAI02Contrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAI02Contrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'ai-02 icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M8.58 5.76c.46-.89.69-1.34 1-1.48a1 1 0 0 1 .84 0c.31.14.54.59 1 1.48l1.2 2.32q.1.21.17.3l.15.16c.07.06.14.1.3.19l2.38 1.39c.78.45 1.17.68 1.3.97a1 1 0 0 1 0 .82c-.13.3-.52.52-1.3.97l-2.39 1.39-.29.19-.15.16q-.08.09-.18.3l-1.19 2.32c-.46.89-.69 1.34-1 1.48a1 1 0 0 1-.84 0c-.31-.14-.54-.6-1-1.48l-1.2-2.32q-.1-.21-.17-.3l-.15-.16-.3-.19-2.38-1.39c-.78-.45-1.17-.68-1.3-.97a1 1 0 0 1 0-.82c.13-.3.52-.52 1.3-.97l2.39-1.4c.15-.08.22-.12.29-.18l.15-.16q.07-.09.18-.3z"/><path d="M17.46 19.4c-.25-.31-.38-.47-.43-.65a1 1 0 0 1 0-.5c.05-.18.18-.34.43-.66l.81-1.02c.26-.31.39-.47.53-.53a.5.5 0 0 1 .4 0c.14.06.27.22.52.53l.82 1.02c.25.32.38.48.43.66q.06.25 0 .5c-.05.18-.18.34-.43.66l-.82 1.02c-.25.31-.38.47-.52.53a.5.5 0 0 1-.4 0c-.14-.06-.27-.22-.53-.53z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.58 5.76c.46-.89.69-1.34 1-1.48a1 1 0 0 1 .84 0c.31.14.54.6 1 1.48l1.2 2.32q.1.21.17.3l.15.16c.07.06.14.1.3.19l2.38 1.39c.78.45 1.17.68 1.3.97a1 1 0 0 1 0 .82c-.13.3-.52.52-1.3.97l-2.39 1.39-.29.19-.15.16q-.08.09-.18.3l-1.19 2.32c-.46.89-.69 1.34-1 1.48a1 1 0 0 1-.84 0c-.31-.14-.54-.6-1-1.48l-1.2-2.32-.17-.3-.15-.16c-.07-.06-.14-.1-.3-.19l-2.38-1.39c-.78-.45-1.17-.68-1.3-.97a1 1 0 0 1 0-.82c.13-.3.52-.52 1.3-.97l2.39-1.39c.15-.09.22-.13.29-.19l.15-.16q.07-.09.18-.3z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.46 19.4c-.25-.31-.38-.47-.43-.65a1 1 0 0 1 0-.5c.05-.18.18-.34.43-.66l.81-1.02c.26-.31.39-.47.53-.53a.5.5 0 0 1 .4 0c.14.06.27.22.52.53l.82 1.02c.25.32.38.48.43.66q.06.25 0 .5c-.05.18-.18.34-.43.66l-.82 1.02c-.25.31-.38.47-.52.53a.5.5 0 0 1-.4 0c-.14-.06-.27-.22-.53-.53z"/>
    </svg>
  );
}
