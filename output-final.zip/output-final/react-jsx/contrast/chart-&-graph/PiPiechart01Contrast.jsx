import React from 'react';

/**
 * PiPiechart01Contrast icon from the contrast style in chart-&-graph category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPiechart01Contrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'piechart-01 icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12.04 10.6V4.27c0-.75.61-1.37 1.36-1.26 3.9.59 7 3.68 7.59 7.6.1.74-.51 1.35-1.26 1.35H13.4c-.75 0-1.36-.61-1.36-1.36" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.33 15.57a9.05 9.05 0 1 1-11.9-11.9m3.61.6v6.33c0 .75.61 1.36 1.36 1.36h6.33c.75 0 1.37-.61 1.26-1.36a9.05 9.05 0 0 0-7.6-7.59c-.74-.1-1.35.51-1.35 1.26"/>
    </svg>
  );
}
