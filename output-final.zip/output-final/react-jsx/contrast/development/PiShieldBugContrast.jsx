import React from 'react';

/**
 * PiShieldBugContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiShieldBugContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'shield-bug icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m5.5 4.31 5.38-1.94a3 3 0 0 1 2.04 0l5.47 1.97a3 3 0 0 1 1.97 2.6l.23 2.94a11 11 0 0 1-5.73 10.52l-1.5.8a3 3 0 0 1-2.9-.03l-1.53-.86a11 11 0 0 1-5.54-9.98l.13-3.31a3 3 0 0 1 1.98-2.7" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.26 9.02A1.33 1.33 0 0 0 12 7.24a1.33 1.33 0 0 0-1.26 1.78m2.52 0h.86q.3.31.54.71m-1.4-.71h-2.52m0 0H9.9q-.33.31-.55.71M16 7.56v.8c0 .64-.45 1.2-1.07 1.32l-.27.05M8 7.56v.8c0 .64.45 1.2 1.07 1.32l.27.05m7.1 5.51v-1.13c0-.63-.44-1.18-1.07-1.3l-.48-.1m-7.33 2.53v-1.13c0-.63.44-1.18 1.07-1.3l.48-.1m5.78 0a3.5 3.5 0 0 0-.23-2.98m.23 2.98A3.1 3.1 0 0 1 12 14.8c-1.3 0-2.43-.87-2.89-2.1m0 0a3.5 3.5 0 0 1 .23-2.97m1.54-7.36L5.5 4.3a3 3 0 0 0-1.98 2.71l-.13 3.3a11 11 0 0 0 5.54 9.99l1.52.86a3 3 0 0 0 2.92.04l1.49-.81a11 11 0 0 0 5.73-10.52l-.23-2.95a3 3 0 0 0-1.97-2.59l-5.47-1.97a3 3 0 0 0-2.04 0"/>
    </svg>
  );
}
