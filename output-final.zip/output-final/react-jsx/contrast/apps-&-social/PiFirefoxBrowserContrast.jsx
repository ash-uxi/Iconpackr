import React from 'react';

/**
 * PiFirefoxBrowserContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiFirefoxBrowserContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'firefox-browser icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12.03 21.81c-7.06 0-12.4-7.98-8.96-14.3a8 8 0 0 1 2.78-2.98q-.08 1.3.34 2.53h.03a8 8 0 0 1 2.37-1.85q-.1.57-.12 1.16c0 1.16.6 1.86 1.6 2.47a37 37 0 0 0 1.96 1.01c-.94 1.9-4.64 1.63-4.5 2.89 0 0 .55 3.68 4.42 3.68 1.43 0 4.26-.8 4.26-4.1a4.1 4.1 0 0 0-2.15-3.65 3.4 3.4 0 0 1 2.6.76c-.45-.83-1.22-1.24-1.94-2-1.65-2.22-2.06-4.74.43-6.27 1.29 2.74 4.08 4.5 5.14 7.36q-.27-1.55-.96-2.95S22 7.13 22 11.9a10.15 10.15 0 0 1-9.97 9.9" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12.03 21.81c-7.06 0-12.4-7.98-8.96-14.3a8 8 0 0 1 2.78-2.98q-.08 1.3.34 2.53h.03a8 8 0 0 1 2.37-1.85q-.1.57-.12 1.16c0 1.16.6 1.86 1.6 2.47a37 37 0 0 0 1.96 1.01c-.94 1.9-4.64 1.63-4.5 2.89 0 0 .55 3.68 4.42 3.68 1.43 0 4.26-.8 4.26-4.1a4.1 4.1 0 0 0-2.15-3.65 3.4 3.4 0 0 1 2.6.76c-.45-.83-1.22-1.24-1.94-2-1.65-2.22-2.06-4.74.43-6.27 1.29 2.74 4.08 4.5 5.14 7.36q-.27-1.55-.96-2.95S22 7.13 22 11.9a10.15 10.15 0 0 1-9.97 9.9"/>
    </svg>
  );
}
