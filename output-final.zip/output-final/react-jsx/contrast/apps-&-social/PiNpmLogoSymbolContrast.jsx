import React from 'react';

/**
 * PiNpmLogoSymbolContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiNpmLogoSymbolContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'npm-logo-symbol icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M10.4 20h3.2c2.24 0 3.36 0 4.22-.44a4 4 0 0 0 1.74-1.74c.44-.86.44-1.98.44-4.22v-3.2c0-2.24 0-3.36-.44-4.22a4 4 0 0 0-1.74-1.74C16.96 4 15.84 4 13.6 4h-3.2c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C4 7.04 4 8.16 4 10.4v3.2c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.86.44 1.98.44 4.22.44" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 11v9m0 0h-3.6c-2.24 0-3.36 0-4.22-.44a4 4 0 0 1-1.74-1.74C4 16.96 4 15.84 4 13.6v-3.2c0-2.24 0-3.36.44-4.22a4 4 0 0 1 1.74-1.74C7.04 4 8.16 4 10.4 4h3.2c2.24 0 3.36 0 4.22.44a4 4 0 0 1 1.74 1.74c.44.86.44 1.98.44 4.22v3.2c0 2.24 0 3.36-.44 4.22a4 4 0 0 1-1.74 1.74c-.8.41-1.84.44-3.82.44"/>
    </svg>
  );
}
