import React from 'react';

/**
 * PiWindowPictureInPictureContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiWindowPictureInPictureContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'window-picture-in-picture icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" fillRule="evenodd" d="M19.36 4.33C18.72 4 17.88 4 16.2 4H7.8c-1.68 0-2.52 0-3.16.33a3 3 0 0 0-1.31 1.3C3 6.29 3 7.13 3 8.8v6.4c0 1.68 0 2.52.33 3.16a3 3 0 0 0 1.3 1.31c.65.33 1.49.33 3.17.33h1.46q-.18-.57-.23-1.17C9 18.45 9 18.03 9 17.67v-2.34c0-.36 0-.79.03-1.16q.06-.9.46-1.71a4.5 4.5 0 0 1 3.68-2.43c.38-.03.8-.03 1.16-.03h4.34c.36 0 .78 0 1.16.03q.48.02 1.17.23V8.8c0-1.68 0-2.52-.33-3.16a3 3 0 0 0-1.3-1.31" clipRule="evenodd" opacity=".28"/><path fill="currentColor" fillRule="evenodd" d="M21.97 15.4v-.03q0-.6-.03-1.03-.03-.52-.25-.97a2.5 2.5 0 0 0-1.09-1.1q-.45-.21-.97-.25-.5-.02-1.03-.02h-4.27q-.59 0-1.03.03-.52.02-.97.24a2.5 2.5 0 0 0-1.1 1.1q-.21.46-.24.96-.03.45-.02 1.04v2.27q0 .59.02 1.03.01.47.25.97.37.72 1.1 1.09.49.22.96.25.45.03 1.03.02h4.27q.6 0 1.03-.02.48-.03.97-.25a2.5 2.5 0 0 0 1.1-1.1q.21-.46.24-.96.04-.45.03-1.03z" clipRule="evenodd"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 9.22V7a3 3 0 0 0-3-3H6a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h2.22"/>
    </svg>
  );
}
