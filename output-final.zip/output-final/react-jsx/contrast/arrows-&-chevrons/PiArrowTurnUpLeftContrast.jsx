import React from 'react';

/**
 * PiArrowTurnUpLeftContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowTurnUpLeftContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-turn-up-left icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M8.86 4a25 25 0 0 0-4.69 4.5.8.8 0 0 0 0 1A25 25 0 0 0 8.86 14a24 24 0 0 1-.3-8.13c.06-.47.14-.94.3-1.87" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.35 9H12c2.8 0 4.2 0 5.27.54a5 5 0 0 1 2.18 2.19C20 12.8 20 14.2 20 17v3M8.35 9a24 24 0 0 1 .2-3.13L8.86 4a25 25 0 0 0-4.68 4.5.8.8 0 0 0 0 1A25 25 0 0 0 8.86 14a24 24 0 0 1-.5-5"/>
    </svg>
  );
}
