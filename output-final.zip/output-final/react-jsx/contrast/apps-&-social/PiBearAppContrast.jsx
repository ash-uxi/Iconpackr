import React from 'react';

/**
 * PiBearAppContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBearAppContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'bear-app icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M10.96 4.24c-.36-.6-1.85-1.48-2.6-1.18-.63.25-.57 1.09-.57 2.38C6.66 7 6.34 7.18 5.51 9.04 4.36 11.6 3.15 14.7 2.42 21h15.4c-.92-1.9-2.28-3.01-3.1-6.37-.57-2.37 2.84-1.83 4.1-2.3A4.1 4.1 0 0 0 21.5 9.4c.3-1.88-.34-1.5-1.09-1.63-1.09-.18-3.06-1.18-4.57-2.67-1.04-1.02-2.66-1.04-4.88-.86" opacity=".28"/><path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M10.96 4.24c-.36-.6-1.85-1.48-2.6-1.18-.63.25-.57 1.09-.57 2.38C6.66 7 6.34 7.18 5.51 9.04 4.36 11.6 3.15 14.7 2.42 21h15.4c-.92-1.9-2.28-3.01-3.1-6.37-.57-2.37 2.84-1.83 4.1-2.3A4.1 4.1 0 0 0 21.5 9.4c.3-1.88-.34-1.5-1.09-1.63-1.09-.18-3.06-1.18-4.57-2.67-1.04-1.02-2.66-1.04-4.88-.86Z"/>
    </svg>
  );
}
