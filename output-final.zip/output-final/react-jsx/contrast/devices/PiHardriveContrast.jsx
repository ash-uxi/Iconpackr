import React from 'react';

/**
 * PiHardriveContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiHardriveContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'hardrive icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M17 12H7c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-2.88 2.26c.3-1.26.9-3.16 1.5-5.26.54-1.92.82-2.87 1.3-3.5A4 4 0 0 1 7.65 4.3C8.38 4 9.31 4 11.18 4h1.93c1.75 0 2.62 0 3.36.3a4 4 0 0 1 1.64 1.26c.48.63.71 1.47 1.17 3.16l1.54 5.68a3.5 3.5 0 0 0-2.93-2.38C17.7 12 17.46 12 17 12" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m20.82 14.4-1.54-5.68c-.46-1.69-.69-2.53-1.17-3.16a4 4 0 0 0-1.64-1.26C15.73 4 14.86 4 13.1 4h-1.93c-1.87 0-2.8 0-3.53.3a4 4 0 0 0-1.63 1.23c-.48.62-.76 1.57-1.3 3.5-.6 2.09-1.2 4-1.5 5.25m17.6.12a3.5 3.5 0 0 0-2.93-2.38C17.7 12 17.46 12 17 12H7c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-2.88 2.26m17.6.12q.12.34.16.7c.02.2.02.44.02.9s0 .7-.02.9a3.5 3.5 0 0 1-3.09 3.08c-.2.02-.43.02-.89.02H7c-.46 0-.7 0-.9-.02a3.5 3.5 0 0 1-3.08-3.09C3 16.7 3 16.46 3 16s0-.7.02-.9q.05-.42.2-.82M17 16h-4"/>
    </svg>
  );
}
