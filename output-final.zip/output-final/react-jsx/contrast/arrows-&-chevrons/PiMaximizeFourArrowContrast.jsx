import React from 'react';

/**
 * PiMaximizeFourArrowContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMaximizeFourArrowContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'maximize-four-arrow icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g opacity=".28"><path fill="currentColor" d="M4.58 4.08q2.37-.23 4.75.18L8.1 5.3a24 24 0 0 0-2.8 2.8L4.26 9.33a19 19 0 0 1-.18-4.75.56.56 0 0 1 .5-.5"/><path fill="currentColor" d="M14.67 4.26q2.38-.4 4.75-.18a.55.55 0 0 1 .5.5q.23 2.37-.17 4.75L18.7 8.1a24 24 0 0 0-2.81-2.8z"/><path fill="currentColor" d="M14.67 19.74q2.38.4 4.75.18a.56.56 0 0 0 .5-.5q.22-2.37-.18-4.75L18.7 15.9a24 24 0 0 1-2.8 2.8z"/><path fill="currentColor" d="M9.33 19.74q-2.38.4-4.75.18a.56.56 0 0 1-.5-.5q-.23-2.37.17-4.75L5.3 15.9a24 24 0 0 0 2.81 2.8z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.58 4.08q2.37-.23 4.75.18L8.1 5.3a24 24 0 0 0-2.8 2.8L4.26 9.33a19 19 0 0 1-.18-4.75.56.56 0 0 1 .5-.5"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.42 4.08a19 19 0 0 0-4.75.18L15.9 5.3a24 24 0 0 1 2.8 2.8l1.05 1.23q.39-2.38.18-4.75a.55.55 0 0 0-.5-.5"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.42 19.92q-2.37.22-4.75-.18l1.23-1.04a24 24 0 0 0 2.8-2.8l1.04-1.23q.4 2.38.18 4.75a.56.56 0 0 1-.5.5"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.58 19.92q2.37.22 4.75-.18L8.1 18.7a24 24 0 0 1-2.8-2.8l-1.05-1.23a19 19 0 0 0-.18 4.75.56.56 0 0 0 .5.5"/>
    </svg>
  );
}
