import React from 'react';

/**
 * PiXComContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiXComContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'x-com icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M7.56 4h-1.5c-.66 0-1 0-1.18.14a.7.7 0 0 0-.26.5c0 .23.19.5.57 1.04l9.5 13.42c.24.33.36.5.5.61q.22.16.46.24c.18.05.38.05.79.05h1.5c.66 0 1 0 1.18-.14q.23-.19.26-.5c0-.23-.19-.5-.57-1.04L9.3 4.9c-.24-.33-.36-.5-.5-.61q-.21-.16-.46-.24C8.17 4 7.97 4 7.56 4" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m18.67 4-5.53 6.32M4.67 20l5.9-6.74m2.57-2.94L9.3 4.9c-.23-.33-.35-.5-.5-.61q-.2-.16-.45-.24C8.17 4 7.97 4 7.56 4h-1.5c-.66 0-1 0-1.18.14a.7.7 0 0 0-.26.5c0 .23.19.5.57 1.04l5.37 7.58m2.58-2.94 5.67 8c.38.54.58.81.57 1.04q-.02.31-.26.5c-.18.14-.52.14-1.18.14h-1.5c-.4 0-.6 0-.8-.05a1 1 0 0 1-.44-.24 3 3 0 0 1-.5-.61l-4.14-5.84"/>
    </svg>
  );
}
