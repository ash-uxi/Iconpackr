import React from 'react';

/**
 * PiTruckDefaultContrast icon from the contrast style in automotive category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTruckDefaultContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'truck-default icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M11.8 5.5H5.2c-1.12 0-1.68 0-2.1.22a2 2 0 0 0-.88.87C2 7.02 2 7.58 2 8.7v6.6c0 1.12 0 1.68.22 2.1q.3.58.87.88c.57.29 1.3.22 1.91.22a2 2 0 1 1 4 0h6v-10c0-.99-.01-1.5-.22-1.9a2 2 0 0 0-.87-.88c-.43-.22-.99-.22-2.11-.22" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 18.5v-10m0 10a2 2 0 1 0 4 0m-4 0a2 2 0 1 1 4 0m-4 0H9m10 0c.61 0 1.34.07 1.9-.22a2 2 0 0 0 .88-.87c.22-.43.22-.99.22-2.11v-1.8l-1.2-2.99a5 5 0 0 0-.67-1.36 2 2 0 0 0-.79-.52c-.33-.13-.72-.13-1.5-.13H15m-6 10a2 2 0 1 1-4 0m4 0a2 2 0 1 0-4 0m0 0c-.61 0-1.34.07-1.9-.22a2 2 0 0 1-.88-.87C2 16.98 2 16.42 2 15.3V8.7c0-1.12 0-1.68.22-2.1a2 2 0 0 1 .87-.88c.43-.22.99-.22 2.11-.22h6.6c1.12 0 1.68 0 2.1.22q.58.3.88.87c.2.4.22.92.22 1.91"/>
    </svg>
  );
}
