import React from 'react';

/**
 * PiSpatialEnvironmentContrast icon from the contrast style in ar-&-vr category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSpatialEnvironmentContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'spatial-environment icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 17.13a29 29 0 0 0-1.75.5A1 1 0 0 1 2 16.68V4.3a1 1 0 0 1 1.25-.92l.09.02.65.2A29 29 0 0 0 20 3.6l.65-.2.09-.02A1 1 0 0 1 22 4.3v12.4a1 1 0 0 1-1.34.9l-.65-.2-1.01-.27M17 21a3 3 0 0 0-3-3h-4a3 3 0 0 0-3 3m7.5-8.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0"/><path fill="currentColor" d="M2 4.4v-.1a1 1 0 0 1 1.34-.9l.65.19a29 29 0 0 0 16.02 0l.65-.2q.07 0 .09-.02A1 1 0 0 1 22 4.3v12.4a1 1 0 0 1-1.25.93l-.09-.03-.65-.19A29 29 0 0 0 4 17.4l-.65.2-.09.02A1 1 0 0 1 2 16.69z" opacity=".35"/>
    </svg>
  );
}
