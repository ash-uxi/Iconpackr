import React from 'react';

/**
 * PiHomeHLineContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiHomeHLineContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'home-h-line icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M3 12.76c0-1.02 0-1.53.12-2a4 4 0 0 1 .51-1.2c.27-.4.64-.76 1.38-1.45l2.6-2.46c1.54-1.46 2.32-2.2 3.2-2.47a4 4 0 0 1 2.38 0c.88.28 1.66 1.01 3.2 2.47L19 8.11c.74.7 1.11 1.04 1.38 1.46a4 4 0 0 1 .51 1.19c.12.47.12.98.12 2v1.84c0 2.24 0 3.36-.44 4.22a4 4 0 0 1-1.74 1.74c-.86.44-1.98.44-4.22.44H9.4c-2.24 0-3.36 0-4.22-.44a4 4 0 0 1-1.74-1.74C3 17.96 3 16.84 3 14.6z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17h6M7.6 5.65 5 8.11c-.73.7-1.1 1.04-1.37 1.46a4 4 0 0 0-.51 1.19c-.12.47-.12.98-.12 2v1.84c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.86.44 1.98.44 4.22.44h5.2c2.24 0 3.36 0 4.22-.44a4 4 0 0 0 1.74-1.74c.44-.86.44-1.98.44-4.22v-1.84c0-1.02 0-1.53-.12-2a4 4 0 0 0-.51-1.2 9 9 0 0 0-1.38-1.45l-2.6-2.46c-1.54-1.46-2.32-2.2-3.2-2.47a4 4 0 0 0-2.38 0c-.88.28-1.66 1.01-3.2 2.47"/>
    </svg>
  );
}
