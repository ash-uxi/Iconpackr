import React from 'react';

/**
 * PiEraserDefaultContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiEraserDefaultContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'eraser-default icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m17.9 5.8.3.3c1.27 1.27 1.9 1.9 2.14 2.64.21.64.21 1.34 0 1.98-.23.74-.87 1.37-2.14 2.64l-3.22 3.23-7.56-7.57 3.22-3.22c1.27-1.27 1.9-1.9 2.64-2.14a3.2 3.2 0 0 1 1.98 0c.73.23 1.37.87 2.64 2.14" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m14.27 17.3-.9.9c-1.28 1.27-1.91 1.9-2.65 2.14-.64.21-1.34.21-1.98 0-.73-.23-1.37-.87-2.64-2.14l-.3-.3c-1.27-1.27-1.9-1.9-2.14-2.64a3.2 3.2 0 0 1 0-1.98c.23-.74.87-1.37 2.14-2.64l.9-.9m7.57 7.55 3.93-3.93c1.27-1.27 1.9-1.9 2.14-2.64.21-.64.21-1.34 0-1.98-.23-.73-.87-1.37-2.14-2.64l-.3-.3c-1.27-1.27-1.9-1.9-2.64-2.14a3.2 3.2 0 0 0-1.98 0c-.74.23-1.37.87-2.64 2.14L6.7 9.73m7.56 7.56L6.7 9.73"/>
    </svg>
  );
}
