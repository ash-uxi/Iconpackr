import React from 'react';

/**
 * PiMaximizeLineArrowContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMaximizeLineArrowContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'maximize-line-arrow icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M19.92 4.65q.25 2.64-.2 5.3l-1.43-1.67a24 24 0 0 0-2.57-2.57L14.06 4.3q2.65-.45 5.3-.2a.6.6 0 0 1 .56.56"/><path d="M4.09 19.35q-.25-2.63.2-5.3l1.42 1.67a24 24 0 0 0 2.57 2.57l1.66 1.42q-2.65.45-5.3.2a.6.6 0 0 1-.55-.56"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6.95 17.05q-.64-.64-1.24-1.33L4.3 14.06q-.45 2.65-.2 5.3a.6.6 0 0 0 .56.55q2.64.25 5.3-.2L8.27 18.3a24 24 0 0 1-1.33-1.24m0 0 10.1-10.1m0 0q.64.64 1.24 1.33l1.43 1.66q.45-2.65.2-5.3a.6.6 0 0 0-.56-.55q-2.65-.25-5.3.2l1.66 1.42q.69.6 1.33 1.24"/>
    </svg>
  );
}
