import React from 'react';

/**
 * PiScaleContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiScaleContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'scale icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M20.34 6.2 17.8 3.66c-.8-.8-1.19-1.2-1.65-1.34a2 2 0 0 0-1.23 0c-.46.15-.85.54-1.65 1.34l-9.61 9.61c-.8.8-1.2 1.2-1.34 1.65a2 2 0 0 0 0 1.23c.15.46.54.86 1.34 1.65l2.54 2.54c.8.8 1.19 1.2 1.65 1.34a2 2 0 0 0 1.23 0c.46-.15.86-.54 1.65-1.34l9.61-9.61c.8-.8 1.2-1.2 1.34-1.65a2 2 0 0 0 0-1.23c-.15-.46-.54-.86-1.34-1.65" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m4.22 12.7 3.54 3.54m2.12-9.19 3.53 3.54m-.7-6.37 2.12 2.12M7.05 9.88 9.17 12m-5.51 5.8 2.54 2.54c.8.8 1.19 1.2 1.65 1.34a2 2 0 0 0 1.23 0c.46-.15.86-.54 1.65-1.34l9.61-9.61c.8-.8 1.2-1.2 1.34-1.65a2 2 0 0 0 0-1.23c-.15-.46-.54-.86-1.34-1.65L17.8 3.66c-.8-.8-1.19-1.2-1.65-1.34a2 2 0 0 0-1.23 0c-.46.15-.85.54-1.65 1.34l-9.61 9.61c-.8.8-1.2 1.2-1.34 1.65a2 2 0 0 0 0 1.23c.15.46.54.86 1.34 1.65"/>
    </svg>
  );
}
