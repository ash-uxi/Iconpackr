import React from 'react';

/**
 * PiBuildingApartmentBigContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBuildingApartmentBigContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'building-apartment-big icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M15.8 2H8.2c-1.12 0-1.68 0-2.1.22a2 2 0 0 0-.88.87C5 3.52 5 4.08 5 5.2v15.2c0 .56 0 .84.1 1.05a1 1 0 0 0 .45.44c.21.11.49.11 1.05.11h10.8c.56 0 .84 0 1.05-.1a1 1 0 0 0 .44-.45c.11-.21.11-.49.11-1.05V5.2c0-1.12 0-1.68-.22-2.1a2 2 0 0 0-.87-.88C17.48 2 16.92 2 15.8 2" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 6h2m-2 4h2m-2 4h2M8 6h2m-2 4h2m-2 4h2m6 8v-2.4c0-.56 0-.84-.1-1.05a1 1 0 0 0-.45-.44c-.21-.11-.49-.11-1.05-.11H9.6c-.56 0-.84 0-1.05.1a1 1 0 0 0-.44.45C8 18.76 8 19.04 8 19.6V22m8 0h1.4c.56 0 .84 0 1.05-.1a1 1 0 0 0 .44-.45c.11-.21.11-.49.11-1.05V5.2c0-1.12 0-1.68-.22-2.1a2 2 0 0 0-.87-.88C17.48 2 16.92 2 15.8 2H8.2c-1.12 0-1.68 0-2.1.22a2 2 0 0 0-.88.87C5 3.52 5 4.08 5 5.2v15.2c0 .56 0 .84.1 1.05a1 1 0 0 0 .45.44c.21.11.49.11 1.05.11H8m8 0H8"/>
    </svg>
  );
}
