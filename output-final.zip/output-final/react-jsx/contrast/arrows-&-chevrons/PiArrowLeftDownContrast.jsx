import React from 'react';

/**
 * PiArrowLeftDownContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowLeftDownContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-left-down icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M5.6 17.57q-.44-3.9.14-7.8l4.03 4.46 4.46 4.03q-3.9.57-7.8.15a.95.95 0 0 1-.84-.84" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.77 14.23 5.74 9.77q-.57 3.9-.15 7.8a.95.95 0 0 0 .84.84q3.9.42 7.8-.15zm0 0L18.6 5.4"/>
    </svg>
  );
}
