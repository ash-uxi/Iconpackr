import React from 'react';

/**
 * PiBuildingApartmentOneContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBuildingApartmentOneContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'building-apartment-one icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M13.8 2H9.2c-1.12 0-1.68 0-2.1.22a2 2 0 0 0-.88.87C6 3.52 6 4.08 6 5.2v15.2c0 .56 0 .84.1 1.05a1 1 0 0 0 .45.44c.21.11.49.11 1.05.11h7.8c.56 0 .84 0 1.05-.1a1 1 0 0 0 .44-.45c.11-.21.11-.49.11-1.05V5.2c0-1.12 0-1.68-.22-2.1a2 2 0 0 0-.87-.88C15.48 2 14.92 2 13.8 2" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6h3m-3 4h3m-3 4h3m-3 4h3M9.2 2h4.6c1.12 0 1.68 0 2.1.22q.58.3.88.87c.22.43.22.99.22 2.11v15.2c0 .56 0 .84-.1 1.05a1 1 0 0 1-.45.44c-.21.11-.49.11-1.05.11H7.6c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45C6 21.24 6 20.96 6 20.4V5.2c0-1.12 0-1.68.22-2.1a2 2 0 0 1 .87-.88C7.52 2 8.08 2 9.2 2"/>
    </svg>
  );
}
