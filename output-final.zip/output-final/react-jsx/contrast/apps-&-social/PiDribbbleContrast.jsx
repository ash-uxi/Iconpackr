import React from 'react';

/**
 * PiDribbbleContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiDribbbleContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'dribbble icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M21 12a9 9 0 1 0-18 0 9 9 0 0 0 18 0" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12.2 9.42A16.4 16.4 0 0 1 3 11.54m9.18-2.12a35 35 0 0 1 1.67 3.68m-1.67-3.68a35 35 0 0 0-3.72-5.7m3.72 5.7a17 17 0 0 0 5.19-4.64m-3.52 8.32a16.5 16.5 0 0 1 7.13-.58m-7.13.58q1.3 3.4 1.89 7.08m-1.9-7.08a16.4 16.4 0 0 0-8.01 5.46M8.47 3.72a9 9 0 0 1 8.9 1.06m-8.9-1.06A9 9 0 0 0 3 11.54m14.37-6.76a9 9 0 0 1 3.6 7.74m0 0a9 9 0 0 1-5.23 7.66m0 0a9 9 0 0 1-9.91-1.62m0 0A9 9 0 0 1 3 11.54"/>
    </svg>
  );
}
