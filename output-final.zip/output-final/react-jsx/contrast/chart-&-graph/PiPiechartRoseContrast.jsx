import React from 'react';

/**
 * PiPiechartRoseContrast icon from the contrast style in chart-&-graph category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPiechartRoseContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'piechart-rose icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M11 2.86c5.6 0 10.13 4.54 10.13 10.14h-1.27c0 4.9-3.97 8.86-8.87 8.86v-1.1A7.76 7.76 0 0 1 3.24 13h1.1A6.65 6.65 0 0 1 11 6.35z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.86 13c0 4.9-3.97 8.86-8.87 8.86v-1.1M19.86 13h1.27C21.13 7.4 16.6 2.86 11 2.86v3.5M19.86 13h-8.87m0 7.76A7.76 7.76 0 0 1 3.24 13h1.1M11 20.76V13m-6.64 0A6.65 6.65 0 0 1 11 6.35M4.35 13h6.64m0-6.65V13"/>
    </svg>
  );
}
