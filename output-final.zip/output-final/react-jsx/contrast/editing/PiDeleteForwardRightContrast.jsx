import React from 'react';

/**
 * PiDeleteForwardRightContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiDeleteForwardRightContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'delete-forward-right icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M21.8 11.3a33 33 0 0 0-4.43-5.28 4 4 0 0 0-.78-.67c-.2-.12-.48-.23-.71-.28C15.6 5 15.32 5 14.76 5H7c-1.4 0-2.1 0-2.63.27a2.5 2.5 0 0 0-1.1 1.1C3 6.9 3 7.6 3 9v6c0 1.4 0 2.1.27 2.64q.37.72 1.1 1.09C4.9 19 5.6 19 7 19h7.76c.56 0 .84 0 1.12-.07.23-.05.5-.16.71-.28a4 4 0 0 0 .78-.67 33 33 0 0 0 4.42-5.29q.21-.31.21-.69t-.2-.7" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m8 15 3-3m0 0 3-3m-3 3L8 9m3 3 3 3m3.37-8.98a33 33 0 0 1 4.42 5.29q.21.31.21.69t-.2.7a33 33 0 0 1-4.43 5.28 4 4 0 0 1-.78.67c-.2.12-.48.23-.71.28-.28.07-.56.07-1.12.07H7c-1.4 0-2.1 0-2.63-.27a2.5 2.5 0 0 1-1.1-1.1C3 17.1 3 16.4 3 15V9c0-1.4 0-2.1.27-2.63a2.5 2.5 0 0 1 1.1-1.1C4.9 5 5.6 5 7 5h7.76c.56 0 .84 0 1.12.07.23.05.5.16.71.28a4 4 0 0 1 .78.67"/>
    </svg>
  );
}
