import React from 'react';

/**
 * PiBulbOnContrast icon from the contrast style in appliances category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBulbOnContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'bulb-on icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12 5a5.6 5.6 0 0 0-5.69 5.47c0 1.65.77 3.14 1.98 4.14.5.43.95.95 1.11 1.6l.23.87c.14.54.63.91 1.18.91h2.38c.56 0 1.04-.37 1.18-.9l.23-.88c.16-.65.6-1.17 1.11-1.6a5.4 5.4 0 0 0 1.98-4.14A5.6 5.6 0 0 0 12 4.99" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.38 21h3.24M12 2V1m7 3.7.7-.7m-15 .7L4 4m18 7h-1M3 11H2m4.31-.53A5.6 5.6 0 0 1 12 4.99a5.6 5.6 0 0 1 5.69 5.48c0 1.65-.77 3.14-1.98 4.14-.5.43-.95.95-1.11 1.6l-.23.87c-.14.54-.62.91-1.18.91h-2.38c-.56 0-1.04-.37-1.18-.9l-.23-.88a3 3 0 0 0-1.11-1.6 5.4 5.4 0 0 1-1.98-4.14"/>
    </svg>
  );
}
