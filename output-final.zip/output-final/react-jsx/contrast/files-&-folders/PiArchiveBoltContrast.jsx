import React from 'react';

/**
 * PiArchiveBoltContrast icon from the contrast style in files-&-folders category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArchiveBoltContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'archive-bolt icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 8a1 1 0 0 0-.9-1H4a1 1 0 0 1-.63-.23l-.08-.06A1 1 0 0 1 3 6V4.9a1 1 0 0 1 .23-.53l.06-.08A1 1 0 0 1 3.9 4H20a1 1 0 0 1 .63.23l.08.06A1 1 0 0 1 21 5v1a1 1 0 0 1-1 1 1 1 0 0 0-1 1v9a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 8h16M4 8v9a4 4 0 0 0 4 4h8a4 4 0 0 0 4-4V8M4 8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v1a2 2 0 0 1-2 2"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m12 11-2.25 3a.5.5 0 0 0 .48.8l3.54-.6a.5.5 0 0 1 .48.8L12 18"/>
    </svg>
  );
}
