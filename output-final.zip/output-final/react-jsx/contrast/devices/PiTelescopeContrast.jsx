import React from 'react';

/**
 * PiTelescopeContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTelescopeContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'telescope icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g opacity=".28"><path fill="currentColor" d="m18 11.8-4.04.8a2 2 0 0 1-1.07 2.19 2 2 0 0 1-2.85-1.4l-6.2 1.23a1 1 0 0 1-1.16-.72l-.55-2.05a1 1 0 0 1 .64-1.2L16.46 6z"/><path fill="currentColor" d="m22.32 12.43-1.93.52a2 2 0 0 1-2.45-1.41l-1.41-5.28a2 2 0 0 1 1.4-2.45l1.94-.51z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12.9 14.8 16 21m-8 0 3.1-6.2"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16.52 6.26a2 2 0 0 1 1.42-2.45l1.93-.52 2.45 9.14-1.93.52a2 2 0 0 1-2.45-1.42z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m4.51 10.05-1.74.59a1 1 0 0 0-.64 1.2l.55 2.06a1 1 0 0 0 1.16.72l6.15-1.22m-5.48-3.35L16.45 6M4.51 10.05 4.1 8.5M18 11.8l-4 .8"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 13a2 2 0 1 1-4 0 2 2 0 0 1 4 0"/>
    </svg>
  );
}
