import React from 'react';

/**
 * PiTrendlineDownSquareContrast icon from the contrast style in chart-&-graph category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTrendlineDownSquareContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'trendline-down-square icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M13 3h-2c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19C3 6.8 3 8.2 3 11v2c0 2.8 0 4.2.54 5.27a5 5 0 0 0 2.19 2.18C6.8 21 8.2 21 11 21h2c2.8 0 4.2 0 5.27-.55a5 5 0 0 0 2.18-2.18C21 17.2 21 15.8 21 13v-2c0-2.8 0-4.2-.55-5.27a5 5 0 0 0-2.18-2.19C17.2 3 15.8 3 13 3" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 9a9 9 0 0 0 3.79 4.58l.25.15 1.92-3.46.25.15A9 9 0 0 1 17 15M11 3h2c2.8 0 4.2 0 5.27.54a5 5 0 0 1 2.18 2.19C21 6.8 21 8.2 21 11v2c0 2.8 0 4.2-.55 5.27a5 5 0 0 1-2.18 2.18C17.2 21 15.8 21 13 21h-2c-2.8 0-4.2 0-5.27-.55a5 5 0 0 1-2.19-2.18C3 17.2 3 15.8 3 13v-2c0-2.8 0-4.2.54-5.27a5 5 0 0 1 2.19-2.19C6.8 3 8.2 3 11 3"/>
    </svg>
  );
}
