import React from 'react';

/**
 * PiAutomationContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAutomationContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'automation icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".3"><path d="M15 18c0-.93 0-1.4.15-1.77a2 2 0 0 1 1.08-1.08C16.6 15 17.07 15 18 15s1.4 0 1.77.15a2 2 0 0 1 1.08 1.08c.15.37.15.84.15 1.77s0 1.4-.15 1.77a2 2 0 0 1-1.08 1.08c-.37.15-.84.15-1.77.15s-1.4 0-1.77-.15a2 2 0 0 1-1.08-1.08C15 19.4 15 18.93 15 18"/><path d="M14.85 6a3.15 3.15 0 1 1 6.3 0 3.15 3.15 0 0 1-6.3 0"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 18H9A6 6 0 0 1 9 6h5.85M11 18a.6.6 0 0 0-.13-.37 13 13 0 0 0-2.2-2.13M11 18q0 .2-.13.37a13 13 0 0 1-2.2 2.13M14.84 6a3.15 3.15 0 1 0 6.3 0 3.15 3.15 0 0 0-6.3 0M18 21c-.93 0-1.4 0-1.77-.15a2 2 0 0 1-1.08-1.08C15 19.4 15 18.93 15 18s0-1.4.15-1.77a2 2 0 0 1 1.08-1.08C16.6 15 17.07 15 18 15s1.4 0 1.77.15a2 2 0 0 1 1.08 1.08c.15.37.15.84.15 1.77s0 1.4-.15 1.77a2 2 0 0 1-1.08 1.08c-.37.15-.84.15-1.77.15"/>
    </svg>
  );
}
