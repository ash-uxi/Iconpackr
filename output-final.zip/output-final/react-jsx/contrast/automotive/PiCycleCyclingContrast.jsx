import React from 'react';

/**
 * PiCycleCyclingContrast icon from the contrast style in automotive category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCycleCyclingContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'cycle-cycling icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M17.5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4"/><path d="M5.5 20.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/><path d="M21.5 17.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m11.5 19.5 1.03-4.12a2 2 0 0 0-1.39-2.41l-1.36-.4a2.01 2.01 0 0 1-.66-3.5 3 3 0 0 1 3.87.12l1.14 1.03a4 4 0 0 0 2.02.97l1.85.31M17.5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m1 12.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-13 0a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
    </svg>
  );
}
