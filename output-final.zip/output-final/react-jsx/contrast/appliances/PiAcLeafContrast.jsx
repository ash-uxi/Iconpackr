import React from 'react';

/**
 * PiAcLeafContrast icon from the contrast style in appliances category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAcLeafContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'ac-leaf icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M20 4H4a2 2 0 0 0-2 2v6h20V6a2 2 0 0 0-2-2"/><path d="M16.68 16.07c-1.48.85-2.03 2.65-1.39 3.76s2.48 1.53 3.95.68 3.04-3.97 2.72-4.53c-.32-.55-3.81-.76-5.28.1"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 8h-2m-1.2 14 .04-.11a6 6 0 0 1 2.32-2.96M22 12V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v6zm-5.32 4.07c-1.48.85-2.03 2.65-1.39 3.76s2.48 1.53 3.95.68 3.04-3.97 2.72-4.53c-.32-.55-3.81-.76-5.28.1"/>
    </svg>
  );
}
