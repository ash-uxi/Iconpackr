import React from 'react';

/**
 * PiTinderContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTinderContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'tinder icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" fillRule="evenodd" d="M8.83 9.66c3.62-1.25 4.24-4.5 3.78-7.5 0-.1.1-.18.18-.15 3.48 1.7 7.38 5.4 7.38 10.96 0 4.26-3.3 8.02-8.1 8.02A7.72 7.72 0 0 1 7.72 6.7c.09-.07.21 0 .21.1.05.57.2 2 .84 2.87z" clipRule="evenodd" opacity=".28"/><path fillRule="evenodd" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.83 9.66c3.62-1.25 4.24-4.5 3.78-7.5 0-.1.1-.18.18-.15 3.48 1.7 7.38 5.4 7.38 10.96 0 4.26-3.3 8.02-8.1 8.02A7.72 7.72 0 0 1 7.72 6.7c.09-.07.21 0 .21.1.05.57.2 2 .84 2.87z" clipRule="evenodd"/>
    </svg>
  );
}
