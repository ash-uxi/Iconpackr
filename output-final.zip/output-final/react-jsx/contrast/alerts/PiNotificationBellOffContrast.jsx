import React from 'react';

/**
 * PiNotificationBellOffContrast icon from the contrast style in alerts category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiNotificationBellOffContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'notification-bell-off icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".35"><path d="M12 2a8.2 8.2 0 0 0-8.18 7.53l-.35 4.26a5 5 0 0 1-.32 1.24 2.6 2.6 0 0 0 2.17 3.4l1.05.1a1 1 0 0 0 .8-.29L18.62 6.8a1 1 0 0 0 .11-1.28A8.2 8.2 0 0 0 12 2"/><path fillRule="evenodd" d="M20.2 9.71a1 1 0 0 0-1.7-.62l-9.71 9.7a1 1 0 0 0-.18 1.18 3.84 3.84 0 0 0 7.2-1.3q1.44-.09 2.87-.25a2.6 2.6 0 0 0 2.17-3.39 6 6 0 0 1-.32-1.24zm-8.58 9.08 2.12-.02a1.84 1.84 0 0 1-2.91.81z" clipRule="evenodd"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m6.47 17.53-1.04-.1a1.6 1.6 0 0 1-1.33-2.08c.16-.49.32-.97.36-1.48l.36-4.26a7.2 7.2 0 0 1 13.1-3.52M6.46 17.53 17.9 6.1M6.47 17.53 3 21M17.91 6.09 21 3m-1.8 6.8.34 4.07c.04.52.2 1 .37 1.48a1.6 1.6 0 0 1-1.34 2.08 60 60 0 0 1-7.36.36L9.49 19.5a2.84 2.84 0 0 0 5.35-1.34v-.35"/>
    </svg>
  );
}
