import React from 'react';

/**
 * PiCommandCmdCircleContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCommandCmdCircleContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'command-cmd-circle icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M21.15 12a9.15 9.15 0 1 1-18.3 0 9.15 9.15 0 0 1 18.3 0" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.33 13.67H8.67a1.67 1.67 0 1 0 1.66 1.66zm0 0h3.34m-3.34 0v-3.34m3.34 3.34h1.66a1.67 1.67 0 1 1-1.66 1.66zm0 0v-3.34m0 0V8.67a1.67 1.67 0 1 1 1.66 1.66zm0 0h-3.34m0 0H8.67a1.67 1.67 0 1 1 1.66-1.66zM21.15 12a9.15 9.15 0 1 1-18.3 0 9.15 9.15 0 0 1 18.3 0"/>
    </svg>
  );
}
