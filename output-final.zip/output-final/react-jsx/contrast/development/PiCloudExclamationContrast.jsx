import React from 'react';

/**
 * PiCloudExclamationContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCloudExclamationContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'cloud-exclamation icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12.5 3a7.5 7.5 0 0 1 6.9 4.49l.07.14.08.07.12.09.5.35A6.5 6.5 0 0 1 16.5 20h-10A5.5 5.5 0 0 1 3.6 9.82L5 8.94l.05-.05.02-.05.1-.23q.13-.29.34-.85A7.5 7.5 0 0 1 12.5 3" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6.51 7.97a6.5 6.5 0 0 1 11.73-.51l.42.75c.1.14.07.1.2.22q.09.08.75.53A5.5 5.5 0 0 1 16.5 19M6.51 7.97l-.04.11m.04-.11-.04.1v.01m0 0a6.5 6.5 0 0 0-.3 3.92m.3-3.92c-.33.8-.49 1.2-.57 1.32-.15.24-.03.1-.24.3-.1.1-.58.39-1.53.97A4.5 4.5 0 0 0 6.5 19m5.5-2v-6m0 9.01V20"/>
    </svg>
  );
}
