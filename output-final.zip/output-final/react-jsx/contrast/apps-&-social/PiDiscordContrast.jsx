import React from 'react';

/**
 * PiDiscordContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiDiscordContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'discord icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M21.91 16.5C19.93 20 16.5 20 16.5 20l-1.17-2.43c-2.44.74-4.2.74-6.64 0L7.5 20s-3.44 0-5.42-3.5l-.07-.24C2 14.9 1.63 8.4 5.5 5.5c1.1-.76 2.47-1.21 3.12-1.4.23-.06.46.05.56.25l.68 1.37a.5.5 0 0 0 .45.28h3.38a.5.5 0 0 0 .45-.28l.68-1.37c.1-.2.33-.31.56-.25.65.19 2.03.64 3.12 1.4 3.87 2.9 3.5 9.39 3.48 10.76z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 6h2.7a.5.5 0 0 0 .44-.28l.68-1.37c.1-.2.33-.31.56-.25.65.19 2.03.64 3.12 1.4 3.87 2.9 3.5 9.39 3.48 10.76l-.07.24C19.93 20 16.5 20 16.5 20l-1.17-2.43M13 6h-2.69a.5.5 0 0 1-.45-.28l-.68-1.37a.5.5 0 0 0-.56-.25c-.65.19-2.03.64-3.12 1.4C1.63 8.4 2 14.89 2.02 16.26q0 .13.07.24C4.07 20 7.5 20 7.5 20l1.17-2.43M7 17q.9.34 1.68.57M17 17q-.9.34-1.68.57m-6.64 0c2.44.74 4.2.74 6.64 0M10 12a1 1 0 1 1-2 0 1 1 0 0 1 2 0m6 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
    </svg>
  );
}
