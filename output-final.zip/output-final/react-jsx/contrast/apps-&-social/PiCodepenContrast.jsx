import React from 'react';

/**
 * PiCodepenContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCodepenContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'codepen icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m20.64 7.61-7-4.55a3 3 0 0 0-3.28 0l-7 4.55A3 3 0 0 0 2 10.13v3.74a3 3 0 0 0 1.37 2.52l7 4.55a3 3 0 0 0 3.27 0l7-4.55A3 3 0 0 0 22 13.87v-3.74a3 3 0 0 0-1.36-2.52" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 21.42v-6.58m0-12.26v6.58m9.66 6.1L13.72 9.7a3 3 0 0 0-3.44 0l-7.94 5.56m19.32 0a3 3 0 0 0 .34-1.39v-3.74a3 3 0 0 0-.34-1.4m0 6.53a3 3 0 0 1-1.02 1.13l-7 4.55a3 3 0 0 1-3.28 0l-7-4.55a3 3 0 0 1-1.02-1.13m19.32-6.52-7.94 5.56a3 3 0 0 1-3.44 0L2.34 8.74m19.32 0a3 3 0 0 0-1.02-1.13l-7-4.55a3 3 0 0 0-3.28 0l-7 4.55a3 3 0 0 0-1.02 1.13m0 0A3 3 0 0 0 2 10.13v3.74q0 .75.34 1.4"/>
    </svg>
  );
}
