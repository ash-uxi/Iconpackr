import React from 'react';

/**
 * PiProjectorContrast icon from the contrast style in appliances category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiProjectorContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'projector icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M2.15 10.23C2 10.6 2 11.07 2 12s0 1.4.15 1.77a2 2 0 0 0 1.08 1.08C3.6 15 4.07 15 5 15h4.35a4 4 0 0 1 0-6H5c-.93 0-1.4 0-1.77.15a2 2 0 0 0-1.08 1.08"/><path d="M21.85 13.77c.15-.37.15-.84.15-1.77s0-1.4-.15-1.77a2 2 0 0 0-1.08-1.08C20.4 9 19.93 9 19 9h-4.35a4 4 0 0 1 0 6H19c.93 0 1.4 0 1.77-.15a2 2 0 0 0 1.08-1.08"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15c-.93 0-1.4 0-1.77-.15a2 2 0 0 1-1.08-1.08C2 13.4 2 12.93 2 12s0-1.4.15-1.77a2 2 0 0 1 1.08-1.08C3.6 9 4.07 9 5 9h4.35M5 15h4.35M5 15v1m14-1c.93 0 1.4 0 1.77-.15a2 2 0 0 0 1.08-1.08c.15-.37.15-.84.15-1.77s0-1.4-.15-1.77a2 2 0 0 0-1.08-1.08C20.4 9 19.93 9 19 9h-4.35M19 15h-4.35M19 15v1m-4.35-7a4 4 0 0 0-5.3 0m5.3 0a4 4 0 0 1 0 6m0 0a4 4 0 0 1-5.3 0m0 0a4 4 0 0 1 0-6m9.66 3H19"/>
    </svg>
  );
}
