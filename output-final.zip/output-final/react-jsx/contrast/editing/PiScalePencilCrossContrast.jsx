import React from 'react';

/**
 * PiScalePencilCrossContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiScalePencilCrossContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'scale-pencil-cross icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M3 3h2.73c.39 0 .58 0 .76.04q.25.05.46.2c.16.1.3.23.58.5l3.15 3.17-3.7 3.7L3.8 7.43c-.27-.27-.4-.4-.5-.56a2 2 0 0 1-.18-.44c-.05-.18-.05-.37-.06-.75z"/><path d="m20.5 16.78-3.42-3.44-3.7 3.7 3.48 3.5c.53.52 1.34.61 1.97.2a6 6 0 0 0 1.93-1.96 1.6 1.6 0 0 0-.2-1.94z"/><path d="M13.64 3.95c.8-.8 1.2-1.2 1.66-1.35.4-.13.84-.13 1.24 0 .46.15.86.55 1.66 1.35l1.85 1.85c.8.8 1.2 1.2 1.35 1.66q.2.62 0 1.24c-.15.46-.55.86-1.35 1.66l-2.97 2.98-3.7 3.7-3.02 3.01c-.8.8-1.2 1.2-1.66 1.35q-.62.2-1.24 0c-.46-.15-.86-.55-1.66-1.35L3.95 18.2c-.8-.8-1.2-1.2-1.35-1.66q-.2-.62 0-1.24c.15-.46.55-.86 1.35-1.66l3.03-3.03 3.7-3.7z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m4.52 13.07 2.85 2.85m2.85-8.55 2.85 2.85m0-5.7 2.14 2.13m-7.84 3.57 2.14 2.14m7.57.98 2.97-2.98c.8-.8 1.2-1.2 1.35-1.66q.2-.62 0-1.24c-.15-.46-.55-.86-1.35-1.66L18.2 3.95c-.8-.8-1.2-1.2-1.66-1.35q-.62-.2-1.24 0c-.46.15-.86.55-1.66 1.35L10.68 6.9m6.4 6.43-3.7 3.7m3.7-3.7 3.42 3.44.06.06c.5.53.58 1.33.2 1.94a6 6 0 0 1-1.93 1.97c-.63.4-1.44.31-1.97-.21l-3.48-3.5M10.68 6.9l-3.7 3.7m3.7-3.7L7.53 3.75a4 4 0 0 0-.58-.52q-.21-.12-.46-.19C6.31 3 6.12 3 5.73 3H3l.07 2.68c0 .38.01.57.06.75q.06.23.19.44c.1.16.22.29.49.56l3.17 3.18m0 0-3.03 3.03c-.8.8-1.2 1.2-1.35 1.66-.13.4-.13.84 0 1.24.15.46.55.86 1.35 1.66l1.85 1.85c.8.8 1.2 1.2 1.66 1.35.4.13.84.13 1.24 0 .46-.15.86-.55 1.66-1.35l3.02-3.01"/>
    </svg>
  );
}
