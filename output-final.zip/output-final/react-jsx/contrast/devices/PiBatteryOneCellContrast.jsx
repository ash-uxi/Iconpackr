import React from 'react';

/**
 * PiBatteryOneCellContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBatteryOneCellContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'battery-one-cell icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2 12c0-1.86 0-2.8.3-3.53A4 4 0 0 1 4.47 6.3C5.2 6 6.14 6 8 6h6c1.86 0 2.8 0 3.53.3a4 4 0 0 1 2.17 2.17c.3.73.3 1.67.3 3.53s0 2.8-.3 3.53a4 4 0 0 1-2.17 2.17c-.73.3-1.67.3-3.53.3H8c-1.86 0-2.8 0-3.53-.3a4 4 0 0 1-2.17-2.17C2 14.8 2 13.86 2 12" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 14c.46 0 .7 0 .89-.05a1.5 1.5 0 0 0 1.06-1.06c.05-.2.05-.43.05-.89s0-.7-.05-.89a1.5 1.5 0 0 0-1.06-1.06c-.2-.05-.43-.05-.89-.05M6 10v4m2 4h6c1.86 0 2.8 0 3.53-.3a4 4 0 0 0 2.17-2.17c.3-.73.3-1.67.3-3.53s0-2.8-.3-3.53a4 4 0 0 0-2.17-2.17C16.8 6 15.86 6 14 6H8c-1.86 0-2.8 0-3.53.3A4 4 0 0 0 2.3 8.47C2 9.2 2 10.14 2 12s0 2.8.3 3.53a4 4 0 0 0 2.17 2.17c.73.3 1.67.3 3.53.3"/>
    </svg>
  );
}
