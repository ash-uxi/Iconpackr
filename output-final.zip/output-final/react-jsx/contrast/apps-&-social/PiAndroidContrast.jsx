import React from 'react';

/**
 * PiAndroidContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAndroidContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'android icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M22 17.98V16A9.98 9.98 0 0 0 5.81 8.14 10 10 0 0 0 2 16v1.98q0 .02.02.02h19.96q.02 0 .02-.02" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m4 5 1.81 3.14M20 5l-1.81 3.14m-12.38 0a9.96 9.96 0 0 1 12.38 0m-12.38 0A10 10 0 0 0 2 16v1.98q0 .02.02.02h19.96q.02 0 .02-.02V16c0-3.19-1.5-6.03-3.81-7.86M9 13a1 1 0 1 1-2 0 1 1 0 0 1 2 0m8 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
    </svg>
  );
}
