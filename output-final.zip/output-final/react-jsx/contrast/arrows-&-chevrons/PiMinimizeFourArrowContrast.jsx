import React from 'react';

/**
 * PiMinimizeFourArrowContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMinimizeFourArrowContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'minimize-four-arrow icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g opacity=".28"><path fill="currentColor" d="M8.75 9.26Q6.38 9.47 4 9.08l1.23-1.04a24 24 0 0 0 2.8-2.81L9.09 4q.39 2.38.18 4.75a.56.56 0 0 1-.5.5"/><path fill="currentColor" d="M20 9.08q-2.38.39-4.75.18a.56.56 0 0 1-.5-.5q-.22-2.38.18-4.76l1.04 1.23a24 24 0 0 0 2.8 2.8z"/><path fill="currentColor" d="M8.76 14.74a19 19 0 0 0-4.76.18l1.23 1.04a24 24 0 0 1 2.8 2.81L9.09 20q.39-2.38.18-4.75a.55.55 0 0 0-.5-.5"/><path fill="currentColor" d="M15.25 14.74q2.37-.21 4.75.18l-1.23 1.04a24 24 0 0 0-2.8 2.81L14.91 20a19 19 0 0 1-.18-4.75.55.55 0 0 1 .5-.5"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.25 14.74q2.37-.21 4.75.18l-1.23 1.04a24 24 0 0 0-2.8 2.81L14.91 20a19 19 0 0 1-.18-4.75.55.55 0 0 1 .5-.5"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.76 14.74a19 19 0 0 0-4.76.18l1.23 1.04a24 24 0 0 1 2.8 2.81L9.09 20q.39-2.38.18-4.75a.55.55 0 0 0-.5-.5"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.25 9.26q2.37.21 4.75-.18l-1.23-1.04a24 24 0 0 1-2.8-2.81L14.93 4a19 19 0 0 0-.18 4.75.55.55 0 0 0 .5.5"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.75 9.26Q6.38 9.47 4 9.08l1.23-1.04a24 24 0 0 0 2.8-2.81L9.09 4q.39 2.38.18 4.75a.56.56 0 0 1-.5.5"/>
    </svg>
  );
}
