import React from 'react';

/**
 * PiExternalLinkCircleContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiExternalLinkCircleContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'external-link-circle icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M19.9 4.54q.25 2.45-.14 4.92L18.61 8.1a24 24 0 0 0-2.72-2.72l-1.34-1.15q2.46-.38 4.9-.14a.5.5 0 0 1 .45.44" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.97 13.5A7.1 7.1 0 0 1 12.9 20H12a8 8 0 0 1-8-8v-.89a7.1 7.1 0 0 1 6.5-7.08m6.8 2.66L10 14m7.3-7.3q.7.67 1.31 1.41l1.15 1.35q.4-2.47.14-4.92a.5.5 0 0 0-.44-.44 19 19 0 0 0-4.91.14l1.34 1.15q.74.62 1.42 1.3"/>
    </svg>
  );
}
