import React from 'react';

/**
 * PiAppleNewSiriContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAppleNewSiriContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'apple-new-siri icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <circle cx="12" cy="12" r="9.15" stroke="currentColor" strokeWidth="2"/><circle cx="12" cy="12" r="9.15" fill="currentColor" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="M11.4 15c-1.22.94-2.64 1.76-3.89 1.76a4.51 4.51 0 0 1 0-9.03c2.94 0 6.82 4.51 6.82 4.51s2.34 2.72 4.1 2.72a2.72 2.72 0 0 0 0-5.43q-.47 0-.97.22"/>
    </svg>
  );
}
