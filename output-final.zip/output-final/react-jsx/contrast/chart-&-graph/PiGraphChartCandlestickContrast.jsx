import React from 'react';

/**
 * PiGraphChartCandlestickContrast icon from the contrast style in chart-&-graph category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiGraphChartCandlestickContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'graph-chart-candlestick icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M7 11c0-.46 0-.7.05-.89a1.5 1.5 0 0 1 1.06-1.06C8.31 9 8.54 9 9 9s.7 0 .89.05c.52.14.92.54 1.06 1.06.05.2.05.43.05.89v2c0 .46 0 .7-.05.89a1.5 1.5 0 0 1-1.06 1.06c-.2.05-.43.05-.89.05s-.7 0-.89-.05a1.5 1.5 0 0 1-1.06-1.06C7 13.69 7 13.46 7 13z"/><path d="M15 7c0-.46 0-.7.05-.89a1.5 1.5 0 0 1 1.06-1.06c.2-.05.43-.05.89-.05s.7 0 .89.05c.52.14.92.54 1.06 1.06.05.2.05.43.05.89v2c0 .46 0 .7-.05.89a1.5 1.5 0 0 1-1.06 1.06c-.2.05-.43.05-.89.05s-.7 0-.89-.05a1.5 1.5 0 0 1-1.06-1.06C15 9.69 15 9.46 15 9z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21H7a4 4 0 0 1-4-4V3m6 3v3m0 8v-2m8-12v2m0 12v-6m-8 4c-.46 0-.7 0-.89-.05a1.5 1.5 0 0 1-1.06-1.06C7 13.69 7 13.46 7 13v-2c0-.46 0-.7.05-.89a1.5 1.5 0 0 1 1.06-1.06C8.31 9 8.54 9 9 9m0 6c.46 0 .7 0 .89-.05a1.5 1.5 0 0 0 1.06-1.06c.05-.2.05-.43.05-.89v-2c0-.46 0-.7-.05-.89a1.5 1.5 0 0 0-1.06-1.06C9.69 9 9.46 9 9 9m8 2c-.46 0-.7 0-.89-.05a1.5 1.5 0 0 1-1.06-1.06C15 9.69 15 9.46 15 9V7c0-.46 0-.7.05-.89a1.5 1.5 0 0 1 1.06-1.06c.2-.05.43-.05.89-.05m0 6c.46 0 .7 0 .89-.05a1.5 1.5 0 0 0 1.06-1.06c.05-.2.05-.43.05-.89V7c0-.46 0-.7-.05-.89a1.5 1.5 0 0 0-1.06-1.06C17.69 5 17.46 5 17 5"/>
    </svg>
  );
}
