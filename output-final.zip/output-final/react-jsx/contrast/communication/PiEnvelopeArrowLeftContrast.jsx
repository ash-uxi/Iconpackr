import React from 'react';

/**
 * PiEnvelopeArrowLeftContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiEnvelopeArrowLeftContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'envelope-arrow-left icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M14 4h-4c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19C2 7.8 2 9.2 2 12s0 4.2.54 5.27a5 5 0 0 0 2.19 2.18C5.8 20 7.2 20 10 20h3c0-.8.27-1.6.8-2.27a16 16 0 0 1 2.81-2.7 3 3 0 0 1 4.44.97h.8c.15-.93.15-2.17.15-4 0-2.8 0-4.2-.55-5.27a5 5 0 0 0-2.18-2.19C18.2 4 16.8 4 14 4" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.41 22.57a13 13 0 0 1-2.28-2.19A.6.6 0 0 1 16 20m2.41-2.57q-1.27.95-2.28 2.2A.6.6 0 0 0 16 20m0 0h6m-10 0h-2c-2.8 0-4.2 0-5.27-.55a5 5 0 0 1-2.19-2.18C2 16.2 2 14.8 2 12c0-2 0-3.28.2-4.24m19.6 0-5.5 3.5c-1.56 1-2.34 1.5-3.18 1.69a5 5 0 0 1-2.24 0c-.84-.2-1.62-.7-3.18-1.68l-5.5-3.5m19.6 0c.2.95.2 2.24.2 4.23 0 1.52 0 2.63-.09 3.5m-.1-7.74a4 4 0 0 0-.36-1.03 5 5 0 0 0-2.18-2.19C18.2 4 16.8 4 14 4h-4c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19 4 4 0 0 0-.34 1.03"/>
    </svg>
  );
}
