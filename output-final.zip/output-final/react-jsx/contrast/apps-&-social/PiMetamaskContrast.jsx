import React from 'react';

/**
 * PiMetamaskContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMetamaskContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'metamask icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M20.74 3.52q.54.28.74.85c.2.6.58 1.3.41 1.95l-1.14 4.53a4 4 0 0 0 .08 2.24l.86 2.57q.15.46.01.91l-.7 2.36a1.5 1.5 0 0 1-1.83 1.02l-2.36-.63a1.5 1.5 0 0 0-1.26.22l-1.65 1.18a1.5 1.5 0 0 1-.87.28h-2.04q-.48 0-.88-.28l-1.64-1.17a1.5 1.5 0 0 0-1.26-.23l-2.36.63a1.5 1.5 0 0 1-1.82-1.02l-.72-2.36a1.5 1.5 0 0 1 .01-.9l.86-2.58a4 4 0 0 0 .08-2.23L2.1 6.32c-.16-.65.2-1.33.4-1.93a1.5 1.5 0 0 1 1.88-.94l4.6 1.48q.22.07.46.07h4.82q.23 0 .45-.07l4.9-1.5a1.5 1.5 0 0 1 1.12.1" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21.89 6.32c.17-.66-.2-1.34-.41-1.95a1.5 1.5 0 0 0-1.86-.94l-4.9 1.5q-.23.07-.45.07H9.45a2 2 0 0 1-.46-.07l-4.6-1.48a1.5 1.5 0 0 0-1.88.94c-.2.6-.56 1.28-.4 1.93l1.14 4.54a4 4 0 0 1-.08 2.23l-.86 2.57q-.15.46 0 .9l.7 2.37a1.5 1.5 0 0 0 1.83 1.02l2.36-.63a1.5 1.5 0 0 1 1.26.23l1.64 1.17q.4.27.88.28h2.04q.47 0 .87-.28l1.65-1.18a1.5 1.5 0 0 1 1.26-.22l2.36.63A1.5 1.5 0 0 0 21 18.93l.71-2.36q.15-.46 0-.91l-.87-2.57a4 4 0 0 1-.08-2.24z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.5 12c0 .54-.46 1-1 1s-1-.46-1-1 .46-1 1-1 1 .46 1 1m7 0c0 .54-.46 1-1 1s-1-.46-1-1 .46-1 1-1 1 .46 1 1"/>
    </svg>
  );
}
