import React from 'react';

/**
 * PiBinanceContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBinanceContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'binance icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M9.37 12.81a1.15 1.15 0 0 1 0-1.62l1.82-1.81a1.15 1.15 0 0 1 1.62 0l1.81 1.81c.45.45.45 1.17 0 1.62l-1.81 1.81c-.45.45-1.17.45-1.62 0z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m3.41 13.72-.34-.34c-.76-.76-.76-2 0-2.76l.34-.34m17.18 0 .34.34c.76.76.76 2 0 2.76l-.34.34m-3.44 3.43-3.53 3.54c-.9.9-2.35.9-3.24 0l-3.53-3.54m10.3-10.3L13.62 3.3c-.9-.9-2.35-.9-3.24 0L6.85 6.85m5.96 7.77 1.81-1.81c.45-.45.45-1.17 0-1.62l-1.81-1.81a1.15 1.15 0 0 0-1.62 0l-1.82 1.81a1.15 1.15 0 0 0 0 1.62l1.82 1.81c.45.45 1.17.45 1.62 0"/>
    </svg>
  );
}
