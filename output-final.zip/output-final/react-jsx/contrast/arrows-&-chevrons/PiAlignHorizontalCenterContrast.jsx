import React from 'react';

/**
 * PiAlignHorizontalCenterContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAlignHorizontalCenterContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'align-horizontal-center icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M14.12 11.7q1.4-1.52 3.2-2.7-.3 3 0 6a16 16 0 0 1-3.2-2.7.4.4 0 0 1-.12-.3q0-.16.12-.3"/><path d="M9.88 12.3q-1.4 1.52-3.2 2.7.3-3 0-6 1.8 1.18 3.2 2.7.12.14.12.3t-.12.3"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.17 12H21m-3.83 0q0-1.5.15-3-1.8 1.18-3.2 2.7a.4.4 0 0 0-.12.3q0 .16.12.3 1.4 1.52 3.2 2.7-.15-1.5-.15-3M6.83 12H3m3.83 0q0 1.5-.15 3 1.8-1.18 3.2-2.7.12-.14.12-.3t-.12-.3q-1.4-1.52-3.2-2.7.15 1.5.15 3M12 5v14"/>
    </svg>
  );
}
