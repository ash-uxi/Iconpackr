import React from 'react';

/**
 * PiQrScanContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiQrScanContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'qr-scan icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M6 7.6c0-.56 0-.84.1-1.05a1 1 0 0 1 .45-.44C6.76 6 7.04 6 7.6 6h.8c.56 0 .84 0 1.05.1a1 1 0 0 1 .44.45c.11.21.11.49.11 1.05v.8c0 .56 0 .84-.1 1.05a1 1 0 0 1-.45.44c-.21.11-.49.11-1.05.11h-.8c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45C6 9.24 6 8.96 6 8.4z" opacity=".28"/><path fill="currentColor" d="M6 15.6c0-.56 0-.84.1-1.05a1 1 0 0 1 .45-.44C6.76 14 7.04 14 7.6 14h.8c.56 0 .84 0 1.05.1a1 1 0 0 1 .44.45c.11.21.11.49.11 1.05v.8c0 .56 0 .84-.1 1.05a1 1 0 0 1-.45.44c-.21.11-.49.11-1.05.11h-.8c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45C6 17.24 6 16.96 6 16.4z" opacity=".28"/><path fill="currentColor" d="M14 7.6c0-.56 0-.84.1-1.05a1 1 0 0 1 .45-.44C14.76 6 15.04 6 15.6 6h.8c.56 0 .84 0 1.05.1a1 1 0 0 1 .44.45c.11.21.11.49.11 1.05v.8c0 .56 0 .84-.1 1.05a1 1 0 0 1-.45.44c-.21.11-.49.11-1.05.11h-.8c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45C14 9.24 14 8.96 14 8.4z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.4 21c-2.24 0-3.36 0-4.22-.44a4 4 0 0 1-1.74-1.74C3 17.96 3 16.84 3 14.6m18 0c0 2.24 0 3.36-.44 4.22a4 4 0 0 1-1.74 1.74c-.86.44-1.98.44-4.22.44m0-18c2.24 0 3.36 0 4.22.44a4 4 0 0 1 1.74 1.74c.44.86.44 1.98.44 4.22M9.4 3c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C3 6.04 3 7.16 3 9.4"/><path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M6 7.6c0-.56 0-.84.1-1.05a1 1 0 0 1 .45-.44C6.76 6 7.04 6 7.6 6h.8c.56 0 .84 0 1.05.1a1 1 0 0 1 .44.45c.11.21.11.49.11 1.05v.8c0 .56 0 .84-.1 1.05a1 1 0 0 1-.45.44c-.21.11-.49.11-1.05.11h-.8c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45C6 9.24 6 8.96 6 8.4z"/><path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M6 15.6c0-.56 0-.84.1-1.05a1 1 0 0 1 .45-.44C6.76 14 7.04 14 7.6 14h.8c.56 0 .84 0 1.05.1a1 1 0 0 1 .44.45c.11.21.11.49.11 1.05v.8c0 .56 0 .84-.1 1.05a1 1 0 0 1-.45.44c-.21.11-.49.11-1.05.11h-.8c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45C6 17.24 6 16.96 6 16.4z"/><path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M14 7.6c0-.56 0-.84.1-1.05a1 1 0 0 1 .45-.44C14.76 6 15.04 6 15.6 6h.8c.56 0 .84 0 1.05.1a1 1 0 0 1 .44.45c.11.21.11.49.11 1.05v.8c0 .56 0 .84-.1 1.05a1 1 0 0 1-.45.44c-.21.11-.49.11-1.05.11h-.8c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45C14 9.24 14 8.96 14 8.4z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14h-2.5c-.83 0-1.5.67-1.5 1.5V18"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 17v.1"/>
    </svg>
  );
}
