import React from 'react';

/**
 * PiBatteryChargingContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBatteryChargingContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'battery-charging icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M7.96 5q-1.34-.01-2.22.04-.9.04-1.65.34a5 5 0 0 0-2.7 2.7c-.22.52-.3 1.05-.35 1.66q-.05.88-.04 2.22v.08q-.01 1.33.04 2.22.04.9.34 1.65a5 5 0 0 0 2.7 2.7c.52.22 1.05.3 1.66.35q.88.05 2.22.04h6.08q1.33.01 2.22-.04.9-.04 1.65-.34a5 5 0 0 0 2.7-2.7c.22-.52.3-1.05.35-1.66q.05-.88.04-2.22v-.08q.01-1.33-.04-2.22a5 5 0 0 0-.34-1.65 5 5 0 0 0-2.7-2.7 5 5 0 0 0-1.66-.35q-.89-.05-2.22-.04z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 14c.46 0 .7 0 .89-.05a1.5 1.5 0 0 0 1.06-1.06c.05-.2.05-.43.05-.89s0-.7-.05-.89a1.5 1.5 0 0 0-1.06-1.06c-.2-.05-.43-.05-.89-.05m-4-3.97c.65.03 1.12.1 1.53.27a4 4 0 0 1 2.17 2.17c.3.73.3 1.67.3 3.53s0 2.8-.3 3.53a4 4 0 0 1-2.17 2.17c-.59.24-1.3.29-2.53.3M7 6a7 7 0 0 0-2.53.3A4 4 0 0 0 2.3 8.47C2 9.2 2 10.14 2 12s0 2.8.3 3.53a4 4 0 0 0 2.17 2.17c.4.16.88.24 1.53.27M12 6l-3.83 4.98c-.37.48-.55.72-.54.9q.01.25.22.4c.16.1.45.06 1.05-.02l4.2-.52c.6-.08.9-.11 1.05-.01a.5.5 0 0 1 .22.39c.01.18-.17.42-.54.9L10 18"/>
    </svg>
  );
}
