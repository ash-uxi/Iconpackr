import React from 'react';

/**
 * PiExchange01Contrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiExchange01Contrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'exchange-01 icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M18.57 19.8q1.36-1.08 2.43-2.45l-.63.06a24 24 0 0 1-4.74 0l-.63-.06q1.06 1.36 2.43 2.45a.9.9 0 0 0 1.14 0"/><path d="M5.43 4.2Q4.07 5.28 3 6.65l.63-.06a24 24 0 0 1 4.74 0l.63.06Q7.94 5.29 6.57 4.2a.9.9 0 0 0-1.14 0"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 17.53V7a3 3 0 1 0-6 0v10a3 3 0 1 1-6 0V6.47m12 11.06a24 24 0 0 0 2.37-.12l.63-.06q-1.06 1.36-2.43 2.45a.9.9 0 0 1-1.14 0q-1.36-1.08-2.43-2.45l.63.06a24 24 0 0 0 2.37.12M6 6.47a24 24 0 0 0-2.37.12L3 6.65Q4.06 5.29 5.43 4.2a.9.9 0 0 1 1.14 0Q7.93 5.28 9 6.65l-.63-.06A24 24 0 0 0 6 6.47"/>
    </svg>
  );
}
