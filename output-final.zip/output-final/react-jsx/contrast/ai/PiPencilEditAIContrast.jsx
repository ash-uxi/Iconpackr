import React from 'react';

/**
 * PiPencilEditAIContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPencilEditAIContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'pencil-edit-ai icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M3.13 17.57c-.05.18-.05.37-.06.75L3 21h2.73c.39 0 .58 0 .76-.04q.25-.05.46-.2c.17-.1.3-.23.58-.5L20.5 7.21l.06-.06c.5-.53.58-1.33.2-1.94l-.05-.08-.03-.05a6 6 0 0 0-1.85-1.84 1.6 1.6 0 0 0-1.97.21L3.81 16.57c-.27.27-.4.4-.5.56a2 2 0 0 0-.18.44"/><path d="M22 18a4.5 4.5 0 0 1-3-3 4.5 4.5 0 0 1-3 3 4.5 4.5 0 0 1 3 3 4.5 4.5 0 0 1 3-3"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 21h2.73c.39 0 .58 0 .76-.04q.25-.05.46-.2c.17-.1.3-.23.58-.5L20.5 7.21c.53-.53.66-1.35.26-2a6 6 0 0 0-1.93-1.97 1.6 1.6 0 0 0-1.97.21L3.81 16.57c-.27.27-.4.4-.5.56a2 2 0 0 0-.18.44c-.05.18-.05.37-.06.75zm16-6a4.5 4.5 0 0 1-3 3 4.5 4.5 0 0 1 3 3 4.5 4.5 0 0 1 3-3 4.5 4.5 0 0 1-3-3"/>
    </svg>
  );
}
