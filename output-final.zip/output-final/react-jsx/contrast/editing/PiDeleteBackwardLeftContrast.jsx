import React from 'react';

/**
 * PiDeleteBackwardLeftContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiDeleteBackwardLeftContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'delete-backward-left icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2.2 11.3a33 33 0 0 1 4.43-5.28 2.7 2.7 0 0 1 1.5-.95C8.39 5 8.67 5 9.22 5H17c1.4 0 2.1 0 2.64.27q.72.37 1.09 1.1C21 6.9 21 7.6 21 9v6c0 1.4 0 2.1-.27 2.64a2.5 2.5 0 0 1-1.1 1.09C19.1 19 18.4 19 17 19H9.24c-.56 0-.84 0-1.12-.07a3 3 0 0 1-.71-.28 4 4 0 0 1-.78-.67 33 33 0 0 1-4.42-5.29Q2 12.38 2 12t.2-.7" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m16 15-3-3m0 0-3-3m3 3 3-3m-3 3-3 3M6.63 6.02a33 33 0 0 0-4.42 5.29Q2 11.62 2 12t.2.7a33 33 0 0 0 4.43 5.28 4 4 0 0 0 .78.67c.2.12.48.23.71.28.28.07.56.07 1.12.07H17c1.4 0 2.1 0 2.64-.27a2.5 2.5 0 0 0 1.09-1.1C21 17.1 21 16.4 21 15V9c0-1.4 0-2.1-.27-2.63a2.5 2.5 0 0 0-1.1-1.1C19.1 5 18.4 5 17 5H9.24c-.56 0-.84 0-1.12.07-.23.05-.5.16-.71.28a4 4 0 0 0-.78.67"/>
    </svg>
  );
}
