import React from 'react';

/**
 * PiAlignUpContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAlignUpContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'align-up icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M11.6 8.14a21 21 0 0 0-3.68 3.9q4.08-.35 8.16 0a21 21 0 0 0-3.68-3.9.64.64 0 0 0-.8 0" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11.87V20m0-8.13q-2.04 0-4.08.16a21 21 0 0 1 3.68-3.89.64.64 0 0 1 .8 0 21 21 0 0 1 3.68 3.9 51 51 0 0 0-4.08-.17M5 4h14"/>
    </svg>
  );
}
