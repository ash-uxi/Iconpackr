import React from 'react';

/**
 * PiArrowBigTurnLeftContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowBigTurnLeftContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-big-turn-left icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M3.24 11.3Q6.11 7.74 9.8 5a61 61 0 0 0-.33 4C17 9 21 12 21 19c-3-4-7-4-11.53-4q.09 2 .33 4a35 35 0 0 1-6.56-6.3 1.1 1.1 0 0 1 0-1.4" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3.24 11.3Q6.1 7.74 9.8 5a61 61 0 0 0-.33 4C17 9 21 12 21 19c-3-4-7-4-11.53-4q.09 2 .33 4a35 35 0 0 1-6.56-6.3 1.1 1.1 0 0 1 0-1.4"/>
    </svg>
  );
}
