import React from 'react';

/**
 * PiAppleIntelligenceContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAppleIntelligenceContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'apple-intelligence icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12 2.25c-2.5 0-3.1 3.67-3.1 3.67s-3.26-1.8-4.82.14c-1.55 1.95.94 4.73.94 4.73s-3.45 1.4-2.9 3.84 4.28 2.22 4.28 2.22-1.04 3.57 1.21 4.66 4.4-1.96 4.4-1.96 2.12 3.04 4.37 1.97c2.26-1.08 1.23-4.67 1.23-4.67s3.7.22 4.26-2.21S19 10.79 19 10.79s2.49-2.78.93-4.73-4.8-.14-4.8-.14S14.5 2.25 12 2.25" opacity=".28"/><path stroke="currentColor" strokeWidth="2" d="M12 19.55c.82-.47 1.63-.97 2.46-1.4l.52-.25c.86-.38 1.75-.7 2.63-1.05m-5.6 2.7S9.85 22.6 7.6 21.5s-1.2-4.66-1.2-4.66m5.6 2.7c-.9-.52-1.79-1.08-2.73-1.53s-1.92-.8-2.88-1.17m5.6 2.7s2.13 3.04 4.38 1.97c2.26-1.08 1.23-4.67 1.23-4.67m-11.2 0c-.15-.93-.27-1.87-.45-2.8l-.13-.55c-.23-.92-.54-1.81-.81-2.71m1.38 6.06s-3.72.22-4.27-2.22c-.56-2.44 2.89-3.84 2.89-3.84m0 0S2.52 8 4.08 6.06s4.81-.14 4.81-.14M5.02 10.8c.7-.77 1.44-1.5 2.09-2.31s1.2-1.7 1.78-2.56m0 0S9.5 2.25 12 2.25s3.11 3.67 3.11 3.67m-6.22 0c1.04.08 2.08.2 3.11.2 1.04 0 2.08-.12 3.11-.2m0 0c.59.86 1.14 1.74 1.78 2.55.65.82 1.4 1.55 2.1 2.32m-3.88-4.87s3.25-1.81 4.8.14C21.49 8 19 10.79 19 10.79m0 0s3.44 1.4 2.88 3.85c-.56 2.43-4.26 2.2-4.26 2.2M19 10.79c-.3.99-.65 1.97-.88 2.98s-.35 2.05-.5 3.08"/>
    </svg>
  );
}
