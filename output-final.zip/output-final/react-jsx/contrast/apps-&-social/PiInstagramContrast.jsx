import React from 'react';

/**
 * PiInstagramContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiInstagramContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'instagram icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M3.4 7.22c-.35 1.01-.35 2.27-.35 4.78s0 3.77.35 4.78a6.3 6.3 0 0 0 3.87 3.87c1 .35 2.26.35 4.78.35 2.51 0 3.77 0 4.78-.35a6.3 6.3 0 0 0 3.86-3.87c.36-1.01.36-2.27.36-4.78s0-3.77-.36-4.78a6.3 6.3 0 0 0-3.86-3.87C15.82 3 14.56 3 12.05 3s-3.77 0-4.78.35A6.3 6.3 0 0 0 3.4 7.22" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3.05 12c0-2.51 0-3.77.35-4.78a6.3 6.3 0 0 1 3.87-3.87C8.27 3 9.53 3 12.05 3c2.51 0 3.77 0 4.78.35a6.3 6.3 0 0 1 3.86 3.87c.36 1.01.36 2.27.36 4.78s0 3.77-.36 4.78a6.3 6.3 0 0 1-3.86 3.87c-1.01.35-2.27.35-4.78.35s-3.77 0-4.78-.35a6.3 6.3 0 0 1-3.87-3.87c-.35-1.01-.35-2.27-.35-4.78m12.77-.56a3.82 3.82 0 1 1-7.55 1.12 3.82 3.82 0 0 1 7.55-1.12"/>
    </svg>
  );
}
