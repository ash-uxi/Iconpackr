import React from 'react';

/**
 * PiBeachUmbrellaContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBeachUmbrellaContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'beach-umbrella icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M4.9 7.4a8.67 8.67 0 0 1 11.82-3.26 8.67 8.67 0 0 1 2.62 12.6l-.27-.3a6.8 6.8 0 0 0-3.79-2.19l-.4-.08-1.29-1.26a7 7 0 0 0-2.9-1.67l-1.74-.5-.27-.3A6.8 6.8 0 0 0 4.9 8.26l-.4-.08q.18-.4.4-.78" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 21h18"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16.72 4.14A8.67 8.67 0 0 0 4.5 8.18l.4.08a6.8 6.8 0 0 1 3.78 2.18l.27.3m7.77-6.6a8.67 8.67 0 0 1 2.62 12.6l-.27-.3a6.8 6.8 0 0 0-3.79-2.19l-.4-.08m1.84-10.03c-1.65-.95-4.94 1.66-7.35 5.84q-.22.38-.42.77m7.77-6.61c1.65.95 1.03 5.1-1.38 9.29l-.45.74m-5.94-3.42 1.74.48c1.1.31 2.1.89 2.9 1.68l1.3 1.26m-2.75-2.1L7 20.97"/>
    </svg>
  );
}
