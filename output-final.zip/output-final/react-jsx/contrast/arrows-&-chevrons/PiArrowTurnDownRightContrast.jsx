import React from 'react';

/**
 * PiArrowTurnDownRightContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowTurnDownRightContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-turn-down-right icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M15.14 20a25 25 0 0 0 4.69-4.5.8.8 0 0 0 0-1 25 25 0 0 0-4.69-4.5 24 24 0 0 1 .3 8.13c-.06.47-.14.94-.3 1.87" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.65 15H12c-2.8 0-4.2 0-5.27-.54a5 5 0 0 1-2.19-2.19C4 11.2 4 9.8 4 7V4m11.65 11a24 24 0 0 1-.2 3.13l-.3 1.87a25 25 0 0 0 4.68-4.5.8.8 0 0 0 0-1 25 25 0 0 0-4.69-4.5 24 24 0 0 1 .5 5"/>
    </svg>
  );
}
