import React from 'react';

/**
 * PiStoreDefaultContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiStoreDefaultContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'store-default icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 13.75a3.3 3.3 0 0 0 1.77-2.9c0-1.18-.22-2.35-.34-3.52-.12-1.24-.13-2.63-1.11-3.53-1-.92-2.4-.8-3.66-.8H7.34c-1.26 0-2.66-.12-3.66.8-.98.9-.99 2.29-1.11 3.53-.12 1.17-.34 2.34-.34 3.52 0 1.26.72 2.36 1.77 2.9m16 0q-.68.35-1.49.36a3.26 3.26 0 0 1-3.25-3.26 3.26 3.26 0 1 1-6.51 0A3.26 3.26 0 0 1 4 13.75m16 0v4.86c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.65c-.32.17-.74.17-1.58.17H6.4c-.84 0-1.26 0-1.58-.17a1.5 1.5 0 0 1-.66-.65C4 19.87 4 19.45 4 18.6v-4.86"/><path fill="currentColor" d="M21.43 7.33c.12 1.17.34 2.34.34 3.52a3.26 3.26 0 1 1-6.51 0 3.26 3.26 0 1 1-6.51 0 3.26 3.26 0 1 1-6.52 0c0-1.18.22-2.35.34-3.52.12-1.24.13-2.63 1.11-3.53 1-.92 2.4-.8 3.66-.8h9.32c1.26 0 2.66-.12 3.66.8.98.9.99 2.29 1.11 3.53" opacity=".28"/>
    </svg>
  );
}
