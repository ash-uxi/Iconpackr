import React from 'react';

/**
 * PiDemergeContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiDemergeContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'demerge icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M4.65 4.09q2.64-.25 5.3.2a53 53 0 0 0-5.66 5.65q-.45-2.65-.2-5.3a.6.6 0 0 1 .56-.55"/><path d="M14.06 4.29q2.65-.45 5.3-.2a.6.6 0 0 1 .55.56q.25 2.64-.2 5.3a53 53 0 0 0-5.65-5.66"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m7 7 5 5v8M7 7a53 53 0 0 1 2.95-2.7q-2.65-.45-5.3-.2a.6.6 0 0 0-.55.56q-.25 2.64.2 5.3A53 53 0 0 1 7 7m10 0-2 2m2-2a53 53 0 0 0-2.94-2.71q2.65-.45 5.3-.2a.6.6 0 0 1 .55.56q.25 2.64-.2 5.3Q18.41 8.41 17 7"/>
    </svg>
  );
}
