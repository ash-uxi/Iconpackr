import React from 'react';

/**
 * PiCameraAIContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCameraAIContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'camera-ai icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" fillRule="evenodd" d="M18.96 6.57c-.47-.15-1.05-.15-2.2-.15-.22 0-.33 0-.43-.02a1 1 0 0 1-.5-.27 2 2 0 0 1-.25-.34l-1.1-1.66c-.18-.26-.27-.4-.38-.49a1 1 0 0 0-.34-.18c-.15-.04-.3-.04-.62-.04h-2.28c-.32 0-.47 0-.62.04a1 1 0 0 0-.34.18c-.11.1-.2.23-.37.49L8.42 5.79q-.16.25-.25.34a1 1 0 0 1-.5.27c-.1.02-.21.02-.42.02-1.15 0-1.72 0-2.18.15a3 3 0 0 0-1.9 1.9 8 8 0 0 0-.15 2.18v4.97c0 1.68 0 2.52.32 3.16a3 3 0 0 0 1.31 1.31c.65.33 1.49.33 3.17.33h8.38c1.68 0 2.52 0 3.16-.33a3 3 0 0 0 1.31-1.31c.33-.64.33-1.48.33-3.16v-4.96c0-1.16 0-1.74-.16-2.2a3 3 0 0 0-1.88-1.89" clipRule="evenodd" opacity=".28"/><path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M16.76 6.42c1.15 0 1.73 0 2.2.15a3 3 0 0 1 1.88 1.89c.16.46.16 1.04.16 2.2v4.96c0 1.68 0 2.52-.33 3.16a3 3 0 0 1-1.3 1.31c-.65.33-1.49.33-3.17.33H7.82c-1.68 0-2.52 0-3.17-.33a3 3 0 0 1-1.3-1.31c-.33-.64-.33-1.48-.33-3.16v-4.97c0-1.15 0-1.72.15-2.18a3 3 0 0 1 1.9-1.9c.46-.15 1.03-.15 2.18-.15q.29 0 .41-.02a1 1 0 0 0 .5-.27q.1-.09.26-.34l1.1-1.66c.18-.26.27-.4.38-.49a1 1 0 0 1 .34-.18c.15-.04.3-.04.62-.04h2.28c.32 0 .47 0 .62.04a1 1 0 0 1 .34.18c.11.1.2.23.38.49l1.1 1.66q.16.25.25.34a1 1 0 0 0 .5.27c.1.02.21.02.43.02Z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12.47 9.6a4.5 4.5 0 0 1-3 3 4.5 4.5 0 0 1 3 3 4.5 4.5 0 0 1 3-3 4.5 4.5 0 0 1-3-3"/>
    </svg>
  );
}
