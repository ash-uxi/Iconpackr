import React from 'react';

/**
 * PiSwapArrowVerticalContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSwapArrowVerticalContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'swap-arrow-vertical icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M15.6 20.86a20 20 0 0 1-3.6-3.75l2.22.17a24 24 0 0 0 3.56 0L20 17.1a20 20 0 0 1-3.6 3.75.6.6 0 0 1-.8 0"/><path d="M4 6.89a20 20 0 0 1 3.6-3.75.6.6 0 0 1 .8 0A20 20 0 0 1 12 6.89l-2.22-.17a24 24 0 0 0-3.56 0z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 17.34V7m0 10.34a24 24 0 0 1-1.78-.06L12 17.1a20 20 0 0 0 3.6 3.75.6.6 0 0 0 .8 0A20 20 0 0 0 20 17.1l-2.22.17a24 24 0 0 1-1.78.06M8 6.66V17M8 6.66a24 24 0 0 0-1.78.06L4 6.9a20 20 0 0 1 3.6-3.75.6.6 0 0 1 .8 0A20 20 0 0 1 12 6.89l-2.22-.17A24 24 0 0 0 8 6.66"/>
    </svg>
  );
}
