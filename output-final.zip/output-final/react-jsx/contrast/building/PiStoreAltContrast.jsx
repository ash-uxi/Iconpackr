import React from 'react';

/**
 * PiStoreAltContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiStoreAltContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'store-alt icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M21.43 7.32c.12 1.17.34 2.35.34 3.53a3.26 3.26 0 1 1-6.51 0 3.26 3.26 0 1 1-6.51 0 3.26 3.26 0 1 1-6.52 0c0-1.18.22-2.36.34-3.53.12-1.24.13-2.63 1.11-3.53 1-.92 2.4-.79 3.66-.79h9.32c1.26 0 2.66-.13 3.66.8.98.9.99 2.28 1.11 3.52" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 21v-7.26m0 0q-.65.35-1.49.36a3.26 3.26 0 0 1-3.25-3.25c0 1.04-.5 1.97-1.26 2.57m6 .32a3.5 3.5 0 0 0 1.75-3.27l-.32-3.15C21.13 4.15 20.04 3 16.67 3H7.34C3.97 3 2.88 4.15 2.56 7.32l-.31 3.15A3.5 3.5 0 0 0 4 13.74m0 0q.65.35 1.49.36c1.8 0 3.25-1.46 3.25-3.25A3.26 3.26 0 0 0 14 13.42m-10 .32v4.86c0 .84 0 1.26.16 1.58q.23.43.66.66c.32.16.74.16 1.58.16h5.2c.84 0 1.26 0 1.58-.16q.43-.23.66-.66c.16-.32.16-.74.16-1.58v-5.18"/>
    </svg>
  );
}
