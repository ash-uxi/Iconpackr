import React from 'react';

/**
 * PiHomeSettingsContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiHomeSettingsContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'home-settings icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M3.12 10.76c-.12.47-.12.98-.12 2v1.84c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.86.44 1.98.44 4.22.44h2.78v-.14l-.01-.44-.31-.32a3 3 0 0 1 0-4.2l.3-.32.01-.44a3 3 0 0 1 2.97-2.97h.44l.32-.31a3 3 0 0 1 4.2 0l.32.3.44.01H21c0-.64-.03-1.04-.12-1.41a4 4 0 0 0-.51-1.2 9 9 0 0 0-1.38-1.45l-2.6-2.46c-1.54-1.46-2.32-2.2-3.2-2.47a4 4 0 0 0-2.38 0c-.88.28-1.66 1.01-3.2 2.47L5 8.11c-.74.7-1.11 1.04-1.38 1.46a4 4 0 0 0-.51 1.19"/><path d="m18.09 18-.03.06-.06.03-.06-.03-.03-.06.03-.06.06-.03.06.03z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 18h.01m-6.83 3H9.4c-2.24 0-3.36 0-4.22-.44a4 4 0 0 1-1.74-1.74C3 17.96 3 16.84 3 14.6v-1.84c0-1.02 0-1.53.12-2a4 4 0 0 1 .51-1.2c.27-.4.64-.76 1.38-1.45l2.6-2.46c1.54-1.46 2.32-2.2 3.2-2.47a4 4 0 0 1 2.38 0c.88.28 1.66 1.01 3.2 2.47L19 8.11c.74.7 1.11 1.04 1.38 1.46a4 4 0 0 1 .59 1.6M18 14l1.18 1.15 1.65.02.02 1.65L22 18l-1.15 1.18-.02 1.65-1.65.02L18 22l-1.18-1.15-1.65-.02-.02-1.65L14 18l1.15-1.18.02-1.65 1.65-.02z"/>
    </svg>
  );
}
