import React from 'react';

/**
 * PiPiechart02Contrast icon from the contrast style in chart-&-graph category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPiechart02Contrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'piechart-02 icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M20.2 11.5a7.42 7.42 0 0 0-9.91-7l-.2-.54c-.27-.78-1.14-1.2-1.87-.8A9.5 9.5 0 1 0 20.5 17.03c.49-.67.18-1.58-.56-1.95l-.52-.26q.77-1.52.78-3.32" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m10.29 4.5 2.28 6.43q.21.57.74.84l6.1 3.05M10.3 4.5a7.4 7.4 0 0 1 9.9 7 7.4 7.4 0 0 1-.78 3.32M10.3 4.5l-.2-.54c-.27-.78-1.14-1.2-1.87-.8A9.5 9.5 0 1 0 20.5 17.03c.49-.67.18-1.58-.56-1.95l-.52-.26"/>
    </svg>
  );
}
