import React from 'react';

/**
 * PiRepeatSquareContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiRepeatSquareContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'repeat-square icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M12 2q1.65 1.2 2.92 2.78a.4.4 0 0 1 0 .44A15 15 0 0 1 12 8l.06-.61a24 24 0 0 0 0-4.78z"/><path d="M9.08 18.78A15 15 0 0 1 12 16l-.06.61a24 24 0 0 0 0 4.78L12 22q-1.65-1.2-2.92-2.78a.4.4 0 0 1 0-.44"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12.18 5H10c-1.86 0-2.8 0-3.55.24a5 5 0 0 0-3.2 3.21C3 9.21 3 10.14 3 12s0 2.8.24 3.55A5 5 0 0 0 5 18m7.18-13a24 24 0 0 0-.12-2.39L12 2q1.65 1.2 2.92 2.78a.4.4 0 0 1 0 .44A15 15 0 0 1 12 8l.06-.61A24 24 0 0 0 12.18 5m-.36 14H14c1.86 0 2.8 0 3.55-.24a5 5 0 0 0 3.2-3.21c.25-.76.25-1.69.25-3.55s0-2.8-.24-3.55A5 5 0 0 0 19 6m-7.18 13q0-1.2.12-2.39L12 16q-1.65 1.2-2.92 2.78a.4.4 0 0 0 0 .44A15 15 0 0 0 12 22l-.06-.61a24 24 0 0 1-.12-2.39"/>
    </svg>
  );
}
