import React from 'react';

/**
 * PiControlTowerContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiControlTowerContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'control-tower icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M3.4 5.83A1.5 1.5 0 0 1 4.88 4h14.26c.96 0 1.67.89 1.46 1.83l-1.16 5.21A2.5 2.5 0 0 1 17 13H7.01a2.5 2.5 0 0 1-2.45-1.96z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3.4 5.83A1.5 1.5 0 0 1 4.88 4h14.26c.96 0 1.67.89 1.46 1.83l-1.16 5.21A2.5 2.5 0 0 1 17 13H7.01a2.5 2.5 0 0 1-2.45-1.96z"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 8h16"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m9 8 1 5"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m15 8-1 5"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4V2"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m7 13-.5 9M17 13l.5 9"/>
    </svg>
  );
}
