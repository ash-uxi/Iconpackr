import React from 'react';

/**
 * PiGitlabContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiGitlabContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'gitlab icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M8.12 8.09 6.35 2.93a.62.62 0 0 0-1.18 0l-2.39 7.09a5.35 5.35 0 0 0 1.64 5.83l6.27 5.18c.77.63 1.86.63 2.62 0l6.26-5.14a5.35 5.35 0 0 0 1.65-5.83l-2.4-7.13a.62.62 0 0 0-1.18 0l-1.76 5.16c-.14.42-.54.7-.98.7H9.1c-.44 0-.84-.28-.98-.7" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.12 8.09 6.35 2.93a.62.62 0 0 0-1.18 0l-2.39 7.09a5.35 5.35 0 0 0 1.64 5.83l6.27 5.18c.77.63 1.86.63 2.62 0l6.26-5.14a5.35 5.35 0 0 0 1.65-5.83l-2.4-7.13a.62.62 0 0 0-1.18 0l-1.76 5.16c-.14.42-.54.7-.98.7H9.1c-.44 0-.84-.28-.98-.7"/>
    </svg>
  );
}
