import React from 'react';

/**
 * PiCubeContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCubeContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'cube icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m18.5 5.64-4-2.22c-.91-.5-1.37-.76-1.85-.85a3 3 0 0 0-1.3 0c-.48.1-.94.35-1.84.85L5.49 5.64c-.9.5-1.36.75-1.69 1.1a3 3 0 0 0-.65 1.08C3 8.27 3 8.77 3 9.78v4.44c0 1 0 1.5.15 1.96q.21.6.65 1.08c.33.35.79.6 1.7 1.1l4 2.22c.91.5 1.37.76 1.85.85a3 3 0 0 0 1.3 0c.48-.1.94-.35 1.84-.85l4.02-2.22c.9-.5 1.36-.75 1.69-1.1q.45-.48.65-1.08c.15-.45.15-.95.15-1.96V9.78c0-1 0-1.5-.15-1.96a3 3 0 0 0-.65-1.08 7 7 0 0 0-1.7-1.1" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 12v9.5m0-9.5L3.34 7.39M12 12l8.66-4.61M12 21.5q.33 0 .65-.07c.48-.1.94-.35 1.84-.85l4.02-2.22c.9-.5 1.36-.75 1.69-1.1q.45-.48.65-1.08c.15-.45.15-.95.15-1.96V9.78c0-1 0-1.5-.15-1.96q-.08-.23-.19-.43M12 21.5q-.33 0-.65-.07c-.48-.1-.94-.35-1.84-.85l-4.02-2.22c-.9-.5-1.36-.75-1.69-1.1q-.45-.48-.65-1.08C3 15.73 3 15.23 3 14.22V9.78c0-1 0-1.5.15-1.96q.08-.23.19-.43m17.32 0a3 3 0 0 0-.46-.65 7 7 0 0 0-1.7-1.1l-4-2.22c-.91-.5-1.37-.76-1.85-.85a3 3 0 0 0-1.3 0c-.48.1-.94.35-1.84.85L5.49 5.64c-.9.5-1.36.75-1.69 1.1q-.27.3-.46.65"/>
    </svg>
  );
}
