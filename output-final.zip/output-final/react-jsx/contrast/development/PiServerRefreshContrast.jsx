import React from 'react';

/**
 * PiServerRefreshContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiServerRefreshContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'server-refresh icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M7 12c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 15.3 3 15.54 3 16s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02h2.38a13 13 0 0 1 .56-1.82 3.5 3.5 0 0 1 1.8-1.9 3 3 0 0 1 1-3.1 7 7 0 0 1 6-1.4 3.5 3.5 0 0 0 2.24-2.89C21 8.7 21 8.46 21 8s0-.7-.02-.9a3.5 3.5 0 0 0-3.09-3.08C17.7 4 17.46 4 17 4H7c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 7.3 3 7.54 3 8s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 12h5.65M7 12c-.46 0-.7 0-.9.02a3.5 3.5 0 0 0-3.08 3.09C3 15.3 3 15.54 3 16s0 .7.02.9a3.5 3.5 0 0 0 3.09 3.08c.2.02.43.02.89.02h1.38M7 12c-.46 0-.7 0-.9-.02a3.5 3.5 0 0 1-3.08-3.09C3 8.7 3 8.46 3 8s0-.7.02-.9a3.5 3.5 0 0 1 3.09-3.08C6.3 4 6.54 4 7 4h10c.46 0 .7 0 .9.02a3.5 3.5 0 0 1 3.08 3.09c.02.2.02.43.02.89s0 .7-.02.9a3.5 3.5 0 0 1-1.36 2.38m2.67 4.29a10 10 0 0 1-.67 2.36.5.5 0 0 1-.45.29m-2.4-.77a10 10 0 0 0 2.4.77m-5.57 1.46a10 10 0 0 0-2.4-.7m-1.08 2.68a10 10 0 0 1 .61-2.38c.08-.2.27-.32.47-.3m7.97-.76a4 4 0 0 0-6.52-2.71m-1.45 3.47a4.01 4.01 0 0 0 6.54 2.7M17 8h.01"/>
    </svg>
  );
}
