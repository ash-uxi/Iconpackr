import React from 'react';

/**
 * PiVercelContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiVercelContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'vercel icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path stroke="currentColor" strokeWidth="2" d="M11.14 3.47a1 1 0 0 1 1.72 0l8.25 14.02a1 1 0 0 1-.86 1.51H3.75a1 1 0 0 1-.86-1.5z"/><path fill="currentColor" d="M11.14 3.47a1 1 0 0 1 1.72 0l8.25 14.02a1 1 0 0 1-.86 1.51H3.75a1 1 0 0 1-.86-1.5z" opacity=".28"/>
    </svg>
  );
}
