import React from 'react';

/**
 * PiCloudCheckContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCloudCheckContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'cloud-check icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M22 14.5a5.5 5.5 0 0 1-5.5 5.5h-10a4.5 4.5 0 0 1-.48-8.97 6.5 6.5 0 0 1 12.65-1.59A5.5 5.5 0 0 1 22 14.5" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m9 13.6 2.34 2.34A15 15 0 0 1 15.9 11m.6 9a5.5 5.5 0 0 0 2.17-10.56 6.5 6.5 0 0 0-12.65 1.59A4.5 4.5 0 0 0 6.5 20z"/>
    </svg>
  );
}
