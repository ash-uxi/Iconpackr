import React from 'react';

/**
 * PiArrowBigDownContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowBigDownContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-big-down icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M10.6 3h2.8c.56 0 .84 0 1.05.11a1 1 0 0 1 .44.44c.11.21.11.5.11 1.05v9.93q2-.1 4-.33a35 35 0 0 1-6.3 6.55 1.1 1.1 0 0 1-1.4 0Q7.74 17.9 5 14.2q2 .24 4 .33V4.6c0-.56 0-.84.1-1.05a1 1 0 0 1 .45-.44c.21-.1.49-.1 1.05-.1" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.4 3h-2.8c-.56 0-.84 0-1.05.11a1 1 0 0 0-.44.44C9 3.76 9 4.05 9 4.6v9.93a61 61 0 0 1-4-.34 35 35 0 0 0 6.3 6.56 1.1 1.1 0 0 0 1.4 0q3.57-2.86 6.3-6.56a61 61 0 0 1-4 .34V4.6c0-.56 0-.84-.1-1.05a1 1 0 0 0-.45-.44c-.21-.1-.49-.1-1.05-.1"/>
    </svg>
  );
}
