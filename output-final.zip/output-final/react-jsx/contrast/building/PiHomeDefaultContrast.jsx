import React from 'react';

/**
 * PiHomeDefaultContrast icon from the contrast style in building category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiHomeDefaultContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'home-default icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M3 12.76c0-1.02 0-1.53.12-2a4 4 0 0 1 .51-1.2c.27-.4.64-.76 1.38-1.45l2.6-2.46c1.54-1.46 2.32-2.2 3.2-2.47a4 4 0 0 1 2.38 0c.88.28 1.66 1.01 3.2 2.47L19 8.11c.74.7 1.11 1.04 1.38 1.46a4 4 0 0 1 .51 1.19c.12.47.12.98.12 2v3.57c0 1.09 0 1.63-.12 2.08a3.5 3.5 0 0 1-2.47 2.47c-.45.12-1 .12-2.08.12-.3 0-.46 0-.59-.03a1 1 0 0 1-.7-.71c-.04-.13-.04-.28-.04-.6V17c0-.46 0-.7-.03-.9a2.5 2.5 0 0 0-2.08-2.07c-.2-.03-.44-.03-.9-.03s-.7 0-.9.03a2.5 2.5 0 0 0-2.07 2.08C9 16.3 9 16.54 9 17v2.67c0 .3 0 .46-.03.59a1 1 0 0 1-.71.7c-.13.04-.28.04-.6.04-1.08 0-1.62 0-2.07-.12a3.5 3.5 0 0 1-2.47-2.47C3 17.96 3 17.4 3 16.33z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 16.33v-3.57c0-1.02 0-1.53-.12-2a4 4 0 0 0-.51-1.2 9 9 0 0 0-1.38-1.45l-2.6-2.46c-1.54-1.46-2.32-2.2-3.2-2.47a4 4 0 0 0-2.38 0c-.88.28-1.66 1.01-3.2 2.47L5 8.11c-.74.7-1.11 1.04-1.38 1.46a4 4 0 0 0-.51 1.19c-.12.47-.12.98-.12 2v3.57c0 1.09 0 1.63.12 2.08a3.5 3.5 0 0 0 2.47 2.47c.45.12 1 .12 2.08.12.3 0 .46 0 .59-.03a1 1 0 0 0 .7-.71c.04-.13.04-.28.04-.6V17c0-.46 0-.7.03-.9a2.5 2.5 0 0 1 2.08-2.07c.2-.03.43-.03.89-.03s.7 0 .9.03c1.06.17 1.9 1 2.07 2.08.03.2.03.43.03.89v2.67c0 .3 0 .46.03.59a1 1 0 0 0 .71.7c.13.04.28.04.6.04 1.08 0 1.62 0 2.07-.12a3.5 3.5 0 0 0 2.47-2.47c.12-.45.12-1 .12-2.08"/>
    </svg>
  );
}
