import React from 'react';

/**
 * PiCloudDisabledContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCloudDisabledContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'cloud-disabled icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M4.13 11.67a4.5 4.5 0 0 0 .35 7.85L17.1 6.9A6.48 6.48 0 0 0 6.47 9.08a15 15 0 0 1-.67 1.49l-.03.03-.11.1c-.1.1-.58.39-1.53.97"/><path d="M20.27 9.2a1 1 0 0 0-1.3.1L9 19.3a1 1 0 0 0 .7 1.7h6.8a6.5 6.5 0 0 0 3.77-11.8"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.7 20h6.8a5.5 5.5 0 0 0 3.19-9.98M6.47 9.08A6.5 6.5 0 0 1 12.5 5c1.8 0 3.42.73 4.6 1.9M6.47 9.08a6.5 6.5 0 0 0-.3 3.92m.3-3.92c-.33.8-.49 1.2-.57 1.32-.15.24-.03.1-.24.3-.1.1-.58.39-1.53.97a4.5 4.5 0 0 0 .35 7.85M17.1 6.9 4.48 19.52M17.1 6.9 20 4M2 22l2.48-2.48"/>
    </svg>
  );
}
