import React from 'react';

/**
 * PiInputFieldContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiInputFieldContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'input-field icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M17 7H7c-.93 0-1.4 0-1.78.08a4 4 0 0 0-3.14 3.14C2 10.61 2 11.07 2 12s0 1.4.08 1.78a4 4 0 0 0 3.14 3.14c.39.08.85.08 1.78.08h10z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 17H7c-.93 0-1.4 0-1.78-.08a4 4 0 0 1-3.14-3.14C2 13.39 2 12.93 2 12s0-1.4.08-1.78a4 4 0 0 1 3.14-3.14C5.61 7 6.07 7 7 7h10m0 10V7m0 10c0 .93 0 1.4-.1 1.78a3 3 0 0 1-2.12 2.12c-.38.1-.85.1-1.78.1m4-4c0 .93 0 1.4.1 1.78a3 3 0 0 0 2.12 2.12c.39.1.85.1 1.78.1M17 7c0-.93 0-1.4-.1-1.78a3 3 0 0 0-2.12-2.12C14.4 3 13.93 3 13 3m4 4c0-.93 0-1.4.1-1.78a3 3 0 0 1 2.12-2.12c.39-.1.85-.1 1.78-.1m0 12.65a4 4 0 0 0 .92-1.87c.08-.39.08-.85.08-1.78s0-1.4-.08-1.78A4 4 0 0 0 21 8.35M7 13a1 1 0 1 1 0-2 1 1 0 0 1 0 2m6 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2"/>
    </svg>
  );
}
