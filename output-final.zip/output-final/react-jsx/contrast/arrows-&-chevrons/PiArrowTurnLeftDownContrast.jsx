import React from 'react';

/**
 * PiArrowTurnLeftDownContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowTurnLeftDownContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-turn-left-down icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M4 15.14a25 25 0 0 0 4.5 4.69.8.8 0 0 0 1 0 25 25 0 0 0 4.5-4.69 24 24 0 0 1-10 0" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 15.65V12c0-2.8 0-4.2.54-5.27a5 5 0 0 1 2.19-2.19C12.8 4 14.2 4 17 4h3M9 15.65a24 24 0 0 1-3.13-.2L4 15.14a25 25 0 0 0 4.5 4.68.8.8 0 0 0 1 0 25 25 0 0 0 4.5-4.69 24 24 0 0 1-5 .5"/>
    </svg>
  );
}
