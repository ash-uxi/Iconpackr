import React from 'react';

/**
 * PiShieldAIContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiShieldAIContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'shield-ai icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m5.5 4.31 5.38-1.94a3 3 0 0 1 2.04 0l5.47 1.97a3 3 0 0 1 1.97 2.6l.23 2.94a11 11 0 0 1-5.73 10.52l-1.5.8a3 3 0 0 1-2.9-.03l-1.53-.86a11 11 0 0 1-5.54-9.98l.13-3.31a3 3 0 0 1 1.98-2.7" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.87 2.37 5.5 4.3a3 3 0 0 0-1.98 2.71l-.13 3.3a11 11 0 0 0 5.54 9.99l1.52.86a3 3 0 0 0 2.92.04l1.49-.81a11 11 0 0 0 5.73-10.52l-.23-2.95a3 3 0 0 0-1.97-2.59l-5.47-1.97a3 3 0 0 0-2.04 0M12.5 8a4.5 4.5 0 0 1-3 3 4.5 4.5 0 0 1 3 3 4.5 4.5 0 0 1 3-3 4.5 4.5 0 0 1-3-3"/>
    </svg>
  );
}
