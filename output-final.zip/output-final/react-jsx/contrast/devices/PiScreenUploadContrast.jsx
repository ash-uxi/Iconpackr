import React from 'react';

/**
 * PiScreenUploadContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiScreenUploadContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'screen-upload icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g clipPath="url(#icon-e9osziqpf-a)"><path fill="currentColor" fillRule="evenodd" d="M4.4 2h10.51v.65l-.28.36a3 3 0 0 0 2.4 4.8V9a3 3 0 0 0 4.53 2.58H22v3.02c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.66c-.32.16-.74.16-1.58.16H4.4c-.84 0-1.26 0-1.58-.16a1.5 1.5 0 0 1-.66-.66C2 15.86 2 15.44 2 14.6V4.4c0-.84 0-1.26.16-1.58a1.5 1.5 0 0 1 .66-.66C3.14 2 3.56 2 4.4 2" clipRule="evenodd" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.16 2H4.4c-.84 0-1.26 0-1.58.16a1.5 1.5 0 0 0-.66.66C2 3.14 2 3.56 2 4.4v10.2c0 .84 0 1.26.16 1.58a1.5 1.5 0 0 0 .66.66c.32.16.74.16 1.58.16H12m10-4.52v2.12c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.66c-.32.16-.74.16-1.58.16H12m0 3.88V17m0 3.88c-1.75 0-3.5.37-5 1.12m5-1.12c1.75 0 3.5.37 5 1.12"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M23.03 4.81a15 15 0 0 0-2.55-2.65.7.7 0 0 0-.45-.16m-3 2.81a15 15 0 0 1 2.56-2.65.7.7 0 0 1 .44-.16m0 0v7"/></g><defs><clipPath id="icon-e9osziqpf-a"><path fill="currentColor" d="M0 0h24v24H0z"/></clipPath></defs>
    </svg>
  );
}
