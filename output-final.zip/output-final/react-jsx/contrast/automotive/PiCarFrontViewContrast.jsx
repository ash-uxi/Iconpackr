import React from 'react';

/**
 * PiCarFrontViewContrast icon from the contrast style in automotive category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCarFrontViewContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'car-front-view icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M21.95 10.81c.05.27.05.55.05 1.1V19a2 2 0 1 1-4 0v-1c-4 0-8 .03-12 0v1a2 2 0 1 1-4 0v-7.08c0-.56 0-.84.05-1.1l.12-.47C5 10.76 8.37 11 12 11s7-.24 9.83-.65q.08.22.12.46" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21.83 10.35c-2.83.41-6.2.65-9.83.65s-7-.24-9.83-.65m19.66 0q.08.22.12.46c.05.27.05.55.05 1.1V19a2 2 0 1 1-4 0v-1c-4 0-8 .03-12 0v1a2 2 0 1 1-4 0v-7.08c0-.56 0-.84.05-1.1l.12-.47m19.66 0-.1-.23a6 6 0 0 0-.58-.94l-1.47-2.11a7 7 0 0 0-1.13-1.41 3 3 0 0 0-1.02-.54C17.12 5 16.66 5 15.73 5H8.27c-.92 0-1.38 0-1.8.12a3 3 0 0 0-1.01.54c-.35.27-.6.65-1.13 1.4L2.85 9.19a6 6 0 0 0-.68 1.17m19.66 0 1.17-.18m-20.83.18L1 10.17m17 3.6-1 .07m-10 0-1-.07"/>
    </svg>
  );
}
