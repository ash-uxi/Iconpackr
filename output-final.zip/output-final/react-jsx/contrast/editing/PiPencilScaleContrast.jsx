import React from 'react';

/**
 * PiPencilScaleContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPencilScaleContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'pencil-scale icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M17.8 2h-2.6c-1.12 0-1.68 0-2.1.22a2 2 0 0 0-.88.87C12 3.52 12 4.08 12 5.2v13.6c0 1.12 0 1.68.22 2.1q.3.58.87.88c.43.22.99.22 2.11.22h2.6c1.12 0 1.68 0 2.1-.22a2 2 0 0 0 .88-.87c.22-.43.22-.99.22-2.11V5.2c0-1.12 0-1.68-.22-2.1a2 2 0 0 0-.87-.88C19.48 2 18.92 2 17.8 2"/><path d="M3.66 3.2a3 3 0 0 0-.43.5 1 1 0 0 0-.16.4c-.03.16-.03.32-.03.65L3 21.02c0 .66.45 1.22 1.09 1.36q1.15.24 2.3 0h.05l.07-.02a1.4 1.4 0 0 0 1.09-1.34v-.07l.04-16.17a3 3 0 0 0-.04-.68 1 1 0 0 0-.17-.4c-.09-.14-.2-.27-.45-.5l-1.7-1.7z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 18h4m-4-8h4m-4-4h3m-3 8h3m.2 8h2.6c1.12 0 1.68 0 2.1-.22a2 2 0 0 0 .88-.87c.22-.43.22-.99.22-2.11V5.2c0-1.12 0-1.68-.22-2.1a2 2 0 0 0-.87-.88C19.48 2 18.92 2 17.8 2h-2.6c-1.12 0-1.68 0-2.1.22a2 2 0 0 0-.88.87C12 3.52 12 4.08 12 5.2v13.6c0 1.12 0 1.68.22 2.1q.3.58.87.88c.43.22.99.22 2.11.22M5.28 1.5l1.7 1.7c.24.23.36.36.45.5q.12.19.17.4a3 3 0 0 1 .04.68L7.6 20.95v.07a1.4 1.4 0 0 1-1.16 1.35l-.05.01q-1.15.24-2.3 0c-.64-.14-1.1-.7-1.09-1.36l.04-16.27c0-.33 0-.5.03-.65q.06-.2.16-.4a3 3 0 0 1 .43-.5z"/>
    </svg>
  );
}
