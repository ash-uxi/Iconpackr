import React from 'react';

/**
 * PiBookmarkDefaultContrast icon from the contrast style in files-&-folders category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBookmarkDefaultContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'bookmark-default icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M5 9c0-1.86 0-2.8.24-3.55a5 5 0 0 1 3.21-3.2C9.21 2 10.14 2 12 2s2.8 0 3.55.24a5 5 0 0 1 3.2 3.21C19 6.21 19 7.14 19 9v13l-1.8-1.54c-1.84-1.58-2.77-2.37-3.8-2.68a5 5 0 0 0-2.8 0c-1.03.3-1.96 1.1-3.8 2.68L5 22z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 9c0-1.86 0-2.8.24-3.55a5 5 0 0 1 3.21-3.2C9.21 2 10.14 2 12 2s2.8 0 3.55.24a5 5 0 0 1 3.2 3.21C19 6.21 19 7.14 19 9v13l-1.8-1.54c-1.84-1.58-2.77-2.37-3.8-2.68a5 5 0 0 0-2.8 0c-1.03.3-1.96 1.1-3.8 2.68L5 22z"/>
    </svg>
  );
}
