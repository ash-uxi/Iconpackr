import React from 'react';

/**
 * PiChartCandlestickContrast icon from the contrast style in chart-&-graph category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiChartCandlestickContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'chart-candlestick icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M12.5 6c.83 0 1.5.67 1.5 1.5v9c0 .83-.67 1.5-1.5 1.5h-1a1.5 1.5 0 0 1-1.5-1.5v-9c0-.83.67-1.5 1.5-1.5z"/><path d="M21 8.5c0-.83-.67-1.5-1.5-1.5h-1c-.83 0-1.5.67-1.5 1.5v4c0 .83.67 1.5 1.5 1.5h1c.83 0 1.5-.67 1.5-1.5z"/><path d="M7 11.5c0-.83-.67-1.5-1.5-1.5h-1c-.83 0-1.5.67-1.5 1.5v4c0 .83.67 1.5 1.5 1.5h1c.83 0 1.5-.67 1.5-1.5z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 18h.5c.83 0 1.5-.67 1.5-1.5v-9c0-.83-.67-1.5-1.5-1.5H12m0 12h-.5a1.5 1.5 0 0 1-1.5-1.5v-9c0-.83.67-1.5 1.5-1.5h.5m0 12v3m0-15V3m7 4h.5c.83 0 1.5.67 1.5 1.5v4c0 .83-.67 1.5-1.5 1.5H19m0-7h-.5c-.83 0-1.5.67-1.5 1.5v4c0 .83.67 1.5 1.5 1.5h.5m0-7V4m0 10v3M5 10h.5c.83 0 1.5.67 1.5 1.5v4c0 .83-.67 1.5-1.5 1.5H5m0-7h-.5c-.83 0-1.5.67-1.5 1.5v4c0 .83.67 1.5 1.5 1.5H5m0-7V7m0 10v3"/>
    </svg>
  );
}
