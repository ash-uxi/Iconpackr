import React from 'react';

/**
 * PiRedditOldContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiRedditOldContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'reddit-old icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M21.44 3.75a1.4 1.4 0 1 1-2.8 0 1.4 1.4 0 0 1 2.8 0"/><path d="M21 14.65c0 3.86-4.03 7-9 7s-9-3.14-9-7q0-1.15.44-2.18h-.1a2.17 2.17 0 1 1 2.11-2.63A10.3 10.3 0 0 1 12 7.64c2.58 0 4.9.85 6.55 2.2a2.17 2.17 0 1 1 2 2.63q.45 1.04.45 2.17"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m12 7.65 1.53-3.9a1.5 1.5 0 0 1 1.65-.9l3.49.64M12 7.65c-2.58 0-4.9.84-6.55 2.2M12 7.64c2.58 0 4.9.84 6.55 2.2m-2.96 7.2a5.5 5.5 0 0 1-3.6 1.13c-1.53 0-2.87-.46-3.59-1.14M18.68 3.5q-.03.13-.03.26a1.4 1.4 0 1 0 .03-.26M5.45 9.84a2.17 2.17 0 1 0-2.01 2.63m2.01-2.63a7 7 0 0 0-2.01 2.63m0 0A6 6 0 0 0 3 14.64c0 3.87 4.03 7 9 7s9-3.13 9-7a6 6 0 0 0-.44-2.17m-2.01-2.63a2.17 2.17 0 1 1 2 2.63m-2-2.63a7 7 0 0 1 2 2.63M9 13.14a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0m7 0a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0"/>
    </svg>
  );
}
