import React from 'react';

/**
 * PiCeilingLampOnContrast icon from the contrast style in appliances category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCeilingLampOnContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'ceiling-lamp-on icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12 5a9 9 0 0 0-9 9h18a9 9 0 0 0-9-9" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 5a9 9 0 0 0-9 9h18a9 9 0 0 0-9-9m0 0V2m0 19v-1m4.5-.13L16 19m-8.5.87L8 19m7-5a3 3 0 1 1-6 0z"/>
    </svg>
  );
}
