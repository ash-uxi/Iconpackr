import React from 'react';

/**
 * PiTruckTrashContrast icon from the contrast style in automotive category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTruckTrashContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'truck-trash icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2 10v5.3c0 1.12 0 1.68.22 2.1q.3.58.87.88c.57.29 1.3.22 1.91.22a2 2 0 1 1 4 0h6V6z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 18.5a2 2 0 0 0 4 0m-4 0a2 2 0 1 1 4 0m-4 0H9m6 0v-10m4 10c.61 0 1.34.07 1.9-.22a2 2 0 0 0 .88-.87c.22-.43.22-.99.22-2.11v-1.8l-1.2-2.99a5 5 0 0 0-.67-1.35 2 2 0 0 0-.79-.53c-.33-.13-.72-.13-1.5-.13H15m-6 10a2 2 0 0 1-4 0m4 0a2 2 0 1 0-4 0m0 0c-.61 0-1.34.07-1.9-.22a2 2 0 0 1-.88-.87C2 16.98 2 16.42 2 15.3V10l13-4v2.5"/>
    </svg>
  );
}
