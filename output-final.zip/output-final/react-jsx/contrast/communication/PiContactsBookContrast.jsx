import React from 'react';

/**
 * PiContactsBookContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiContactsBookContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'contacts-book icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M13 2h-2c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19C3 5.8 3 7.2 3 10v4c0 2.8 0 4.2.54 5.27a5 5 0 0 0 2.19 2.18C6.8 22 8.2 22 11 22h2c2.8 0 4.2 0 5.27-.55a5 5 0 0 0 2.18-2.18C21 18.2 21 16.8 21 14v-4c0-2.8 0-4.2-.55-5.27a5 5 0 0 0-2.18-2.19C17.2 2 15.8 2 13 2" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2 8h2m-2 8h2m7 6h2c2.8 0 4.2 0 5.27-.55a5 5 0 0 0 2.18-2.18C21 18.2 21 16.8 21 14v-4c0-2.8 0-4.2-.55-5.27a5 5 0 0 0-2.18-2.19C17.2 2 15.8 2 13 2h-2c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19C3 5.8 3 7.2 3 10v4c0 2.8 0 4.2.54 5.27a5 5 0 0 0 2.19 2.18C6.8 22 8.2 22 11 22m3.22-13.23a2.22 2.22 0 1 1-4.44 0 2.22 2.22 0 0 1 4.44 0m-4.44 4.9c-1.23 0-2.22 1-2.22 2.22 0 .61.5 1.11 1.1 1.11h6.67c.62 0 1.11-.5 1.11-1.11 0-1.23-1-2.22-2.22-2.22z"/>
    </svg>
  );
}
