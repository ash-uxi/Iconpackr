import React from 'react';

/**
 * PiTvContrast icon from the contrast style in appliances category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTvContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'tv icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2 6.4c0-.84 0-1.26.16-1.58q.23-.43.66-.66C3.14 4 3.56 4 4.4 4h15.2c.84 0 1.26 0 1.58.16q.43.23.66.66c.16.32.16.74.16 1.58v9.2c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.66c-.32.16-.74.16-1.58.16H4.4c-.84 0-1.26 0-1.58-.16a1.5 1.5 0 0 1-.66-.66C2 16.86 2 16.44 2 15.6z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m20 21-2-3M4 21l2-3m-1.6 0h15.2c.84 0 1.26 0 1.58-.16q.43-.23.66-.66c.16-.32.16-.74.16-1.58V6.4c0-.84 0-1.26-.16-1.58a1.5 1.5 0 0 0-.66-.66C20.86 4 20.44 4 19.6 4H4.4c-.84 0-1.26 0-1.58.16a1.5 1.5 0 0 0-.66.66C2 5.14 2 5.56 2 6.4v9.2c0 .84 0 1.26.16 1.58q.23.43.66.66c.32.16.74.16 1.58.16"/>
    </svg>
  );
}
