import React from 'react';

/**
 * PiSupabaseContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSupabaseContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'supabase icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12 15H7.13c-2.19 0-3.28 0-3.83-.45a2 2 0 0 1-.74-1.58c0-.71.71-1.55 2.11-3.23L10.6 2.7c.43-.52.65-.78.84-.81a.5.5 0 0 1 .44.16c.13.14.13.48.13 1.16V9m0 6v5.8c0 .68 0 1.02.13 1.16a.5.5 0 0 0 .44.16c.2-.03.41-.29.85-.8l5.9-7.07c1.41-1.67 2.11-2.5 2.13-3.22a2 2 0 0 0-.75-1.59C20.15 9 19.06 9 16.88 9H12" opacity=".28"/><path stroke="currentColor" strokeWidth="2" d="M12 15H7.13c-2.19 0-3.28 0-3.83-.45a2 2 0 0 1-.74-1.58c0-.71.71-1.55 2.11-3.23L10.6 2.7c.43-.52.65-.78.84-.81a.5.5 0 0 1 .44.16c.13.14.13.48.13 1.16V9m0 6V9m0 6v5.8c0 .68 0 1.02.13 1.16a.5.5 0 0 0 .44.16c.2-.03.41-.29.85-.8l5.9-7.07c1.41-1.67 2.11-2.5 2.13-3.22a2 2 0 0 0-.75-1.59C20.15 9 19.06 9 16.88 9H12"/>
    </svg>
  );
}
