import React from 'react';

/**
 * PiTwitterContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTwitterContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'twitter icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M20.96 5.25c.18-.4-.3-.75-.69-.54q-.93.5-1.94.8c-2.71-3.38-7.39-.53-6.7 3.12.02.12-.06.24-.19.24a7.6 7.6 0 0 1-6.07-2.83c-.24-.27-.68-.26-.86.06C3.36 8.07.54 14.17 7.8 16.62a25 25 0 0 1-4.23 2.18c-.23.1-.24.43-.01.53 9.48 4.27 18.71-1.95 15.79-11.74a8 8 0 0 0 1.6-2.34" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.96 5.25c.18-.4-.3-.75-.69-.54q-.93.5-1.94.8c-2.71-3.38-7.39-.53-6.7 3.12.02.12-.06.24-.19.24a7.6 7.6 0 0 1-6.07-2.83c-.24-.27-.68-.26-.86.06C3.36 8.07.54 14.17 7.8 16.62a25 25 0 0 1-4.23 2.18c-.23.1-.24.43-.01.53 9.48 4.27 18.71-1.95 15.79-11.74a8 8 0 0 0 1.6-2.34"/>
    </svg>
  );
}
