import React from 'react';

/**
 * PiBatteryOffContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBatteryOffContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'battery-off icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M17.53 6.3C16.8 6 15.86 6 14 6H8c-1.86 0-2.8 0-3.53.3A4 4 0 0 0 2.3 8.47C2 9.2 2 10.14 2 12s0 2.8.3 3.53a4 4 0 0 0 2.17 2.17c.41.17.89.24 1.56.27L17.65 6.35z"/><path d="M20.3 8.75a1 1 0 0 1 .65.86q.06.91.05 2.35v.08q.01 1.34-.04 2.22-.04.9-.34 1.65a5 5 0 0 1-2.7 2.7c-.52.22-1.05.3-1.66.35q-.89.05-2.22.04h-2.4a1 1 0 0 1-.7-1.7l8.3-8.31a1 1 0 0 1 1.06-.24"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.97 14c.47 0 .73 0 .92-.05a1.5 1.5 0 0 0 1.06-1.06c.05-.2.05-.43.05-.89s0-.7-.05-.89a1.5 1.5 0 0 0-1.06-1.06c-.2-.05-.45-.05-.92-.05M21 3l-3.35 3.35M3 21l3.03-3.03M17.65 6.35l-.12-.05C16.8 6 15.86 6 14 6H8c-1.86 0-2.8 0-3.53.3A4 4 0 0 0 2.3 8.47C2 9.2 2 10.14 2 12s0 2.8.3 3.53a4 4 0 0 0 2.17 2.17c.41.17.89.24 1.56.27M17.65 6.35 6.03 17.97M19.95 9.7c.05.57.05 1.3.05 2.3 0 1.86 0 2.8-.3 3.53a4 4 0 0 1-2.17 2.17c-.73.3-1.67.3-3.53.3h-2.35"/>
    </svg>
  );
}
