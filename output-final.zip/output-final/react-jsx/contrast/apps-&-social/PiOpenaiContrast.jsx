import React from 'react';

/**
 * PiOpenaiContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiOpenaiContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'openai icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M7 6a3 3 0 0 1 5.98-.34l1.72-.99a3 3 0 0 1 3.28 5.01l1.72.99a3 3 0 0 1-2.7 5.35V18a3 3 0 0 1-5.98.34l-1.72.99a3 3 0 0 1-3.28-5.01l-1.72-.99A3 3 0 0 1 7 7.98z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m10.27 12.96-2.3-1.38A2 2 0 0 1 7 9.87V7.98m3.27 4.98 1.7 1.02m-1.7-1.02.03-1.98m1.67 3-2.35 1.3a2 2 0 0 1-1.97-.02l-1.63-.94m5.95-.34 1.73-.96m0 0-.05 2.68a2 2 0 0 1-1 1.7l-1.63.94m2.68-5.32.03-1.98m0 0 2.3 1.38a2 2 0 0 1 .97 1.71v1.89m-3.27-4.98-1.7-1.02m0 0 2.35-1.3a2 2 0 0 1 1.97.02l1.63.94m-5.95.34-1.73.96m0 0 .05-2.68a2 2 0 0 1 1-1.7l1.63-.94M7 7.98a3 3 0 0 0-2.7 5.35l1.72.99M7 7.98V6a3 3 0 0 1 5.98-.34m-6.96 8.66a3 3 0 0 0 3.28 5.01l1.72-.99m0 0A3 3 0 0 0 17 18v-1.98m0 0a3 3 0 0 0 2.7-5.35l-1.72-.99m0 0a3 3 0 0 0-3.28-5.01l-1.72.99"/>
    </svg>
  );
}
