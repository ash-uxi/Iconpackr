import React from 'react';

/**
 * PiAlertTriangleContrast icon from the contrast style in alerts category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAlertTriangleContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'alert-triangle icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M13.39 3.28a3.6 3.6 0 0 0-2.78 0C7.96 4.41 1.7 14.42 1.88 17.1c.07 1.05.6 2.01 1.42 2.64 2.22 1.68 15.18 1.68 17.4 0a3.6 3.6 0 0 0 1.42-2.64c.18-2.68-6.08-12.69-8.73-13.82" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 13V9m-1.39-5.72c.89-.37 1.9-.37 2.78 0 2.65 1.13 8.91 11.14 8.73 13.82a3.6 3.6 0 0 1-1.42 2.64c-2.22 1.68-15.18 1.68-17.4 0a3.6 3.6 0 0 1-1.42-2.64C1.7 14.42 7.96 4.4 10.6 3.28"/>
    </svg>
  );
}
