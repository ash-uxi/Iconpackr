import React from 'react';

/**
 * PiScreenAddContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiScreenAddContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'screen-add icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" fillRule="evenodd" d="M15 2.76V2H4.4c-.84 0-1.26 0-1.58.16a1.5 1.5 0 0 0-.66.66C2 3.14 2 3.56 2 4.4v10.2c0 .84 0 1.26.16 1.58q.23.43.66.66c.32.16.74.16 1.58.16h15.2c.84 0 1.26 0 1.58-.16q.43-.23.66-.66c.16-.32.16-.74.16-1.58v-3.98h-.53q-.66.37-1.47.38a3 3 0 0 1-3-3 3 3 0 0 1-2-5.24" clipRule="evenodd" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.35 2H4.4c-.84 0-1.26 0-1.58.16a1.5 1.5 0 0 0-.66.66C2 3.14 2 3.56 2 4.4v10.2c0 .84 0 1.26.16 1.58q.23.43.66.66c.32.16.74.16 1.58.16H12m10-5.54v3.14c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.66c-.32.16-.74.16-1.58.16H12m0 3.88V17m0 3.88c-1.75 0-3.5.37-5 1.12m5-1.12c1.75 0 3.5.37 5 1.12"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 8V5m0 0V2m0 3h-3m3 0h3"/>
    </svg>
  );
}
