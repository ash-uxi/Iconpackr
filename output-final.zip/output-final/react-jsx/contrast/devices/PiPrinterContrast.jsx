import React from 'react';

/**
 * PiPrinterContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPrinterContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'printer icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M15.6 6H8.4q-1.41 0-2.3.03c-.84.05-1.42.15-1.92.4a4 4 0 0 0-1.74 1.75C2 9.04 2 10.16 2 12.4v.8c0 1.68 0 2.52.33 3.16a3 3 0 0 0 1.3 1.31c.56.28 1.26.32 2.51.33l.2-.68c.23-.83.35-1.25.6-1.56a2 2 0 0 1 .81-.61c.37-.15.8-.15 1.66-.15h5.18c.86 0 1.3 0 1.66.15a2 2 0 0 1 .81.61c.25.31.37.73.6 1.56l.2.68c1.25 0 1.95-.05 2.5-.33a3 3 0 0 0 1.31-1.3c.33-.65.33-1.49.33-3.17v-.8c0-2.24 0-3.36-.44-4.22a4 4 0 0 0-1.74-1.74 5 5 0 0 0-1.92-.4q-.89-.05-2.3-.04" opacity=".2"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m17.9 6.03-.11-1.15c-.1-1.02-.15-1.53-.39-1.91a2 2 0 0 0-.86-.78C16.14 2 15.63 2 14.6 2H9.4c-1.03 0-1.54 0-1.94.2a2 2 0 0 0-.86.77c-.24.38-.29.9-.39 1.91L6.1 6.03m11.8 0Q17.01 6 15.6 6H8.4q-1.41 0-2.3.03m11.8 0c.84.05 1.42.15 1.92.4a4 4 0 0 1 1.74 1.75c.44.86.44 1.98.44 4.22v.8c0 1.68 0 2.52-.33 3.16a3 3 0 0 1-1.3 1.31c-.56.28-1.26.32-2.51.33M6.1 6.03c-.84.05-1.42.15-1.92.4a4 4 0 0 0-1.74 1.75C2 9.04 2 10.16 2 12.4v.8c0 1.68 0 2.52.33 3.16a3 3 0 0 0 1.3 1.31c.56.28 1.26.32 2.51.33m0 0-.27.94c-.3 1.04-.44 1.56-.32 1.97q.16.55.65.87c.36.22.9.22 1.98.22h7.64c1.08 0 1.62 0 1.98-.22q.49-.31.65-.87c.12-.41-.03-.93-.32-1.97l-.27-.94M6.14 18l.2-.68c.23-.83.35-1.25.6-1.56a2 2 0 0 1 .81-.61c.37-.15.8-.15 1.66-.15h5.18c.86 0 1.3 0 1.66.15a2 2 0 0 1 .81.61c.25.31.37.73.6 1.56l.2.68m.14-8h.01"/>
    </svg>
  );
}
