import React from 'react';

/**
 * PiAirplaneFlyingContrast icon from the contrast style in automotive category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAirplaneFlyingContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'airplane-flying icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M6.16 16H20a1 1 0 0 0 1-1 3 3 0 0 0-3-3h-3L8.9 5.03A3 3 0 0 0 6.64 4H6l3 8H6l-2.75-1.83A1 1 0 0 0 2.7 10H2l1.32 3.95A3 3 0 0 0 6.16 16" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 20h18M6.16 16H20a1 1 0 0 0 1-1 3 3 0 0 0-3-3h-3L8.9 5.03A3 3 0 0 0 6.64 4H6l3 8H6l-2.75-1.83A1 1 0 0 0 2.7 10H2l1.32 3.95A3 3 0 0 0 6.16 16"/>
    </svg>
  );
}
