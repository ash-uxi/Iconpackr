import React from 'react';

/**
 * PiDrawHighlighterAngleContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiDrawHighlighterAngleContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'draw-highlighter-angle icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m8.64 11.7 5.66 5.66.2.15-2.2 2.2a1 1 0 0 1-.71.29H4a1 1 0 0 1-1-1v-1.17a2 2 0 0 1 .59-1.41l4.9-4.91z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m17.16 15.9-1.45 1.46a1 1 0 0 1-1.22.15m2.67-1.6c.97.64 2.3.53 3.15-.32l2.48-2.48m-5.63 2.8a3 3 0 0 1-.38-.32L10.4 9.23a3 3 0 0 1-.32-.4m0 0L8.64 10.3a1 1 0 0 0-.15 1.22m1.6-2.67a2.5 2.5 0 0 1 .32-3.15l2.48-2.48m-4.4 8.3.15.19 5.66 5.66.2.15m-6-6-4.91 4.9A2 2 0 0 0 3 17.83V19a1 1 0 0 0 1 1h7.59a1 1 0 0 0 .7-.3l2.2-2.2"/>
    </svg>
  );
}
