import React from 'react';

/**
 * PiFileAIContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiFileAIContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'file-ai icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M4 15.6c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.86.44 1.98.44 4.22.44h3.2c2.24 0 3.36 0 4.22-.44a4 4 0 0 0 1.74-1.74c.44-.86.44-1.98.44-4.22V9.65c0-.79 0-1.26-.06-1.65l-.05-.28a4 4 0 0 0-.48-1.15c-.25-.4-.6-.75-1.28-1.44l-1.26-1.26a8 8 0 0 0-1.44-1.28A4 4 0 0 0 14 2.06C13.6 2 13.14 2 12.35 2H10.4c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C4 5.04 4 6.16 4 8.4z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.53 9.81a4.5 4.5 0 0 1-3 3 4.5 4.5 0 0 1 3 3 4.5 4.5 0 0 1 3-3 4.5 4.5 0 0 1-3-3"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.53 1.87v1.14c0 1.68 0 2.52.33 3.16a3 3 0 0 0 1.31 1.32c.64.32 1.48.32 3.16.32h1.15m-5.95-5.94c-.39-.06-.86-.06-1.65-.06H9.93c-2.24 0-3.36 0-4.21.44A4 4 0 0 0 3.97 4c-.44.85-.44 1.97-.44 4.21v7.2c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.75 1.75c.85.43 1.97.43 4.21.43h3.2c2.24 0 3.36 0 4.22-.43a4 4 0 0 0 1.75-1.75c.43-.86.43-1.98.43-4.22V9.46c0-.78 0-1.25-.05-1.65m-5.95-5.94.28.05q.61.15 1.16.48c.4.25.75.6 1.44 1.29l1.25 1.25c.7.69 1.04 1.04 1.28 1.44a4 4 0 0 1 .54 1.43"/>
    </svg>
  );
}
