import React from 'react';

/**
 * PiMaximizeTwoArrowContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMaximizeTwoArrowContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'maximize-two-arrow icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M12 6.29q2.68-.45 5.35-.2a.6.6 0 0 1 .56.56q.25 2.67-.2 5.35l-.05-.06a32 32 0 0 0-5.6-5.6z"/><path d="M12 17.71q-2.68.45-5.35.2a.6.6 0 0 1-.56-.56q-.25-2.67.2-5.35l.05.06a32 32 0 0 0 5.6 5.6z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.35 6.09q-2.67-.25-5.35.2l3.21 2.5 2.5 3.21q.45-2.68.2-5.35a.6.6 0 0 0-.56-.56"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6.65 17.91q2.67.25 5.35-.2l-3.21-2.5L6.29 12q-.45 2.68-.2 5.35a.6.6 0 0 0 .56.56"/>
    </svg>
  );
}
