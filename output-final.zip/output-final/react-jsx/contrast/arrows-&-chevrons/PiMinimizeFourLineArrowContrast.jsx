import React from 'react';

/**
 * PiMinimizeFourLineArrowContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMinimizeFourLineArrowContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'minimize-four-line-arrow icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g opacity=".28"><path fill="currentColor" d="M15.54 15.07q2.23-.2 4.46.17l-.95.8a24 24 0 0 0-3.02 3.01l-.79.95q-.37-2.23-.17-4.46a.5.5 0 0 1 .47-.47"/><path fill="currentColor" d="M15.07 8.46q-.2-2.23.17-4.46l.8.95a24 24 0 0 0 3.01 3.02l.95.79q-2.23.37-4.46.17a.5.5 0 0 1-.47-.47"/><path fill="currentColor" d="M8.93 8.46q.2-2.23-.17-4.46l-.8.95a24 24 0 0 1-3.01 3.02L4 8.76q2.23.37 4.46.17a.5.5 0 0 0 .47-.47"/><path fill="currentColor" d="M8.93 15.54q.2 2.23-.17 4.46l-.8-.95a24 24 0 0 0-3.01-3.02L4 15.24q2.23-.37 4.46-.17a.5.5 0 0 1 .47.47"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m21 21-3.52-3.52M3 3l3.52 3.52M3 21l3.52-3.52M21 3l-3.52 3.52m0 0a24 24 0 0 1-1.45-1.57L15.24 4q-.37 2.23-.17 4.46a.5.5 0 0 0 .47.47q2.23.2 4.46-.17l-.95-.8a24 24 0 0 1-1.57-1.44m-10.96 0a24 24 0 0 0 1.45-1.57L8.76 4q.37 2.23.17 4.46a.5.5 0 0 1-.47.47q-2.23.2-4.46-.17l.95-.8a24 24 0 0 0 1.57-1.44m0 10.96a24 24 0 0 1 1.45 1.57l.79.95q.37-2.23.17-4.46a.5.5 0 0 0-.47-.47 17 17 0 0 0-4.46.17l.95.8a24 24 0 0 1 1.57 1.44m10.96 0a24 24 0 0 1 1.57-1.45l.95-.79q-2.23-.37-4.46-.17a.5.5 0 0 0-.47.47q-.2 2.23.17 4.46l.8-.95q.67-.82 1.44-1.57"/>
    </svg>
  );
}
