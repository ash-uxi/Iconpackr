import React from 'react';

/**
 * PiRepeatRectangularContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiRepeatRectangularContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'repeat-rectangular icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M18 2q1.66 1.2 2.92 2.78c.1.13.1.31 0 .44A15 15 0 0 1 18 8l.06-.61a24 24 0 0 0 0-4.78z"/><path d="M6 16q-1.65 1.2-2.92 2.78c-.1.13-.1.31 0 .44A15 15 0 0 0 6 22l-.06-.61a24 24 0 0 1 0-4.78z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.18 5H11c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19C3.07 8.66 3.01 9.85 3 12m15.18-7a24 24 0 0 0-.12-2.39L18 2q1.66 1.2 2.92 2.78a.4.4 0 0 1 0 .44A15 15 0 0 1 18 8l.06-.61A24 24 0 0 0 18.18 5M5.82 19H13c2.8 0 4.2 0 5.27-.55a5 5 0 0 0 2.18-2.18c.48-.93.54-2.12.55-4.27M5.82 19q0-1.2.12-2.39L6 16q-1.65 1.2-2.92 2.78a.4.4 0 0 0 0 .44A15 15 0 0 0 6 22l-.06-.61A24 24 0 0 1 5.82 19"/>
    </svg>
  );
}
