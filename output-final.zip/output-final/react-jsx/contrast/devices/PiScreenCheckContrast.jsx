import React from 'react';

/**
 * PiScreenCheckContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiScreenCheckContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'screen-check icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" fillRule="evenodd" d="M21.13 7H22v7.6c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.66c-.32.16-.74.16-1.58.16H4.4c-.84 0-1.26 0-1.58-.16a1.5 1.5 0 0 1-.66-.66C2 15.86 2 15.44 2 14.6V4.4c0-.84 0-1.26.16-1.58q.23-.43.66-.66C3.14 2 3.56 2 4.4 2h9.11v.59a3 3 0 0 0 .37 3.8l2.04 2.02a3 3 0 0 0 4.72-.63q.23-.4.5-.78" clipRule="evenodd" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12.7 2H4.4c-.84 0-1.26 0-1.58.16a1.5 1.5 0 0 0-.66.66C2 3.14 2 3.56 2 4.4v10.2c0 .84 0 1.26.16 1.58q.23.43.66.66c.32.16.74.16 1.58.16H12m10-9.48v7.08c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.66c-.32.16-.74.16-1.58.16H12m0 3.88V17m0 3.88c-1.75 0-3.5.37-5 1.12m5-1.12c1.75 0 3.5.37 5 1.12"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m16 4.26 2.04 2.03A13 13 0 0 1 22 2"/>
    </svg>
  );
}
