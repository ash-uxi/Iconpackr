import React from 'react';

/**
 * PiSpreadsheetAIContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSpreadsheetAIContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'spreadsheet-ai icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M9.4 3h5.2c2.24 0 3.36 0 4.22.44a4 4 0 0 1 1.74 1.74c.41.8.44 1.84.44 3.82H9v12c-1.98 0-3.01-.03-3.82-.44a4 4 0 0 1-1.74-1.74C3.03 18.02 3 16.98 3 15V9c0-1.98.03-3.01.44-3.82a4 4 0 0 1 1.74-1.74C6.04 3 7.16 3 9.4 3" opacity=".28"/><path stroke="currentColor" strokeLinejoin="round" strokeWidth="2" d="M9 9v6m0-6H3m6 0h12c0-1.98-.03-3.01-.44-3.82a4 4 0 0 0-1.74-1.74C17.96 3 16.84 3 14.6 3H9.4c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C3.03 5.98 3 7.02 3 9m6 6v6c-1.98 0-3.01-.03-3.82-.44a4 4 0 0 1-1.74-1.74C3.03 18.02 3 16.98 3 15m6 0H3m0 0V9"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 14a4.5 4.5 0 0 1-3 3 4.5 4.5 0 0 1 3 3 4.5 4.5 0 0 1 3-3 4.5 4.5 0 0 1-3-3"/>
    </svg>
  );
}
