import React from 'react';

/**
 * PiRotateRightContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiRotateRightContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'rotate-right icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M18.83 6.4a15 15 0 0 0-1.05-3.73l-.24.54a24 24 0 0 1-2.41 4.18l-.35.48a15 15 0 0 0 3.57-.89c.27-.1.53-.25.48-.58" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.75 14a8 8 0 1 1-3.3-8.65m0 0q.6-1.05 1.1-2.14l.23-.54a15 15 0 0 1 1.05 3.73c.05.33-.21.48-.48.58a15 15 0 0 1-3.57.89l.35-.48q.7-.99 1.32-2.04"/>
    </svg>
  );
}
