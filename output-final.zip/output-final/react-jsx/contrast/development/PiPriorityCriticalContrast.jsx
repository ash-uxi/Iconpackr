import React from 'react';

/**
 * PiPriorityCriticalContrast icon from the contrast style in development category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiPriorityCriticalContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'priority-critical icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M11.3 4.16A32 32 0 0 0 5.76 7.8c-.49.4-.75.98-.75 1.57V20a32 32 0 0 1 6.3-4.28q.33-.16.7-.16t.7.16A32 32 0 0 1 19 20V9.37c0-.6-.26-1.16-.75-1.57a32 32 0 0 0-5.56-3.64Q12.38 4.01 12 4q-.37 0-.7.16"/><path d="M11.3 4.16A32 32 0 0 0 5.76 7.8c-.49.4-.75.98-.75 1.57V20a32 32 0 0 1 6.3-4.28q.33-.16.7-.16t.7.16A32 32 0 0 1 19 20V9.37c0-.6-.26-1.16-.75-1.57a32 32 0 0 0-5.56-3.64Q12.38 4.01 12 4q-.37 0-.7.16"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.3 4.16A32 32 0 0 0 5.76 7.8c-.49.4-.75.98-.75 1.57V20a32 32 0 0 1 6.3-4.28q.33-.16.7-.16t.7.16A32 32 0 0 1 19 20V9.37c0-.6-.26-1.16-.75-1.57a32 32 0 0 0-5.56-3.64Q12.38 4.01 12 4q-.37 0-.7.16"/>
    </svg>
  );
}
