import React from 'react';

/**
 * PiTwitchContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTwitchContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'twitch icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M7.8 3h8.4c1.68 0 2.52 0 3.16.31q.87.42 1.31 1.25c.33.6.33 1.4.33 3v4.32c0 .93 0 1.4-.11 1.83q-.15.6-.48 1.1c-.25.38-.6.71-1.28 1.37l-.26.24c-.69.66-1.03.98-1.44 1.22q-.53.3-1.15.45c-.46.11-.95.11-1.93.11H12L8 22v-3.8h-.2c-1.68 0-2.52 0-3.16-.31a3 3 0 0 1-1.31-1.25c-.33-.6-.33-1.4-.33-3V7.56c0-1.6 0-2.4.33-3q.44-.83 1.3-1.25C5.29 3 6.13 3 7.8 3" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 11V7.75M16 11V7.75M8 18.2h-.2c-1.68 0-2.52 0-3.16-.31a3 3 0 0 1-1.31-1.25c-.33-.6-.33-1.4-.33-3V7.56c0-1.6 0-2.4.33-3q.44-.83 1.3-1.25C5.29 3 6.13 3 7.8 3h8.4c1.68 0 2.52 0 3.16.31q.87.42 1.31 1.25c.33.6.33 1.4.33 3v4.32c0 .93 0 1.4-.11 1.83q-.15.6-.48 1.1c-.25.38-.6.71-1.28 1.37l-.26.24c-.69.66-1.03.98-1.44 1.22q-.53.3-1.15.45c-.46.11-.95.11-1.93.11H12L8 22z"/>
    </svg>
  );
}
