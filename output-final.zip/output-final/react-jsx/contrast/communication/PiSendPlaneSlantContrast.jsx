import React from 'react';

/**
 * PiSendPlaneSlantContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSendPlaneSlantContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'send-plane-slant icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="m9.54 14.46-5.48-2.99A2.02 2.02 0 0 1 4.1 7.9a51 51 0 0 1 12.56-4.5c1.25-.28 2.68-.84 3.73.22 1.06 1.05.5 2.48.23 3.73a51 51 0 0 1-4.51 12.56 2.02 2.02 0 0 1-3.57.03z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m9.54 14.46-5.48-2.99A2.02 2.02 0 0 1 4.1 7.9a51 51 0 0 1 12.56-4.5c1.25-.28 2.68-.84 3.73.22 1.06 1.05.5 2.48.23 3.73a51 51 0 0 1-4.51 12.56 2.02 2.02 0 0 1-3.57.03zm0 0 3.3-3.3"/>
    </svg>
  );
}
