import React from 'react';

/**
 * PiBulbBoltContrast icon from the contrast style in appliances category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBulbBoltContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'bulb-bolt icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12 3C8.13 3 5 6.02 5 9.74c0 2.04.94 3.86 2.43 5.1A4 4 0 0 1 8.8 16.8l.28 1.08A1.5 1.5 0 0 0 10.54 19h2.92a1.5 1.5 0 0 0 1.46-1.12l.28-1.08c.2-.8.74-1.44 1.37-1.96A6.6 6.6 0 0 0 19 9.74 6.87 6.87 0 0 0 12 3" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 22h4M12.38 6.7l-1.83 2.7c-.12.16 0 .37.22.41l2.46.4c.23.04.34.24.22.4l-2.08 2.69M5 9.74A6.87 6.87 0 0 1 12 3c3.87 0 7 3.02 7 6.74 0 2.04-.94 3.86-2.43 5.1a4 4 0 0 0-1.37 1.96l-.28 1.08A1.5 1.5 0 0 1 13.46 19h-2.92a1.5 1.5 0 0 1-1.46-1.12L8.8 16.8a4 4 0 0 0-1.37-1.96A6.6 6.6 0 0 1 5 9.74"/>
    </svg>
  );
}
