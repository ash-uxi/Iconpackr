import React from 'react';

/**
 * PiKeyboardWirelessContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiKeyboardWirelessContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'keyboard-wireless icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M15.6 5H8.4c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C2 8.04 2 9.16 2 11.4v1.2c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.86.44 1.98.44 4.22.44h7.2c2.24 0 3.36 0 4.22-.44a4 4 0 0 0 1.74-1.74c.44-.86.44-1.98.44-4.22v-1.2c0-2.24 0-3.36-.44-4.22a4 4 0 0 0-1.74-1.74C18.96 5 17.84 5 15.6 5" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 15H8m10-6h.01M18 12h.01M8.4 19h7.2c2.24 0 3.36 0 4.22-.44a4 4 0 0 0 1.74-1.74c.44-.86.44-1.98.44-4.22v-1.2c0-2.24 0-3.36-.44-4.22a4 4 0 0 0-1.74-1.74C18.96 5 17.84 5 15.6 5H8.4c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C2 8.04 2 9.16 2 11.4v1.2c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.86.44 1.98.44 4.22.44"/>
    </svg>
  );
}
