import React from 'react';

/**
 * PiSteeringWheelContrast icon from the contrast style in automotive category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSteeringWheelContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'steering-wheel icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M19.5 12a7.5 7.5 0 0 0-7.32 9.15h-.36a7.52 7.52 0 0 0-8.97-8.97v-.3A16 16 0 0 1 12 9c3.4 0 6.56 1.06 9.15 2.87v.31A8 8 0 0 0 19.5 12" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19.5a7.5 7.5 0 0 1 9.15-7.32M12 19.5a7.5 7.5 0 0 0-9.15-7.32M12 19.5q0 .86.18 1.65M12 19.5q0 .86-.18 1.65m.36 0h-.36m.36 0a9.15 9.15 0 0 0 8.97-8.97m-9.33 8.97a9.15 9.15 0 0 1-8.97-8.97m0 0v-.3m0 0A16 16 0 0 1 12 9c3.4 0 6.56 1.06 9.15 2.87m-18.3 0a9.15 9.15 0 0 1 18.3 0m0 0v.31M12 12.01"/>
    </svg>
  );
}
