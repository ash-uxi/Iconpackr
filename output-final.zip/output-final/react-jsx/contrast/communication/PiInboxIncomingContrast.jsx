import React from 'react';

/**
 * PiInboxIncomingContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiInboxIncomingContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'inbox-incoming icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M10 20h4c2.8 0 4.2 0 5.27-.55a5 5 0 0 0 2.18-2.18C22 16.2 22 14.8 22 12v-.15c0-.32 0-.47-.02-.63l-.05-.22h-5a.9.9 0 0 0-.93.92c0 1.7-1.38 3.08-3.08 3.08h-1.84A3.1 3.1 0 0 1 8 11.92a.9.9 0 0 0-.92-.92h-5l-.06.22c-.02.16-.02.31-.02.63V12c0 2.8 0 4.2.54 5.27a5 5 0 0 0 2.19 2.18C5.8 20 7.2 20 10 20" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21.93 11h-5a.9.9 0 0 0-.93.92c0 1.7-1.38 3.08-3.08 3.08h-1.84A3.1 3.1 0 0 1 8 11.92a.9.9 0 0 0-.92-.92h-5m19.85 0-.06-.18a4 4 0 0 0-.3-.56l-1.73-3.04a9 9 0 0 0-1.48-2.18 4 4 0 0 0-1.44-.84m5 6.8.06.22c.02.16.02.31.02.63V12c0 2.8 0 4.2-.55 5.27a5 5 0 0 1-2.18 2.18C18.2 20 16.8 20 14 20h-4c-2.8 0-4.2 0-5.27-.55a5 5 0 0 1-2.19-2.18C2 16.2 2 14.8 2 12v-.15c0-.32 0-.47.02-.63l.05-.22m0 0 .06-.18c.06-.15.13-.28.3-.56l1.73-3.04c.67-1.17 1-1.76 1.48-2.18a4 4 0 0 1 1.44-.84M10 7.13a10 10 0 0 0 1.7 1.77q.15.1.3.1m2-1.87a10 10 0 0 1-1.7 1.77q-.15.1-.3.1m0 0V4"/>
    </svg>
  );
}
