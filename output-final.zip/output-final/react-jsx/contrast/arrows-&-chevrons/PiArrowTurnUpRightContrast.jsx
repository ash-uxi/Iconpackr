import React from 'react';

/**
 * PiArrowTurnUpRightContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiArrowTurnUpRightContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'arrow-turn-up-right icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M15.14 4a25 25 0 0 1 4.69 4.5.8.8 0 0 1 0 1 25 25 0 0 1-4.69 4.5 24 24 0 0 0 .3-8.13c-.06-.47-.14-.94-.3-1.87" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.65 9H12c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19C4 12.8 4 14.2 4 17v3M15.65 9a24 24 0 0 0-.2-3.13L15.14 4a25 25 0 0 1 4.68 4.5.8.8 0 0 1 0 1 25 25 0 0 1-4.69 4.5 24 24 0 0 0 .5-5"/>
    </svg>
  );
}
