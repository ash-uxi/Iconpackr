import React from 'react';

/**
 * PiAmieSoContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAmieSoContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'amie-so icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M8.21 21A5.2 5.2 0 0 0 12 19.37a5.2 5.2 0 0 0 9-3.58A5.2 5.2 0 0 0 19.37 12a5.2 5.2 0 0 0-3.58-9A5.2 5.2 0 0 0 12 4.63a5.2 5.2 0 0 0-9 3.58c0 1.5.63 2.84 1.63 3.79a5.2 5.2 0 0 0 3.58 9" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.21 21A5.2 5.2 0 0 0 12 19.37a5.2 5.2 0 0 0 9-3.58A5.2 5.2 0 0 0 19.37 12a5.2 5.2 0 0 0-3.58-9A5.2 5.2 0 0 0 12 4.63a5.2 5.2 0 0 0-9 3.58c0 1.5.63 2.84 1.63 3.79a5.2 5.2 0 0 0 3.58 9"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 14v-4a1 1 0 1 1 2 0v4a1 1 0 1 1-2 0"/>
    </svg>
  );
}
