import React from 'react';

/**
 * PiScreenRemoveContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiScreenRemoveContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'screen-remove icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" fillRule="evenodd" d="M14.07 2H4.4c-.84 0-1.26 0-1.58.16a1.5 1.5 0 0 0-.66.66C2 3.14 2 3.56 2 4.4v10.2c0 .84 0 1.26.16 1.58q.23.43.66.66c.32.16.74.16 1.58.16h15.2c.84 0 1.26 0 1.58-.16q.43-.23.66-.66c.16-.32.16-.74.16-1.58V9.76c-.79 0-1.55-.32-2.1-.88l-.36-.35-.35.35a3 3 0 1 1-4.24-4.24l.35-.35-.35-.36A3 3 0 0 1 14.07 2" clipRule="evenodd" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.04 2H4.4c-.84 0-1.26 0-1.58.16a1.5 1.5 0 0 0-.66.66C2 3.14 2 3.56 2 4.4v10.2c0 .84 0 1.26.16 1.58q.23.43.66.66c.32.16.74.16 1.58.16H12m10-6.23v3.83c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.66c-.32.16-.74.16-1.58.16H12m0 3.88V17m0 3.88c-1.75 0-3.5.37-5 1.12m5-1.12c1.75 0 3.5.37 5 1.12"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m17.03 6.76 2.48-2.47m0 0 2.47-2.48M19.51 4.3l-2.48-2.5m2.48 2.48 2.47 2.47"/>
    </svg>
  );
}
