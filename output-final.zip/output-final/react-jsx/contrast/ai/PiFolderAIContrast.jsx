import React from 'react';

/**
 * PiFolderAIContrast icon from the contrast style in ai category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiFolderAIContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'folder-ai icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2 9.4c0-2.24 0-3.36.44-4.22a4 4 0 0 1 1.74-1.74C5.04 3 6.16 3 8.4 3h.32c.47 0 .7 0 .91.06q.3.1.52.28c.17.14.3.34.56.73l.58.86c.26.4.39.59.56.73q.23.19.52.28c.21.06.44.06.91.06h2.32c2.24 0 3.36 0 4.22.44a4 4 0 0 1 1.74 1.74c.44.86.44 1.98.44 4.22v2.2c0 2.24 0 3.36-.44 4.22a4 4 0 0 1-1.74 1.74c-.86.44-1.98.44-4.22.44H8.4c-2.24 0-3.36 0-4.22-.44a4 4 0 0 1-1.74-1.74C2 17.96 2 16.84 2 14.6z" opacity=".28"/><path fill="currentColor" d="M12.5 10.5a4.5 4.5 0 0 0 3 3 4.5 4.5 0 0 0-3 3 4.5 4.5 0 0 0-3-3 4.5 4.5 0 0 0 3-3"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.71 3H8.4c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C2 6.04 2 7.16 2 9.4v5.2c0 2.24 0 3.36.44 4.22a4 4 0 0 0 1.74 1.74c.86.44 1.98.44 4.22.44h7.2c2.24 0 3.36 0 4.22-.44a4 4 0 0 0 1.74-1.74c.44-.86.44-1.98.44-4.22v-2.2c0-2.24 0-3.36-.44-4.22a4 4 0 0 0-1.74-1.74C18.96 6 17.84 6 15.6 6h-2.32c-.47 0-.7 0-.91-.06a2 2 0 0 1-.52-.28c-.17-.14-.3-.34-.56-.73l-.58-.86c-.26-.4-.39-.59-.56-.73a2 2 0 0 0-.52-.28C9.42 3 9.2 3 8.72 3m3.79 7.5a4.5 4.5 0 0 1-3 3 4.5 4.5 0 0 1 3 3 4.5 4.5 0 0 1 3-3 4.5 4.5 0 0 1-3-3"/>
    </svg>
  );
}
