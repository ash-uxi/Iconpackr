import React from 'react';

/**
 * PiEnvelopeSettingsContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiEnvelopeSettingsContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'envelope-settings icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M10 4h4c2.8 0 4.2 0 5.27.54a5 5 0 0 1 2.18 2.19C22 7.8 22 9.2 22 12v.3h-.27a3 3 0 0 0-.87-.13h-.44l-.32-.31a3 3 0 0 0-4.2 0l-.32.3-.44.01a3 3 0 0 0-2.97 2.97v.44l-.31.32a3 3 0 0 0-.45 3.62V20H10c-2.8 0-4.2 0-5.27-.55a5 5 0 0 1-2.19-2.18C2 16.2 2 14.8 2 12s0-4.2.54-5.27a5 5 0 0 1 2.19-2.19C5.8 4 7.2 4 10 4" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.54 20H10c-2.8 0-4.2 0-5.27-.55a5 5 0 0 1-2.19-2.18C2 16.2 2 14.8 2 12c0-2 0-3.28.2-4.24m19.6 0-5.5 3.5c-1.56 1-2.34 1.5-3.18 1.69a5 5 0 0 1-2.24 0c-.84-.2-1.62-.7-3.18-1.68l-5.5-3.5m19.6 0a4 4 0 0 0-.35-1.04 5 5 0 0 0-2.18-2.19C18.2 4 16.8 4 14 4h-4c-2.8 0-4.2 0-5.27.54a5 5 0 0 0-2.19 2.19 4 4 0 0 0-.34 1.03m19.6 0c.18.85.2 1.96.2 3.6M18 18h.01M18 14l1.18 1.15 1.65.02.02 1.65L22 18l-1.15 1.18-.02 1.65-1.65.02L18 22l-1.18-1.15-1.65-.02-.02-1.65L14 18l1.15-1.18.02-1.65 1.65-.02z"/>
    </svg>
  );
}
