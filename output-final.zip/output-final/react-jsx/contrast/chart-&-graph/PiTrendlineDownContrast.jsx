import React from 'react';

/**
 * PiTrendlineDownContrast icon from the contrast style in chart-&-graph category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiTrendlineDownContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'trendline-down icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M20.88 16.55q.84-2.1 1.12-4.38l-1.15.81a24 24 0 0 1-3.56 2.06l-1.28.59q2.1.9 4.36 1.22c.22.03.43-.1.5-.3" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m2 7.15.73.94a22 22 0 0 0 6.6 5.66.7.7 0 0 0 .93-.22l3.2-4.82a.64.64 0 0 1 .93-.15A20 20 0 0 1 19.24 14m0 0q.83-.48 1.6-1.03l1.16-.8q-.27 2.26-1.12 4.37a.5.5 0 0 1-.51.3q-2.26-.32-4.36-1.22l1.28-.6q1-.46 1.95-1.02"/>
    </svg>
  );
}
