import React from 'react';

/**
 * PiMicrosoftEdgeContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMicrosoftEdgeContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'microsoft-edge icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12.1 9.6c-.5 0-1.09.22-1.66.6-.29.27-.72.86-.72 2 0 4.92 6.93 7.34 10.41 4.87.47-.41 1 .03.7.48-1.83 2.8-5.15 4.07-8.72 4.07a9.62 9.62 0 1 1 7.52-15.65c2.95 3.68 2.75 9.26-3.08 9.26-1.5 0-2.84-.45-2.84-1.12 0-.85.85-.66.85-2.1l-.02-.26S14.1 9.6 12.1 9.6" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.35 21.55c-3.3-.04-5.71-3.4-5.71-6.02a6.7 6.7 0 0 1 2.8-5.32m0 0a3 3 0 0 1 1.67-.6c1.99 0 2.43 2.14 2.43 2.14m-4.1-1.54c-.29.26-.72.85-.72 1.99 0 4.92 6.93 7.34 10.41 4.87.47-.41 1 .03.7.48-1.83 2.8-5.15 4.07-8.72 4.07a9.62 9.62 0 1 1 7.52-15.65c2.95 3.68 2.75 9.26-3.08 9.26-1.5 0-2.84-.45-2.84-1.12 0-.85.85-.66.85-2.1 0-2.94-3.17-5.08-5.86-5.08s-6.2 1.83-6.2 5.09m7.94-1.81q.24-.2.26-.19"/>
    </svg>
  );
}
