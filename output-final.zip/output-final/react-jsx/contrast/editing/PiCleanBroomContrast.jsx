import React from 'react';

/**
 * PiCleanBroomContrast icon from the contrast style in editing category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiCleanBroomContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'clean-broom icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M19 14.61q-.02-.93-.2-1.9c-.3-1.56-1.9-2.05-3.17-2.37-2.65-.67-3.32.31-4.9 2.12z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.72 12.46a33 33 0 0 1-7.3 6.15c-1.92 1.22 3.26 1.9 3.72 1.97m3.58-8.12L19 14.61m-8.28-2.15c1.59-1.8 2.26-2.8 4.9-2.12M19 14.6a11 11 0 0 0-.2-1.9c-.3-1.56-1.9-2.05-3.17-2.37M19 14.6a11.4 11.4 0 0 1-1.17 5.13c-.66 1.38-3.7 1.26-5.34 1.25m-5.35-.4q2.66.4 5.35.4m-5.35-.4a15.5 15.5 0 0 0 4.6-4.32m.75 4.72c.64-.68 1.98-2.3 2.72-3.7m.42-6.95L18.65 3"/>
    </svg>
  );
}
