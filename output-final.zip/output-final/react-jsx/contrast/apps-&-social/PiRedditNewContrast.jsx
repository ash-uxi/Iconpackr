import React from 'react';

/**
 * PiRedditNewContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiRedditNewContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'reddit-new icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M12 20.85c4.95 0 8.97-2.9 8.97-6.46q0-.33-.05-.65a2.43 2.43 0 1 0-2.36-3.76 10.8 10.8 0 0 0-6.55-2.06H12c-2.6 0-4.93.8-6.56 2.06a2.42 2.42 0 1 0-2.36 3.76q-.05.32-.05.65c0 3.57 4.02 6.46 8.97 6.46"/><path d="M17.53 4.7a1.35 1.35 0 1 0 0-2.7 1.35 1.35 0 0 0 0 2.7"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.56 9.98a2.42 2.42 0 1 1 2.36 3.76q.05.32.05.65c0 3.57-4.02 6.46-8.97 6.46s-8.97-2.9-8.97-6.46q0-.33.05-.65a2.43 2.43 0 1 1 2.36-3.76m13.12 0a10.8 10.8 0 0 0-6.55-2.06m6.55 2.06.45.37M5.44 9.98A10.8 10.8 0 0 1 12 7.92M5.44 9.98l-.45.37m7.02-2.43a3.8 3.8 0 0 1 4.18-4.61m0 0v.04a1.35 1.35 0 1 0 0-.04M14.43 17c-1.44 1.43-3.56 1.43-4.86 0zM6.6 13.64c.03-.68.48-1.2 1-1.2.53 0 .93.55.9 1.23s-.42.93-.95.93c-.52 0-.98-.28-.95-.96m10.78 0c-.03-.68-.48-1.2-1-1.2-.53 0-.93.55-.9 1.23s.42.93.95.93c.52 0 .98-.28.95-.96"/>
    </svg>
  );
}
