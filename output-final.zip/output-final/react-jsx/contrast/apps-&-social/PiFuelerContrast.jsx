import React from 'react';

/**
 * PiFuelerContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiFuelerContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'fueler icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12 2.1c1 0 1.72 1.6 2.62 1.89.92.3 2.45-.56 3.22 0 .78.57.44 2.28 1 3.06.57.77 2.32.97 2.62 1.9.29.88-1 2.06-1 3.05s1.29 2.17 1 3.06c-.3.92-2.05 1.12-2.61 1.9s-.23 2.48-1 3.05c-.78.56-2.3-.3-3.23 0-.9.3-1.63 1.89-2.62 1.89s-1.72-1.6-2.62-1.9c-.92-.3-2.45.56-3.22 0-.78-.57-.44-2.28-1-3.06-.57-.77-2.32-.97-2.62-1.9-.29-.88 1-2.06 1-3.05s-1.29-2.17-1-3.06c.3-.92 2.05-1.12 2.61-1.9s.23-2.48 1-3.05c.78-.56 2.3.3 3.23 0 .9-.3 1.63-1.89 2.62-1.89" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2.1c1 0 1.72 1.6 2.62 1.89.92.3 2.45-.56 3.22 0 .78.57.44 2.28 1 3.06.57.77 2.32.97 2.62 1.9.29.88-1 2.06-1 3.05s1.29 2.17 1 3.06c-.3.92-2.05 1.12-2.61 1.9s-.23 2.48-1 3.05c-.78.56-2.3-.3-3.23 0-.9.3-1.63 1.89-2.62 1.89s-1.72-1.6-2.62-1.9c-.92-.3-2.45.56-3.22 0-.78-.57-.44-2.28-1-3.06-.57-.77-2.32-.97-2.62-1.9-.29-.88 1-2.06 1-3.05s-1.29-2.17-1-3.06c.3-.92 2.05-1.12 2.61-1.9s.23-2.48 1-3.05c.78-.56 2.3.3 3.23 0 .9-.3 1.63-1.89 2.62-1.89"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m9.22 12.48 2.67-5.1c.18-.33.69-.2.69.18v3.1q0 .16.1.26t.26.11h1.52a.37.37 0 0 1 .32.55l-2.8 5.04c-.18.33-.67.2-.67-.18v-3.06q0-.15-.11-.26a.4.4 0 0 0-.26-.1h-1.4a.37.37 0 0 1-.32-.54"/>
    </svg>
  );
}
