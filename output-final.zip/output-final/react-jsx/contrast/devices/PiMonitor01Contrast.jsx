import React from 'react';

/**
 * PiMonitor01Contrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiMonitor01Contrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'monitor-01 icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M2 4.4c0-.84 0-1.26.16-1.58q.23-.43.66-.66C3.14 2 3.56 2 4.4 2h15.2c.84 0 1.26 0 1.58.16q.43.23.66.66c.16.32.16.74.16 1.58v10.2c0 .84 0 1.26-.16 1.58a1.5 1.5 0 0 1-.66.66c-.32.16-.74.16-1.58.16H4.4c-.84 0-1.26 0-1.58-.16a1.5 1.5 0 0 1-.66-.66C2 15.86 2 15.44 2 14.6z" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 22H7m5-5v5m-7.6-5h15.2c.84 0 1.26 0 1.58-.16q.43-.23.66-.66c.16-.32.16-.74.16-1.58V4.4c0-.84 0-1.26-.16-1.58a1.5 1.5 0 0 0-.66-.66C20.86 2 20.44 2 19.6 2H4.4c-.84 0-1.26 0-1.58.16a1.5 1.5 0 0 0-.66.66C2 3.14 2 3.56 2 4.4v10.2c0 .84 0 1.26.16 1.58q.23.43.66.66c.32.16.74.16 1.58.16"/>
    </svg>
  );
}
