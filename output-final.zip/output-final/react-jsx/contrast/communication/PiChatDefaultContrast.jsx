import React from 'react';

/**
 * PiChatDefaultContrast icon from the contrast style in communication category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiChatDefaultContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'chat-default icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12 21a9 9 0 1 0-8.91-7.73l.27 1.97c.02.25.01.16.01.42l-.04.7-.15 2.15c-.06.86-.1 1.29.06 1.61q.2.42.64.64c.32.15.75.12 1.6.06l2.16-.15.7-.04.42.01 1.97.27q.62.09 1.27.09" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h8m-8 4h4m9-2a9 9 0 0 1-10.27 8.91l-1.97-.27c-.25-.02-.16-.01-.42-.01l-.7.04-2.15.15c-.86.06-1.29.1-1.61-.06q-.42-.2-.64-.64c-.15-.32-.12-.75-.06-1.6l.15-2.16.04-.7-.01-.42-.27-1.97A9 9 0 1 1 21 12"/>
    </svg>
  );
}
