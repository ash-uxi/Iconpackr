import React from 'react';

/**
 * PiUturnLeftContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiUturnLeftContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'uturn-left icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M4.14 7.6a21 21 0 0 1 3.9-3.68l-.18 2.32a24 24 0 0 0 0 3.52l.17 2.32A21 21 0 0 1 4.14 8.4a.64.64 0 0 1 0-.8" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7.8 8H15a5 5 0 1 1 0 10h-3M7.8 8a24 24 0 0 1 .06-1.76l.17-2.32a21 21 0 0 0-3.89 3.67.64.64 0 0 0 0 .81 21 21 0 0 0 3.9 3.68l-.18-2.32A24 24 0 0 1 7.8 8"/>
    </svg>
  );
}
