import React from 'react';

/**
 * PiSpeakerOffContrast icon from the contrast style in devices category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiSpeakerOffContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'speaker-off icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="m19.56 4.18.08.18L4.36 19.64C4 18.81 4 17.7 4 15.6V8.4c0-2.24 0-3.36.44-4.22a4 4 0 0 1 1.74-1.74C7.04 2 8.16 2 10.4 2h3.2c2.24 0 3.36 0 4.22.44a4 4 0 0 1 1.74 1.74"/><path d="M21 9.66a1 1 0 0 0-1.7-.71l-4.18 4.17a1 1 0 0 0-.25 1 3 3 0 0 1-3.75 3.75 1 1 0 0 0-1 .25l-3.11 3.11a1 1 0 0 0 .62 1.7q1.07.09 2.72.07h3.3q1.6.02 2.66-.06a5 5 0 0 0 1.96-.49 5 5 0 0 0 2.18-2.18c.3-.6.43-1.23.5-1.96q.06-1.04.05-2.67z"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m22 2-2.36 2.36M2 22l2.36-2.36m3.36 2.3c.67.06 1.53.06 2.68.06h3.2c2.24 0 3.36 0 4.22-.44a4 4 0 0 0 1.74-1.74c.44-.86.44-1.98.44-4.22V9.66m-9.17 9.17a4 4 0 0 0 5-5m3.81-9.47-.08-.18a4 4 0 0 0-1.74-1.74C16.96 2 15.84 2 13.6 2h-3.2c-2.24 0-3.36 0-4.22.44a4 4 0 0 0-1.74 1.74C4 5.04 4 6.16 4 8.4v7.2c0 2.1 0 3.2.36 4.04M19.64 4.36 12.9 11.1m0 0a4 4 0 0 0-4.8 4.8m4.8-4.8-4.8 4.8m0 0-3.74 3.74M12 7a.5.5 0 1 1 0-1 .5.5 0 0 1 0 1"/>
    </svg>
  );
}
