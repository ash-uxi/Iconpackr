import React from 'react';

/**
 * PiBlueskyContrast icon from the contrast style in apps-&-social category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiBlueskyContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'bluesky icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M12 11.3c-.9-1.88-3.37-5.38-5.66-7.11C4.68 2.94 2 1.98 2 5.05c0 .6.35 5.14.56 5.88.7 2.56 3.31 3.21 5.63 2.82-4.05.69-5.08 2.98-2.86 5.26 4.22 4.35 6.07-1.09 6.54-2.48.13-.38.13-.38.26 0 .47 1.4 2.32 6.83 6.54 2.48 2.22-2.28 1.19-4.57-2.86-5.26 2.32.4 4.92-.26 5.63-2.82.21-.74.56-5.27.56-5.88 0-3.07-2.68-2.1-4.34-.86-2.29 1.73-4.75 5.23-5.66 7.1" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11.3c-.9-1.88-3.37-5.38-5.66-7.11C4.68 2.94 2 1.98 2 5.05c0 .6.35 5.14.56 5.88.7 2.56 3.31 3.21 5.63 2.82-4.05.69-5.08 2.98-2.86 5.26 4.22 4.35 6.07-1.09 6.54-2.48.13-.38.13-.38.26 0 .47 1.4 2.32 6.83 6.54 2.48 2.22-2.28 1.19-4.57-2.86-5.26 2.32.4 4.92-.26 5.63-2.82.21-.74.56-5.27.56-5.88 0-3.07-2.68-2.1-4.34-.86-2.29 1.73-4.75 5.23-5.66 7.1"/>
    </svg>
  );
}
