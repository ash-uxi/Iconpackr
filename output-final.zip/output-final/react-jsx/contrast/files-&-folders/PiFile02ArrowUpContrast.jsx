import React from 'react';

/**
 * PiFile02ArrowUpContrast icon from the contrast style in files-&-folders category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiFile02ArrowUpContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'file-02-arrow-up icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <path fill="currentColor" d="M16 22H8a4 4 0 0 1-4-4V6a4 4 0 0 1 4-4h4a8 8 0 0 1 8 8v8a4 4 0 0 1-4 4" opacity=".28"/><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 11a3 3 0 0 0-3-3h-.6c-.37 0-.56 0-.71-.02a2 2 0 0 1-1.67-1.67C14 6.16 14 5.97 14 5.6V5a3 3 0 0 0-3-3m-1 10.87a10 10 0 0 1 1.7-1.77q.15-.1.3-.1m2 1.87a10 10 0 0 0-1.7-1.77.5.5 0 0 0-.3-.1m0 0v6m8-7v8a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4V6a4 4 0 0 1 4-4h4a8 8 0 0 1 8 8"/>
    </svg>
  );
}
