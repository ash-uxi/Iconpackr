import React from 'react';

/**
 * PiAlignVerticalCenterContrast icon from the contrast style in arrows-&-chevrons category.
 * @param {Object} props - Component props
 * @param {number} [props.size=24] - Icon size
 * @param {string} [props.color] - Icon color
 * @param {string} [props.className] - Additional CSS class
 * @param {string} [props.ariaLabel] - Accessibility label
 */
export default function PiAlignVerticalCenterContrast({ 
  size = 24, 
  color,
  className,
  ariaLabel = 'align-vertical-center icon',
  ...props 
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{color: color || "currentColor"}}
      
      role="img"
      aria-label={ariaLabel}
      {...props}
    >
      <g fill="currentColor" opacity=".28"><path d="M11.7 9.88q-1.52-1.4-2.7-3.2 3 .3 6 0a16 16 0 0 1-2.7 3.2.4.4 0 0 1-.3.12.4.4 0 0 1-.3-.12"/><path d="M12.3 14.12q1.52 1.4 2.7 3.2-3-.3-6 0 1.18-1.8 2.7-3.2.14-.12.3-.12t.3.12"/></g><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.83V3m0 3.83q-1.5 0-3-.15 1.18 1.8 2.7 3.2.14.12.3.12t.3-.12q1.52-1.4 2.7-3.2-1.5.15-3 .15m0 10.34V21m0-3.83q1.5 0 3 .15a16 16 0 0 0-2.7-3.2.4.4 0 0 0-.3-.12q-.16 0-.3.12-1.52 1.4-2.7 3.2 1.5-.15 3-.15M5 12h14"/>
    </svg>
  );
}
